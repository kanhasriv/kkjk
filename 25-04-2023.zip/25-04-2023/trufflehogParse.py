# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 19:20:33 2021

@author: rnandre
"""

import json

# Opening JSON file
f = open('trufflehog.json',)
  
# returns JSON object as 
# a dictionary
try:
    data = json.load(f)
    #print("data",data)
    for i in data:
       # print("\n\n\n\n\n\n")
       try:
        print("path :",str(i['path']),"Strings found ", str(i['stringsFound']))
       except:
            print("couldn't read vulnerabilities")
except:
    print("No data loaded")    

# Iterating through the json
# list

  
# Closing file
f.close()