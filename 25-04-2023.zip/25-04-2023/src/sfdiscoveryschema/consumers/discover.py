"""
This service contains APIs for the data discover
"""
import traceback
import logging
import sys
import uuid
from datetime import datetime
from ftplib import FTP
import pyodbc
import numpy as np
import pandas as pd
from config import config, db, send_message
from libs import teradata, snowflake
from libs.util import abcr_job_run
from libs.secret_manager import get_secret

log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'
job_run_failed = "Job run failed"
hashamp_function = '(hashamp()+1)'
query_log = "query {}"
hostname_format = '{hostname}'

def discover(data):
    """
    Data Discover Consumer for teradata and snowflake
    """
    log.info("START")
    try:
        job_id = data["job_id"]
        creation_time = data["discover_creation_time"]
        job_run_id = data["job_run_id"]
        job_name = data["job_name"]
        run_by = data["run_by"]
        project_id = data['project_id']
        user_id = data["user_id"]
        socket_flag = data["socket_flag"]
        pipeline_id = data["pipeline_id"]
        db.job_run.update_one({"job_id": job_id, "job_run_id": job_run_id},
                              {"$set": {"status": "InProgress"}})
        job_register_df = db.job_registry.find_one({"job_id": job_id, "job_type": "discovery"},
                                                   {'_id': 0})
        link_service_id = job_register_df["link_service_id"]
        query = {"link_service_id": link_service_id, "active": True}
        log.info("db.link_service.find_one():query: {query}".format(query=query))
        resp = db.link_service.find_one(query, {'_id': 0})

        link_service_type = resp["link_service_type"]
        db_vendor_type = link_service_type.lower().split()[1]
        db_vendor = link_service_type.lower().split()[0]
        hostname = resp["db_hostname"]

        # Getting the secrets from secret manager
        username = get_secret(link_service_id + "-username")
        password = get_secret(link_service_id + "-password")

        batch_id = str(uuid.uuid4())

        def content_callback(line):
            content.append(line.split("¬"))
            return content

        if db_vendor == 'teradata':
            log.info("Database Vendor Encountered: Teradata")

            database_df = pd.DataFrame()
            table_df = pd.DataFrame()
            column_df = pd.DataFrame()
            view_df = pd.DataFrame()
            user_df = pd.DataFrame()
            role_df = pd.DataFrame()
            macro_df = pd.DataFrame()
            procedure_df = pd.DataFrame()
            hashamp_df = pd.DataFrame()
            object_details_df = pd.DataFrame()

            # Connecting to FTP and checking for required file in folder
            if db_vendor_type == "ftp":
                try:
                    shared_path = resp["shared_path"]
                    port = resp["port"]
                    ftp = FTP()
                    ftp.connect(hostname,port)
                    ftp.login(username,password)
                    # ftp.set_pasv(False)
                    content = []
                    ftp.encoding = "utf-8"
                    FTP.maxline = sys.maxsize - 1
                    ftp.cwd("/" + shared_path + "/" + config["ftp"]["discover"])
                    file_names = ftp.nlst()
                except Exception as exception:
                    log.error(traceback.format_exc())
                    job_status = "Fail"
                    end_time = int(datetime.utcnow().timestamp())
                    end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
                    error_code = exception.args[0].split()[0]
                    if error_code == "550":
                        log.error({"message": "Provided path does not exist"})

                    # Populating details on ABCR
                    if config["ABCR"]["flag"] == "Y":
                        abcr_status = abcr_job_run("", end_time,
                                                   {"message": "Teradata FTP Connection failed!"},
                                                   job_register_df['job_id'], job_run_id, job_name,
                                                   "MigrationSF-discovery",
                                                   {"message": job_run_failed}, run_by,
                                                   creation_time, job_status,config['ABCR']['discover'], "")
                        if abcr_status == "Fail":
                            log.info("Error while producing message on job run topic")
                            db.job_run.update_one({"job_id": data["job_id"],
                                                   "job_run_id": job_run_id},
                                                  {"$set": {"status": "Fail",
                                                            "end_time": end_time,
                                                            "end_time_str": end_time_str}})
                            return
                    db.job_run.update_one({"job_id": data["job_id"], "job_run_id": job_run_id},
                                          {"$set": {"status": job_status, "end_time": end_time,
                                                    "end_time_str": end_time_str}})
                    return

                # Reading file with database details
                if "Database_discovery_Info.txt" in file_names:
                    ftp.retrlines("RETR Database_discovery_Info.txt", callback=content_callback)
                    columns = content[0]
                    del content[0]
                    database_df = pd.DataFrame(content, columns=columns)
                    database_df.columns = database_df.columns.str.strip()
                    database_df.dropna(subset=['DATABASE_NM'], inplace=True)
                    database_df.reset_index(drop=True, inplace=True)
                    if socket_flag:
                        send_message("sf_discover_run", {"status": "Database discovery successful..", "pipeline_id": pipeline_id}, user_id)
                    log.info("Teradata FTP database Metadata Fetching Successful..")

                # Reading file with table details
                if "Table_discovery_Info.txt" in file_names:
                    content = []
                    ftp.retrlines("RETR Table_discovery_Info.txt", callback=content_callback)
                    columns = content[0]
                    del content[0]
                    table_df = pd.DataFrame(content, columns=columns)
                    table_df.columns = table_df.columns.str.strip()
                    table_df.dropna(subset=['TABLE_NM'], inplace=True)
                    table_df.reset_index(drop=True, inplace=True)

                    if "Table_count_Info.txt" in file_names:
                        content = []
                        ftp.retrlines("RETR Table_count_Info.txt", callback=content_callback)
                        columns = content[0]
                        del content[0]
                        table_count_df = pd.DataFrame(content, columns=columns)
                        table_count_df.columns = table_count_df.columns.str.strip()

                        table_df = pd.merge(table_df, table_count_df, on=["DATABASE_NM", "TABLE_NM"]
                                            , how="left")
                        table_df.dropna(subset=['TABLE_NM'], inplace=True)
                        table_df.reset_index(drop=True, inplace=True)
                        table_df['NUM_OF_RECORDS'] = table_df['NUM_OF_RECORDS'].fillna(value=0)

                    if "Table_ddl_Info.txt" in file_names:
                        content = []
                        ftp.retrlines("RETR Table_ddl_Info.txt", callback=content_callback)
                        columns = content[0]
                        del content[0]
                        table_ddl_df = pd.DataFrame(content, columns=columns)
                        table_ddl_df.columns = table_ddl_df.columns.str.strip()

                        table_df = pd.merge(table_df, table_ddl_df, on=["DATABASE_NM", "TABLE_NM"],
                                            how="left")
                        table_df.dropna(subset=['TABLE_NM'], inplace=True)
                        table_df.replace({'': None}, inplace=True)
                        table_df.reset_index(drop=True, inplace=True)
                        table_df['DEFINITION'] = table_df['DEFINITION'].fillna(value='')
                    if socket_flag:
                        send_message("sf_discover_run", {"status": "Table discovery successful..", "pipeline_id": pipeline_id}, user_id)
                    log.info("Teradata FTP table Metadata Fetching Successful..")

                # Reading file with column details
                if "Column_discovery_Info.txt" in file_names:
                    content = []
                    ftp.retrlines("RETR Column_discovery_Info.txt", callback=content_callback)
                    columns = content[0]
                    del content[0]
                    column_df = pd.DataFrame(content, columns=columns)
                    column_df.columns = column_df.columns.str.strip()
                    column_df.dropna(subset=['COLUMN_NM'], inplace=True)
                    column_df.replace({'': None}, inplace=True)
                    column_df['COLUMN_LENGTH'].replace({None: ''}, inplace=True)
                    column_df.reset_index(drop=True, inplace=True)
                    if socket_flag:
                        send_message("sf_discover_run", {"status": "Column discovery successful..", "pipeline_id": pipeline_id}, user_id)
                    log.info("Teradata FTP column Metadata Fetching Successful..")

                # Reading file with view details
                if "View_discovery_Info.txt" in file_names:
                    content = []
                    ftp.retrlines("RETR View_discovery_Info.txt", callback=content_callback)
                    columns = content[0]
                    del content[0]
                    view_df = pd.DataFrame(content, columns=columns)
                    view_df.columns = view_df.columns.str.strip()
                    view_df.dropna(subset=['View_Nm'], inplace=True)
                    view_df["Schema_Nm"] = None
                    view_df["View_Definition"].replace(to_replace=r'(\\r+)', value=' ', regex=True,
                                                       inplace=True)
                    view_df.reset_index(drop=True, inplace=True)
                    if socket_flag:
                        send_message("sf_discover_run", {"status": "View discovery successful..", "pipeline_id": pipeline_id}, user_id)
                    log.info("Teradata FTP view Metadata Fetching Successful..")

                # Reading file with role
                if "Role_Discovery_sf_info.txt" in file_names:
                    content = []
                    ftp.retrlines("RETR Role_Discovery_sf_info.txt", callback=content_callback)
                    columns = content[0]
                    del content[0]
                    role_df = pd.DataFrame(content, columns=columns)
                    role_df.columns = role_df.columns.str.strip()
                    role_df.dropna(subset=['Role_Nm'], inplace=True)
                    role_df["SCHEMA_NM"] = None
                    role_df.reset_index(drop=True, inplace=True)
                    role_df['child_role_nm'].replace({"": None},inplace = True)
                    if socket_flag:
                        send_message("sf_discover_run", {"status": "Role discovery successful..", "pipeline_id": pipeline_id}, user_id)
                    log.info("Teradata FTP role Metadata Fetching Successful..")

                # Reading file with user
                if "User_Discovery_sf_info.txt" in file_names:
                    content = []
                    ftp.retrlines("RETR User_Discovery_sf_info.txt", callback=content_callback)
                    columns = content[0]
                    del content[0]
                    user_df = pd.DataFrame(content, columns=columns)
                    user_df.columns = user_df.columns.str.strip()
                    user_df.dropna(subset=['user_nm'], inplace=True)
                    user_df["Schema_Nm"] = None
                    user_df.reset_index(drop=True, inplace=True)
                    user_df['role_nm'].replace({"": None},inplace = True)
                    if socket_flag:
                        send_message("sf_discover_run", {"status": "User discovery successful..", "pipeline_id": pipeline_id}, user_id)
                    log.info("Teradata FTP user Metadata Fetching Successful..")

                # Reading file with macro details
                if "Macro_discovery_Info.txt" in file_names:
                    content = []
                    ftp.retrlines("RETR Macro_discovery_Info.txt", callback=content_callback)
                    columns = content[0]
                    del content[0]
                    macro_df = pd.DataFrame(content, columns=columns)
                    macro_df.columns = macro_df.columns.str.strip()
                    macro_df.dropna(subset=['Macro_Nm'], inplace=True)
                    macro_df.reset_index(drop=True, inplace=True)
                    if socket_flag:
                        send_message("sf_discover_run", {"status": "Macro discovery successful..", "pipeline_id": pipeline_id}, user_id)
                    log.info("Teradata FTP Macro Metadata Fetching Successful..")

                # Reading file with procedure details
                if "Procedure_discovery_Info.txt" in file_names:
                    content = []
                    ftp.retrlines("RETR Procedure_discovery_Info.txt", callback=content_callback)
                    columns = content[0]
                    del content[0]
                    procedure_df = pd.DataFrame(content, columns=columns)
                    procedure_df.dropna(subset=['PROCEDURE_NAME'], inplace=True)
                    procedure_df.reset_index(drop=True, inplace=True)
                    procedure_df.rename(columns={"PROCEDURE_NAME": "PROCEDURE_NM",
                                                 "DATABASE_NAME": "DATABASE_NM"}, inplace=True)
                    procedure_df["Schema_Nm"] = None
                    procedure_df.columns = procedure_df.columns.str.strip()
                    if socket_flag:
                        send_message("sf_discover_run", {"status": "Procedure discovery successful..", "pipeline_id": pipeline_id}, user_id)
                    log.info("Teradata FTP Procedure Metadata Fetching Successful..")

                # Reading file with HASHAMP
                if "Hashamp_discovery_Info.txt" in file_names:
                    content = []
                    ftp.retrlines("RETR Hashamp_discovery_Info.txt", callback=content_callback)
                    columns = content[0]
                    del content[0]
                    hashamp_df = pd.DataFrame(content, columns=columns)
                    hashamp_df.columns = hashamp_df.columns.str.strip()
                    hashamp_df.columns = hashamp_df.columns.str.lower()
                    hashamp_df[hashamp_function].replace('', np.nan, inplace=True)
                    hashamp_df.dropna(subset=[hashamp_function], inplace=True)
                    hashamp_df.reset_index(drop=True, inplace=True)
                    if socket_flag:
                        send_message("sf_discover_run", {"status": "Hashamp discovery successful..", "pipeline_id": pipeline_id}, user_id)
                    log.info("Teradata FTP Hashamp Metadata Fetching Successful..")

                # Reading file with Object Details
                if "Object_discovery_Info.txt" in file_names:
                    content = []
                    ftp.retrlines("RETR Object_discovery_Info.txt", callback=content_callback)
                    columns = content[0]
                    del content[0]
                    object_details_df = pd.DataFrame(content, columns=columns)
                    object_details_df.columns = object_details_df.columns.str.strip()
                    object_details_df.dropna(subset=['OBJECT_KIND'], inplace=True)
                    object_details_df.reset_index(drop=True, inplace=True)
                    if socket_flag:
                        send_message("sf_discover_run", {"status": "Object discovery successful..", "pipeline_id": pipeline_id}, user_id)
                    log.info("Teradata FTP object details Metadata Fetching Successful..")

            # Making connection string for teradata DWH
            if db_vendor_type == "dwh":
                td_conn_string = config[db_vendor]["conn"].format(hostname=hostname, uid=username,
                                                                  pwd=password)
                try:
                    conn = pyodbc.connect(td_conn_string)
                    log.info("Teradata Connection Established..")
                except pyodbc.Error as exception:
                    log.error(exception)
                    job_status = "Fail"
                    end_time = int(datetime.utcnow().timestamp())
                    end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)

                    # Populating details on ABCR
                    if config["ABCR"]["flag"] == "Y":
                        abcr_status = abcr_job_run("", end_time,
                                                   {"message": "Teradata DWH Connection failed!"},
                                                   job_register_df['job_id'], job_run_id, job_name,
                                                   "MigrationSF-discovery",
                                                   {"message": job_run_failed}, run_by,
                                                   creation_time, job_status, config['ABCR']['discover'], "")
                        if abcr_status == "Fail":
                            log.info("Error while producing message on job run topic")
                            db.job_run.update_one({"job_id": data["job_id"],
                                                   "job_run_id": job_run_id},
                                                  {"$set": {"status": job_status,
                                                            "end_time": end_time,
                                                            "end_time_str": end_time_str}})
                            return

                    db.job_run.update_one({"job_id": data["job_id"], "job_run_id": job_run_id},
                                          {"$set": {"status": job_status, "end_time": end_time,
                                                    "end_time_str": end_time_str}})
                    return

                # Fetching details for database
                tera_query = teradata.query["database_discover"]
                log.info(query_log.format(tera_query))
                database_df = pd.read_sql_query(tera_query, conn)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Database discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("Teradata DWH database Metadata Fetching Successful..")

                # Fetching details for table
                tera_query = teradata.query["table_discover"]
                log.info(query_log.format(tera_query))
                table_df = pd.read_sql_query(tera_query, conn)
                for index, row in table_df.iterrows():
                    ddl_query = teradata.query["table_ddl"]. \
                        format(database_name=row.DATABASE_NM, table_name=row.TABLE_NM)
                    ddl_df = pd.read_sql_query(ddl_query, conn)
                    table_df.loc[index, "definition"] = ddl_df.iloc[0][0]
                table_df.replace({pd.NaT: None}, inplace=True)

                tera_query = teradata.query["table_no_records"]
                no_of_records_df = pd.read_sql_query(tera_query, conn)
                table_df = pd.merge(table_df, no_of_records_df, on=["DATABASE_NM", "TABLE_NM"],
                                    how="left")
                table_df['NUM_OF_RECORDS'] = table_df['NUM_OF_RECORDS'].fillna(value=0)
                table_df_incremental = table_df.filter(["TABLE_NM","DATABASE_NM"])
                table_df_incremental.rename(columns={"TABLE_NM": "table_nm", "DATABASE_NM": "database_nm"}, inplace = True)
                table_df_incremental.drop_duplicates(inplace = True)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Table discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("Teradata DWH tables Metadata Fetching Successful..")

                # Fetching details for column
                tera_query = teradata.query["column_discover"]
                log.info(query_log.format(tera_query))
                column_df = pd.read_sql_query(tera_query, conn)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Column discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("Teradata DWH column Metadata Fetching Successful..")

                # Fetching details for user
                tera_query = teradata.query["user_discover"]
                log.info(query_log.format(tera_query))
                user_df = pd.read_sql_query(tera_query, conn)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "User discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("Teradata DWH users Metadata Fetching Successful..")

                # Fetching details for role
                tera_query = teradata.query["role_discover"]
                log.info(query_log.format(tera_query))
                role_df = pd.read_sql_query(tera_query, conn)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Role discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("Teradata DWH roles Metadata Fetching Successful..")

                # Fetching details for view
                tera_query = teradata.query["view_discover"]
                log.info(query_log.format(tera_query))
                view_df = pd.read_sql_query(tera_query, conn)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "View discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("Teradata DWH views Metadata Fetching Successful..")

                # Fetching details for Procedures
                tera_query = teradata.query["procedure_discover_1"]
                procedure_df = pd.read_sql_query(tera_query, conn)
                df_list = procedure_df.values.tolist()
                for i in range(len(df_list)):
                    query = teradata.query["procedure_discover_2"]. \
                        format(database_name=df_list[i][1], procedure_name=df_list[i][0])
                    p_def = pd.read_sql_query(query, conn)
                    p_list = p_def.values.tolist()
                    p_text = ' '.join([str(txt) for txt in p_list])
                    p_text = p_text.replace('"', '').replace("['", "").replace("']", ""). \
                        replace("]", "").replace("[", "")
                    df_list[i].append(p_text)
                procedure_df = pd.DataFrame(df_list)
                procedure_df.rename(columns={0: "PROCEDURE_NM", 1: "DATABASE_NM", 2: "SCHEMA_NM",
                                             3: "DATABASE_VENDOR",
                                             4: "PROCEDURE_DEFINITION"},
                                    inplace=True)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Procedure discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("Teradata DWH Procedures Metadata Fetching Successful..")

                # Fetching details for macro
                tera_query = teradata.query["macro_discover"]
                log.info(query_log.format(tera_query))
                macro_df = pd.read_sql_query(tera_query, conn)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Macro discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("Teradata DWH Macro Metadata Fetching Successful..")

                # Fetching details for Hashamp
                tera_query = teradata.query["hashamp"]
                log.info(query_log.format(tera_query))
                hashamp_df = pd.read_sql_query(tera_query, conn)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Hashamp discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("Teradata DWH Hashamp Metadata Fetching Successful..")

                # Fetching details for Object Count
                tera_query = teradata.query["object_details"]
                log.info(query_log.format(tera_query))
                object_details_df = pd.read_sql_query(tera_query, conn)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Object discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("Teradata DWH object details Metadata Fetching Successful..")
                conn.close()

            try:

                # Formatting database discovery details
                if not database_df.empty:
                    database_df["DATABASE_SERVER_NM"].replace({hostname_format: hostname},
                                                              inplace=True)
                    insert_time = int(datetime.utcnow().timestamp())
                    database_df["INSERT_DTTM"] = insert_time
                    database_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                        strftime(idea_date_format)
                    database_df["BATCH_ID"] = batch_id
                    database_df["project_id"] = data["project_id"]
                    database_df.columns = database_df.columns.str.lower()
                    database_df[['occupied_space', 'allocated_space']] = \
                        database_df[['occupied_space', 'allocated_space']].fillna(value=0)
                    database_df['occupied_space'] = database_df['occupied_space'].apply(float). \
                        apply(int)
                    database_df['allocated_space'] = database_df['allocated_space'].apply(float). \
                        apply(int)
                    db.idea_database_discovery_attr.insert_many(database_df.T.to_dict().values())
                    log.info("MongoDB Database Metadata Insertion Successful..")
                else:
                    log.info("Empty record for Database Metadata")

                # Formatting table discovery details
                if not table_df.empty:
                    table_df["DATABASE_SERVER_NM"].replace({hostname_format: hostname}, inplace=True)
                    insert_time = int(datetime.utcnow().timestamp())
                    table_df["INSERT_DTTM"] = insert_time
                    table_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                        strftime(idea_date_format)
                    table_df["BATCH_ID"] = batch_id
                    table_df["project_id"] = data["project_id"]
                    table_df.columns = table_df.columns.str.lower()
                    table_df[['tbl_space_occupied_in_kbs', 'tbl_space_occupied_in_gbs',
                              'tbl_space_occupied_in_mbs', 'data_skewness_prcnt',
                              'rowsize_defined']] = table_df[['tbl_space_occupied_in_kbs',
                                                              'tbl_space_occupied_in_gbs',
                                                              'tbl_space_occupied_in_mbs',
                                                              'data_skewness_prcnt',
                                                              'rowsize_defined']].fillna(value=0)
                    table_df = table_df.astype({"tbl_space_occupied_in_kbs": float,
                                                "tbl_space_occupied_in_mbs": float,
                                                "tbl_space_occupied_in_gbs": float,
                                                "data_skewness_prcnt": float,
                                                "rowsize_defined": 'int64'})
                    db.idea_table_discovery_attr.insert_many(table_df.T.to_dict().values())
                    log.info("MongoDB Table Metadata Insertion Successful..")
                else:
                    log.info("Empty record for Table Metadata")

                # Formating the incremantal load discovery
                if db_vendor_type != "ftp":
                    incremental_df = pd.DataFrame(db.table_migration_dashboard.find({"active":True},{"database_nm":1,"table_nm":1,"_id":0}))
                    insert_df = pd.DataFrame(columns = ["table_nm","database_nm"])
                    if not incremental_df.empty:

                        # Making the dataframe of the newly added tables teradata
                        insert_df = table_df_incremental.merge(incremental_df, how = 'outer' ,indicator=True).loc[lambda x : x['_merge']=='left_only']
                        insert_df.drop(columns=['_merge'], inplace = True)

                        # Making the dataframe of removed table in the teradata
                        update_df = table_df_incremental.merge(incremental_df, how = 'outer' ,indicator=True).loc[lambda x : x['_merge']=='right_only']
                        update_df.drop(columns=['_merge'], inplace = True)

                        # Soft deleting removed tables
                        if not update_df.empty:
                            log.info("Few tables has been removed from source")
                            db_list = update_df["database_nm"].tolist()
                            tbl_list = update_df["table_nm"].tolist()
                            db.table_migration_dashboard.update({"table_nm":{"$in":tbl_list},"database_nm":{"$in":db_list}},{'$set': {'active': False,'batch_id':batch_id}})
                            log.info("Dashboard collection updated successfully")
                    else:
                        log.info("Inserting for the first time in dashboard collection")
                        insert_df = table_df_incremental


                    if not insert_df.empty:
                        log.info("Updating the dashboard collection")
                        insert_df["table_type"]= "permanent"
                        insert_df["load_type"]= "Full Load"
                        insert_df["split"]= False
                        insert_df["split_type"] = "No"
                        insert_df["active"] = True
                        insert_df["batch_id"] = batch_id

                        db.table_migration_dashboard.insert_many(insert_df.T.to_dict().values())
                        log.info("Dashboard collection updated successfully")
                    else:
                        log.info("No new tables is added in dashboard collection")


                # Formatting column discovery details
                if not column_df.empty:
                    column_df["DATA_TYPE"] = column_df["DATA_TYPE"].str.strip()
                    column_df["DATABASE_SERVER_NM"].replace({hostname_format: hostname}, inplace=True)
                    insert_time = int(datetime.utcnow().timestamp())
                    column_df["INSERT_DTTM"] = insert_time
                    column_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                        strftime(idea_date_format)
                    column_df["BATCH_ID"] = batch_id
                    column_df["project_id"] = data["project_id"]
                    column_df.columns = column_df.columns.str.lower()
                    column_df[['column_seq']] = \
                        column_df[['column_seq']].fillna(value=0)
                    column_df['column_seq'] = column_df['column_seq'].apply(int)
                    db.idea_column_discovery_attr.insert_many(column_df.T.to_dict().values())
                    log.info("MongoDB Column Metadata Insertion Successful..")
                    resp = db.idea_src_tgt_data_type_map.find({},
                                                              {"src_generic_data_type": 1,
                                                               "src_column_type_cd": 1, "_id": 0})
                    resp_df = pd.DataFrame(resp)
                    resp_df.drop_duplicates(inplace=True)
                    for ind in resp_df.index:
                        db.idea_column_discovery_attr.update_many(
                            {"batch_id": batch_id,"data_type": resp_df["src_column_type_cd"][ind]}, {
                                "$set": {"data_type": resp_df["src_generic_data_type"][ind]}})
                else:
                    log.info("Empty record for Column Metadata")

                # Formatting view discovery details
                if not view_df.empty:
                    view_df["DATABASE_SERVER_NM"].replace({hostname_format: hostname}, inplace=True)
                    insert_time = int(datetime.utcnow().timestamp())
                    view_df["INSERT_DTTM"] = insert_time
                    view_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                        strftime(idea_date_format)
                    view_df["BATCH_ID"] = batch_id
                    view_df["project_id"] = data["project_id"]
                    view_df.columns = view_df.columns.str.lower()
                    db.idea_view_discovery_attr.insert_many(view_df.T.to_dict().values())
                    log.info("MongoDB View Metadata Insertion Successful..")
                else:
                    log.info("Empty record for View Metadata")

                # Formatting role discovery details
                if not role_df.empty:
                    role_df["DATABASE_SERVER_NM"].replace({hostname_format: hostname}, inplace=True)
                    role_df["Role_Nm"] = role_df["Role_Nm"].str.strip()
                    role_df["Object_Nm"] = role_df["Object_Nm"].str.strip()
                    role_df["Database_Nm"] = role_df["Database_Nm"].str.strip()
                    insert_time = int(datetime.utcnow().timestamp())
                    role_df["INSERT_DTTM"] = insert_time
                    role_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                        strftime(idea_date_format)
                    role_df["BATCH_ID"] = batch_id
                    role_df["project_id"] = data["project_id"]
                    role_df.columns = role_df.columns.str.lower()
                    db.idea_role_discovery_attr.insert_many(role_df.T.to_dict().values())
                    log.info("MongoDB Role Metadata Insertion Successful..")
                else:
                    log.info("Empty record for Role Metadata")

                # Formatting user discovery details
                if not user_df.empty:
                    user_df["DATABASE_SERVER_NM"].replace({hostname_format: hostname}, inplace=True)
                    insert_time = int(datetime.utcnow().timestamp())
                    user_df["INSERT_DTTM"] = insert_time
                    user_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                        strftime(idea_date_format)
                    user_df["BATCH_ID"] = batch_id
                    user_df["project_id"] = data["project_id"]
                    user_df.columns = user_df.columns.str.lower()
                    db.idea_user_discovery_attr.insert_many(user_df.T.to_dict().values())
                    log.info("MongoDB User Metadata Insertion Successful..")
                else:
                    log.info("Empty record for User Metadata")

                # Formatting macro discovery details
                if not macro_df.empty:
                    insert_time = int(datetime.utcnow().timestamp())
                    macro_df["INSERT_DTTM"] = insert_time
                    macro_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                        strftime(idea_date_format)
                    macro_df["BATCH_ID"] = batch_id
                    macro_df["project_id"] = data["project_id"]
                    macro_df.columns = macro_df.columns.str.lower()
                    db.idea_macro_discovery_attr.insert_many(macro_df.T.to_dict().values())
                    log.info("MongoDB Macro Metadata Insertion Successful..")
                else:
                    log.info("Empty record for Macro Metadata")

                # Formatting procedure discovery details
                if not procedure_df.empty:
                    insert_time = int(datetime.utcnow().timestamp())
                    procedure_df["INSERT_DTTM"] = insert_time
                    procedure_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                        strftime(idea_date_format)
                    procedure_df["BATCH_ID"] = batch_id
                    procedure_df["project_id"] = data["project_id"]
                    procedure_df.columns = procedure_df.columns.str.lower()
                    db.idea_procedure_discovery_attr.insert_many(procedure_df.T.to_dict().values())
                    log.info("MongoDB Procedure Metadata Insertion Successful..")
                else:
                    log.info("Empty record for Procedure Metadata")

                # Formatting HASHAMP discovery details
                if not hashamp_df.empty:
                    insert_time = int(datetime.utcnow().timestamp())
                    hashamp_df["INSERT_DTTM"] = insert_time
                    hashamp_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                        strftime(idea_date_format)
                    hashamp_df["BATCH_ID"] = batch_id
                    hashamp_df["project_id"] = data["project_id"]
                    hashamp_df.columns = hashamp_df.columns.str.lower()
                    hashamp_df[hashamp_function] = hashamp_df[hashamp_function].apply(int)
                    db.idea_hashamp_discovery_attr.insert_many(hashamp_df.T.to_dict().values())
                    log.info("MongoDB #amp Metadata Insertion Successful..")
                else:
                    log.info("Empty record for #amp Metadata")

                # Formatting object discovery details
                if not object_details_df.empty:
                    user_count = len(
                        db.idea_user_discovery_attr.find({'batch_id': batch_id}).distinct(
                            'user_nm'))
                    role_count = len(
                        db.idea_role_discovery_attr.find({'batch_id': batch_id}).distinct(
                            'role_nm'))
                    df = pd.DataFrame({"OBJECT_COUNT": [user_count, role_count],
                                       "OBJECT_KIND": ["USERS", 'ROLES']})
                    object_details_df = object_details_df.append(df, ignore_index=True)
                    object_details_df['DATABASE_VENDOR'] = 'TERADATA'
                    object_details_df['DATABASETYPE'] = 'MPP'
                    object_details_df["DATABASE_SERVER_NM"].replace({hostname_format: hostname},
                                                                    inplace=True)
                    insert_time = int(datetime.utcnow().timestamp())
                    object_details_df["INSERT_DTTM"] = insert_time
                    object_details_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                        strftime(idea_date_format)
                    object_details_df["BATCH_ID"] = batch_id
                    object_details_df["project_id"] = data["project_id"]
                    object_details_df.columns = object_details_df.columns.str.lower()
                    object_details_df[['object_count']] = \
                        object_details_df[['object_count']].fillna(value=0)
                    object_details_df = object_details_df.astype({"object_count": int})
                    db.idea_object_details_discovery_attr.insert_many(object_details_df.T.to_dict().
                                                                      values())
                    log.info("MongoDB object_details Metadata Insertion Successful..")
                else:
                    log.info("Empty record for object_details Metadata")

            except KeyError:
                log.error(traceback.format_exc())
                status = {"message": "The file either doesn't consist header or "
                                     "is not in the correct format"}
                job_status = "Fail"
                end_time = int(datetime.utcnow().timestamp())
                end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)

                # Populating details on ABCR
                if config["ABCR"]["flag"] == "Y":
                    abcr_status = abcr_job_run("", end_time,
                                               status,
                                               job_register_df['job_id'], job_run_id, job_name,
                                               "MigrationSF-discovery", {"message": "Job Failed"},
                                               run_by, creation_time, job_status, config['ABCR']['discover'], "")
                    if abcr_status == "Fail":
                        db.job_run.update_one({"job_id": data["job_id"], "job_run_id": job_run_id},
                                              {"$set": {"status": job_status, "end_time": end_time,
                                                        "end_time_str": end_time_str}})
                        return
                db.job_run.update_one({"job_id": data["job_id"], "job_run_id": job_run_id},
                                      {"$set": {"status": job_status, "end_time": end_time,
                                                "end_time_str": end_time_str}})
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Discovery failed!", "link_service_id": link_service_id, "pipeline_id": pipeline_id}, user_id)
                return

        # Making connection string for snowflake dwh
        if db_vendor == 'snowflake':
            log.info("Database Vendor Encountered: Snowflake")
            sf_conn_string = config[db_vendor]["conn"].format(hostname=hostname, uid=username,
                                                              pwd=password, warehouse=
                                                              config["snowflake"]["discover_dwh"])

            # Connecting to snowflake
            try:
                conn = pyodbc.connect(sf_conn_string)
                log.info("Snowflake Connection Established..")
            except pyodbc.Error as exception:
                log.error(exception)
                job_status = "Fail"
                end_time = int(datetime.utcnow().timestamp())
                end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)

                # Populating details on ABCR
                if config["ABCR"]["flag"] == "Y":
                    abcr_status = abcr_job_run("", end_time,
                                               {"message": "Snowflake Connection failed!"},
                                               job_register_df['job_id'], job_run_id, job_name,
                                               "MigrationSF-discovery",
                                               {"message": job_run_failed}, run_by, creation_time,
                                               job_status, config['ABCR']['discover'], "")
                    if abcr_status == "Fail":
                        db.job_run.update_one({"job_id": data["job_id"], "job_run_id": job_run_id},
                                              {"$set": {"status": job_status, "end_time": end_time,
                                                        "end_time_str": end_time_str}})
                        return

                db.job_run.update_one({"job_id": data["job_id"], "job_run_id": job_run_id},
                                      {"$set": {"status": job_status, "end_time": end_time,
                                                "end_time_str": end_time_str}})

                return

            # Making database discovery
            table_count, view_count, procedure_count, user_count, role_count = 0, 0, 0, 0, 0
            snow_query = snowflake.query["database_discover"].format(hostname=hostname)
            database_df = pd.read_sql_query(snow_query, conn)
            log.info("Snowflake Database Metadata Fetching Successful..")

            # Formatting database discovery details
            if not database_df.empty:
                database_df.rename(columns={"DATABASE_NAME": "DATABASE_NM"}, inplace=True)
                insert_time = int(datetime.utcnow().timestamp())
                database_df["INSERT_DTTM"] = insert_time
                database_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                    strftime(idea_date_format)
                database_df["BATCH_ID"] = batch_id
                database_df["project_id"] = data["project_id"]
                database_df.columns = database_df.columns.str.lower()
                database_name_df = database_df["database_nm"].copy()
                db.idea_database_discovery_attr.insert_many(database_df.T.to_dict().values())
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Database discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("MongoDB Database Metadata Insertion Successful..")
            else:
                log.info("Empty record for Database Metadata")

            # Making table discovery
            df = pd.DataFrame()
            for database in database_name_df:
                snow_query = snowflake.query["table_discover_1"].format(database=database,
                                                                        hostname=hostname)
                df1 = pd.read_sql_query(snow_query, conn)
                df = df.append(df1, ignore_index=True)

            # Formatting table discovery details
            if not df.empty:
                insert_time = int(datetime.utcnow().timestamp())
                df["INSERT_DTTM"] = insert_time
                df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                    strftime(idea_date_format)
                df["BATCH_ID"] = batch_id
                df["project_id"] = data["project_id"]
                ref_df = pd.DataFrame(columns=["DATABASE_NM", "CHILD_TBL_INFO", "PARENT_TBL_INFO",
                                               "TABLE_NM"])
                for database in database_name_df:
                    db_query = snowflake.query["table_discover_2"].format(database=database)
                    db_df = pd.read_sql_query(db_query, conn)
                    ref_df = ref_df.append(db_df)
                    ref_df.drop_duplicates(inplace=True)

                left_df = df.set_index(['DATABASE_NM', 'TABLE_NM'])
                right_df = ref_df.set_index(['DATABASE_NM', 'TABLE_NM'])
                df = left_df.reindex(columns=left_df.columns)
                df.update(right_df)
                df.reset_index(inplace=True)
                log.info("Snowflake Table Metadata Fetching Successful..")
                df.rename(columns={"INDEX_DEFINED": "INDEXES_DEFINED",
                                   "INDEX_NAME": "INDEX_OBJECT_NM",
                                   "CONSTRAINT_DEFINED": "CONSTRAINTS_DEFINED"}, inplace=True)

                for index, row in df.iterrows():
                    ddl_query_0 = snowflake.query["table_ddl_1"]. \
                        format(database_name=row.DATABASE_NM,schema_name=row.TBL_SCHEMA_NM)
                    cursor = conn.cursor()
                    cursor.execute(ddl_query_0)
                    ddl_query_1 = snowflake.query["table_ddl_2"]. \
                        format(table_name=row.TABLE_NM)
                    ddl_df = pd.read_sql_query(ddl_query_1, conn)
                    df.loc[index, "definition"] = ddl_df.iloc[0][0]
                df.replace({pd.NaT: None}, inplace=True)

                df.columns = df.columns.str.lower()
                db.idea_table_discovery_attr.insert_many(df.T.to_dict().values())
                table_count_df = df[['database_nm', 'tbl_schema_nm', 'table_nm']].copy().drop_duplicates()
                table_count = len(table_count_df)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Table discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("MongoDB Table Metadata Insertion Successful..")
            else:
                log.info("Empty record for Table Metadata")

            # Making column discovery
            df = pd.DataFrame()
            for database in database_name_df:
                snow_query = snowflake.query["column_discover"]. \
                    format(database=database, hostname=hostname)
                df1 = pd.read_sql_query(snow_query, conn)
                df = df.append(df1, ignore_index=True)

            # Formatting column discovery details
            if not df.empty:
                insert_time = int(datetime.utcnow().timestamp())
                df["INSERT_DTTM"] = insert_time
                df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                    strftime(idea_date_format)
                df["BATCH_ID"] = batch_id
                df["project_id"] = data["project_id"]
                df.columns = df.columns.str.lower()
                db.idea_column_discovery_attr.insert_many(df.T.to_dict().values())
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Column discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("MongoDB Column Metadata Insertion Successful..")
            else:
                log.info("Empty record for Column Metadata")

            # Making warehouse discovery
            snow_query1 = snowflake.query["warehouse_discovery_q1"]
            wh_result1 = pd.read_sql_query(snow_query1, conn)
            log.info("Snowflake Warehouse Metadata Fetching Query 1 Executed Successfully..")
            snow_query2 = snowflake.query["warehouse_discovery_q2"]
            wh_result2 = pd.read_sql_query(snow_query2, conn)
            log.info("Snowflake Warehouse Metadata Fetching Query 2 Executed Successfully..")
            wh_result = wh_result1.merge(wh_result2, left_on='name', right_on='WAREHOUSE_NAME',
                                         how='left')
            wh_result = wh_result[["WAREHOUSE_NAME", "state", "type", "size", "min_cluster_count",
                                   "max_cluster_count",
                                   "started_clusters", "running", "queued", "is_default",
                                   "is_current", "auto_suspend", "auto_resume", "available",
                                   "provisioning", "quiescing", "other", "created_on", "resumed_on",
                                   "updated_on", "owner", "comment", "resource_monitor", "actives",
                                   "pendings", "failed", "suspended", "uuid", "scaling_policy",
                                   "CREDITS_USED", "CREDITS_USED_COMPUTE",
                                   "CREDITS_USED_CLOUD_SERVICES"]].replace("null", "")
            log.info("Snowflake Warehouse Metadata Fetching Successful..")

            # Formatting warehouse discovery details
            if not wh_result.empty:
                insert_time = int(datetime.utcnow().timestamp())
                wh_result["INSERT_DTTM"] = insert_time
                wh_result["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                    strftime(idea_date_format)
                wh_result["BATCH_ID"] = batch_id
                wh_result["project_id"] = data["project_id"]
                wh_result.columns = wh_result.columns.str.lower()
                db.idea_warehouse_discovery_attr.insert_many(wh_result.T.to_dict().values())
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Warehouse discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("MongoDB Warehouse Metadata Insertion Successful..")
            else:
                log.info("Empty record for Warehouse Metadata")

            # Making user discovery
            # snow_query = snowflake.query["user_discover"].format(hostname=hostname)
            # df = pd.read_sql_query(snow_query, conn)
            # log.info("Snowflake User Metadata Fetching Successful..")

            # # Formatting user discovery details
            # if not df.empty:
            #     df.rename(columns={"ROLENAME": "Role_Nm"}, inplace=True)
            #     insert_time = int(datetime.utcnow().timestamp())
            #     df["INSERT_DTTM"] = insert_time
            #     df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
            #         strftime(idea_date_format)
            #     df["BATCH_ID"] = batch_id
            #     df["project_id"] = data["project_id"]
            #     df.columns = df.columns.str.lower()
            #     db.idea_user_discovery_attr.insert_many(df.T.to_dict().values())
            #     log.info("MongoDB User Metadata Insertion Successful..")
            #     user_count_df = df[['user_nm']].copy().drop_duplicates()
            #     user_count = len(user_count_df)
            #     if socket_flag:
            #         send_message("sf_discover_run", {"status": "User discovery successful..", "pipeline_id": pipeline_id}, user_id)
            # else:
            #     log.info("Empty record for User Metadata")

            # Making View discovery
            df = pd.DataFrame()
            for database in database_name_df:
                snow_query = snowflake.query["view_discover"] \
                    .format(database=database, hostname=hostname)
                df1 = pd.read_sql_query(snow_query, conn)
                df = df.append(df1, ignore_index=True)

            # Formatting the view discovery details
            if not df.empty:
                insert_time = int(datetime.utcnow().timestamp())
                df["INSERT_DTTM"] = insert_time
                df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                    strftime(idea_date_format)
                df["BATCH_ID"] = batch_id
                df["project_id"] = data["project_id"]
                df.columns = df.columns.str.lower()
                db.idea_view_discovery_attr.insert_many(df.T.to_dict().values())
                log.info("MongoDB View Metadata Insertion Successful..")
                view_count_df = df[['database_nm', 'schema_nm', 'view_nm']].copy().drop_duplicates()
                view_count = len(view_count_df)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "View discovery successful..", "pipeline_id": pipeline_id}, user_id)
            else:
                log.info("Empty record for View Metadata")

            # Making Role discovery
            # snow_query = snowflake.query["role_discover"].format(hostname=hostname)
            # df = pd.read_sql_query(snow_query, conn)
            # log.info("Snowflake Role Metadata Fetching Successful..")

            # # Formatting role discovery details
            # if not df.empty:
            #     df.rename(columns={"ROLE_NAME": "Role_NM"}, inplace=True)
            #     insert_time = int(datetime.utcnow().timestamp())
            #     df["INSERT_DTTM"] = insert_time
            #     df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
            #         strftime(idea_date_format)
            #     df["BATCH_ID"] = batch_id
            #     df["project_id"] = data["project_id"]
            #     df.columns = df.columns.str.lower()
            #     db.idea_role_discovery_attr.insert_many(df.T.to_dict().values())
            #     log.info("MongoDB Role Metadata Insertion Successful..")
            #     role_count_df = df[['role_nm']].copy().drop_duplicates()
            #     role_count = len(role_count_df)
            #     if socket_flag:
            #         send_message("sf_discover_run", {"status": "Role discovery successful..", "pipeline_id": pipeline_id}, user_id)
            # else:
            #     log.info("Empty record for Role Metadata")

            # Making procedures discovery
            df = pd.DataFrame(columns=["PROCEDURE_NM", "DATABASE_NM", "SCHEMA_NM",
                                       "PROCEDURE_DEFINITION"])
            for database in database_name_df:
                db_query = snowflake.query["procedure_discover"].format(database=database)
                db_df = pd.read_sql_query(db_query, conn)
                df = df.append(db_df)
            log.info("Snowflake Procedure Metadata Fetching Successful..")

            # Formatting procedure discovery details
            if not df.empty:
                insert_time = int(datetime.utcnow().timestamp())
                df["INSERT_DTTM"] = insert_time
                df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                    strftime(idea_date_format)
                df["BATCH_ID"] = batch_id
                df["project_id"] = project_id
                df.columns = df.columns.str.lower()
                db.idea_procedure_discovery_attr.insert_many(df.T.to_dict().values())
                log.info("MongoDB Procedure Metadata Insertion Successful..")
                proc_count_df = df[
                    ['database_nm', 'schema_nm', 'procedure_nm']].copy().drop_duplicates()
                procedure_count = len(proc_count_df)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Procedure discovery successful..", "pipeline_id": pipeline_id}, user_id)
            else:
                log.info("Empty record for Procedure Metadata")

            # Making schema discovery
            df = pd.DataFrame()
            for database in database_name_df:
                snow_query = snowflake.query["schema_discover"].format(database=database)
                df1 = pd.read_sql_query(snow_query, conn)
                df = df.append(df1, ignore_index=True)

            # Formatting schema discovery details
            if not df.empty:
                insert_time = int(datetime.utcnow().timestamp())
                df["INSERT_DTTM"] = insert_time
                df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                    strftime(idea_date_format)
                df["BATCH_ID"] = batch_id
                df["project_id"] = data["project_id"]
                df.columns = df.columns.str.lower()
                db.idea_schema_discovery_attr.insert_many(df.T.to_dict().values())
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Schema discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("MongoDB Schema Metadata Insertion Successful..")
            else:
                log.info("Empty record for Schema Metadata")

            # Making objects discovery
            object_details_df = pd.DataFrame(
                {"OBJECT_COUNT": [table_count, view_count, procedure_count, user_count, role_count],
                 "OBJECT_KIND": ["TABLES", "VIEWS", "STORED PROCEDURE", "USERS", 'ROLES']})

            # Formating object discovery details
            if not object_details_df.empty:
                insert_time = int(datetime.utcnow().timestamp())
                object_details_df["INSERT_DTTM"] = insert_time
                object_details_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time).\
                    strftime(idea_date_format)
                object_details_df["BATCH_ID"] = batch_id
                object_details_df["project_id"] = data["project_id"]
                object_details_df['DATABASE_VENDOR'] = 'SNOWFLAKE'
                object_details_df['DATABASETYPE'] = 'MPP'
                object_details_df['DATABASE_SERVER_NM'] = hostname
                object_details_df.columns = object_details_df.columns.str.lower()
                db.idea_object_details_discovery_attr.insert_many(object_details_df.T.to_dict().
                                                                  values())
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Object discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("MongoDB Objects Details Metadata Insertion Successful..")
            else:
                log.info("Empty record for Objects Details Metadata")

            # Materialized Views
            database_schema = db.idea_schema_discovery_attr.find({"batch_id": batch_id})
            for schema in database_schema:
                cursor = conn.cursor()
                cursor.execute(snowflake.schema_migration['use_db'].format(schema_name=schema['database_name']))
                cursor.execute(snowflake.schema_migration['use_schema'].format(schema_name=schema['schema_name']))
                materialized_df = pd.read_sql_query(snowflake.query["materialized_views"], conn)[['name', 'is_secure']]
                materialized_df = materialized_df.loc[materialized_df['is_secure'] == 'true']
                if not materialized_df.empty:
                    materialized_df = materialized_df[['name']]
                    materialized_df.columns = ['view_nm']
                    insert_time = int(datetime.utcnow().timestamp())
                    materialized_df["DATABASE_NM"] = schema['database_name']
                    materialized_df["SCHEMA_NM"] = schema['schema_name']
                    materialized_df["INSERT_DTTM"] = insert_time
                    materialized_df["INSERT_DTTM_STR"] = datetime.fromtimestamp(insert_time). \
                        strftime(idea_date_format)
                    materialized_df["BATCH_ID"] = batch_id
                    materialized_df["project_id"] = data["project_id"]
                    materialized_df.columns = materialized_df.columns.str.lower()
                    db.idea_materialized_view_discovery_attr.insert_many(materialized_df.T.to_dict().values())
            if socket_flag:
                send_message("sf_discover_run", {"status": "Materialized view discovery successful..", "pipeline_id": pipeline_id}, user_id)
            log.info("Materialized views discovery successful..")
            
            # Shares & Readers
            try:
                # Fetch previous discovery details
                show_share_df = pd.read_sql_query(snowflake.query["share_discover_1"], conn)
                previous_shares = list(db.idea_data_sharing_shares.find({"link_service_id":link_service_id,
                                                                        "active":True}, {"_id": 0}))
                previous_readers = list(db.idea_data_sharing_readers.find({"link_service_id":link_service_id,
                                                                            "active":True}, {"_id": 0}))
                previous_linkage = list(db.idea_data_sharing_linkage.find({"link_service_id":link_service_id,
                                                                            "active":True}, {"_id": 0}))
                idea_shares = list(db.idea_data_sharing_shares.find({"link_service_id":link_service_id,
                                                                    "active":True, "creator":"IDEA"},
                                                                    {"_id": 0, "share_name": 1, "created_by": 1}))
                idea_readers = list(db.idea_data_sharing_readers.find({"link_service_id":link_service_id,
                                                                    "active":True, "creator":"IDEA"},
                                                                    {"_id": 0, "locator": 1, "created_by": 1}))
                new_shares = []
                new_readers = []
                new_linkage = []

                # Share discovery
                show_share_df = show_share_df[show_share_df['kind']=='OUTBOUND']
                show_reader_df = pd.read_sql_query(snowflake.query["reader_discover"], conn)
                instance_readers = list(show_reader_df['locator'])
                if not show_share_df.empty:
                    for share in show_share_df['name']:
                        describe_share_df = pd.read_sql_query(snowflake.query["share_discover_2"].format(share=share), conn)
                        created_at_str = show_share_df[show_share_df['name']==share]['created_on'][show_share_df[show_share_df['name']==share].index.tolist()[0]]
                        share_data = {
                            "share_name": show_share_df[show_share_df['name']==share]['name'][show_share_df[show_share_df['name']==share].index.tolist()[0]].split(".")[1],
                            "database": "",
                            "data": [],
                            "active": True,
                            "link_service_id": link_service_id,
                            "created_by": "Snowflake User",
                            "modified_by": "",
                            "created_at": int(created_at_str.timestamp()),
                            "created_at_str": created_at_str,
                            "creator": "Snowflake"
                        }

                        # Assigned consumers with share
                        consumers = show_share_df[show_share_df['name']==share]['to'][show_share_df[show_share_df['name']==share].index.tolist()[0]].split(",")
                        if consumers != ['']:
                            reader_accounts = []
                            full_accounts = []
                            for consumer in consumers:
                                if consumer in instance_readers:
                                    reader_accounts.append(consumer)
                                else:
                                    full_accounts.append(consumer)
                            
                            # Assigned readers with share
                            for reader in reader_accounts:
                                linkage = {
                                    "share_name": share_data['share_name'],
                                    "reader_locator": reader,
                                    "link_service_id": link_service_id,
                                    "active": True
                                }
                                new_linkage.append(linkage)

                            # Assigned full accounts with share
                            for full_account in full_accounts:
                                linkage = {
                                    "share_name": share_data['share_name'],
                                    "full_account": full_account,
                                    "link_service_id": link_service_id,
                                    "active": True
                                }
                                new_linkage.append(linkage)

                        # Assigned DB objects to share
                        if not describe_share_df.empty:
                            share_data['database'] = describe_share_df['name'][0]
                            data = {
                                "schema": "",
                                "tables": [],
                                "secure_views": []
                            }
                            for index, row in describe_share_df.iterrows():
                                if row['kind']=='SCHEMA':
                                    if data not in share_data['data'] and data['schema'] != "":
                                        share_data['data'].append(data)
                                        data = {
                                            "schema": "",
                                            "tables": [],
                                            "secure_views": []
                                        }
                                    data['schema'] = row['name'].split(".")[1]
                                elif row['kind'] == 'VIEW':
                                    data['secure_views'].append(row['name'].split(".")[2].replace('"',''))
                                elif row['kind'] == 'TABLE':
                                    data['tables'].append(row['name'].split(".")[2])
                            if data not in share_data['data'] and data['schema'] != "":
                                share_data['data'].append(data)
                        new_shares.append(share_data)
                
                # Updating IDEA metadata
                db.idea_data_sharing_shares.delete_many({})
                for share in new_shares:
                    db.idea_data_sharing_shares.insert_one(share)
                    insert_time = int(datetime.utcnow().timestamp())
                    share["insert_dttm"] = insert_time
                    share["insert_dttm_str"] = datetime.fromtimestamp(insert_time).\
                        strftime(idea_date_format)
                    share["batch_id"] = batch_id
                    share["project_id"] = project_id
                    db.idea_share_discovery_attr.insert_one(share)

                # Preserving IDEA creator flag
                for share in idea_shares:
                    db.idea_data_sharing_shares.update_one({"share_name":share['share_name']},
                                                        {"$set": {"creator": "IDEA",
                                                        "created_by": share['created_by']}})
                    db.idea_share_discovery_attr.update_one({"share_name":share['share_name']},
                                                        {"$set": {"creator": "IDEA",
                                                        "created_by": share['created_by']}})

                # Reader discovery
                if not show_reader_df.empty:
                    for index, row in show_reader_df.iterrows():
                        reader_data = {
                            "reader_name": row['name'],
                            "cloud": row['cloud'],
                            "region": row['region'],
                            "locator": row['locator'],
                            "url": row['url'],
                            "active": True,
                            "link_service_id": link_service_id,
                            "created_by": "Snowflake User",
                            "created_at": int(row['created_on'].timestamp()),
                            "created_at_str": row['created_on'],
                            "creator": "Snowflake"
                        }
                        new_readers.append(reader_data)
                
                # Updating IDEA metadata
                db.idea_data_sharing_readers.delete_many({})
                for reader in new_readers:
                    db.idea_data_sharing_readers.insert_one(reader)
                    insert_time = int(datetime.utcnow().timestamp())
                    reader["insert_dttm"] = insert_time
                    reader["insert_dttm_str"] = datetime.fromtimestamp(insert_time).\
                        strftime(idea_date_format)
                    reader["batch_id"] = batch_id
                    reader["project_id"] = project_id
                    db.idea_reader_discovery_attr.insert_one(reader)

                # Preserving IDEA creator flag
                for reader in idea_readers:
                    db.idea_data_sharing_readers.update_one({"locator":reader['locator']},
                                                            {"$set": {"creator": "IDEA",
                                                            "created_by": reader['created_by']}})
                    db.idea_reader_discovery_attr.update_one({"locator":reader['locator']},
                                                            {"$set": {"creator": "IDEA",
                                                            "created_by": reader['created_by']}})
                
                # Updating IDEA linkage metadata
                db.idea_data_sharing_linkage.delete_many({})
                for linkage in new_linkage:
                    db.idea_data_sharing_linkage.insert_one(linkage)
                    insert_time = int(datetime.utcnow().timestamp())
                    linkage["insert_dttm"] = insert_time
                    linkage["insert_dttm_str"] = datetime.fromtimestamp(insert_time).\
                        strftime(idea_date_format)
                    linkage["batch_id"] = batch_id
                    linkage["project_id"] = project_id
                    db.idea_linkage_discovery_attr.insert_one(linkage)
                if socket_flag:
                    send_message("sf_discover_run", {"status": "Share & reader discovery successful..", "pipeline_id": pipeline_id}, user_id)
                log.info("Share & Reader discovery successful..")
            except Exception as e_error:
                # Populating previous discovery & raising exception
                db.idea_data_sharing_shares.delete_many({})
                for share in previous_shares:
                    db.idea_data_sharing_shares.insert_one(share)
                db.idea_data_sharing_readers.delete_many({})
                for reader in previous_readers:
                    db.idea_data_sharing_readers.insert_one(reader)
                db.idea_data_sharing_linkage.delete_many({})
                for linkage in previous_linkage:
                    db.idea_data_sharing_linkage.insert_one(linkage)
                raise e_error

        # Update with batch_id
        end_time = int(datetime.utcnow().timestamp())
        end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
        job_status = "Success"

        # Populating details on ABCR
        if config["ABCR"]["flag"] == "Y":
            abcr_status = abcr_job_run("", end_time, "Other",
                                       job_register_df['job_id'], job_run_id, job_name,
                                       "MigrationSF-discovery",
                                       {"message": "Discover success", "batch_id": batch_id},
                                       run_by, creation_time, job_status, config['ABCR']['discover'], batch_id)
            if abcr_status == "Fail":
                db.job_run.update_one({"job_id": job_id, "job_run_id": job_run_id},
                                      {"$set": {"status": job_status, "end_time": end_time,
                                                "end_time_str": end_time_str}})
                return
        db.job_run.update_one({"job_id": job_id, "job_run_id": job_run_id},
                              {"$set": {"status": job_status, "end_time": end_time,
                                        "end_time_str": end_time_str, "batch_id": batch_id,
                                        "link_service_id": link_service_id,
                                        "link_service_type": link_service_type}})
        if socket_flag:
            send_message("sf_discover_run", {"status": "Discovery successful!", "link_service_id": link_service_id, "pipeline_id": pipeline_id}, user_id)

    except Exception:
        log.error(traceback.format_exc())
        status = {"message": "Something went wrong. Please try later"}
        job_status = "Fail"
        end_time = int(datetime.utcnow().timestamp())
        end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
        db.job_run.update_one({"job_id": job_id, "job_run_id": job_run_id},
                              {"$set": {"status": job_status, "end_time": end_time,
                                        "end_time_str": end_time_str}})

        # Populating details on ABCR
        if config["ABCR"]["flag"] == "Y":
            abcr_status = abcr_job_run("", end_time, status,
                                       job_register_df['job_id'], job_run_id, job_name,
                                       "MigrationSF-discovery",
                                       {"message": "Job Failed"}, run_by, creation_time,
                                       job_status, config['ABCR']['discover'], "")
            if abcr_status == "Fail":
                db.job_run.update_one({"job_id": job_id, "job_run_id": job_run_id},
                                      {"$set": {"status": job_status, "end_time": end_time,
                                                "end_time_str": end_time_str}})
                return
        db.job_run.update_one({"job_id": job_id, "job_run_id": job_run_id},
                              {"$set": {"status": job_status, "end_time": end_time,
                                        "end_time_str": end_time_str}})
        if socket_flag:
            send_message("sf_discover_run", {"status": "Discovery failed!", "link_service_id": link_service_id, "pipeline_id": pipeline_id}, user_id)
        return

    log.info("END")
