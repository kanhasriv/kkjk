query = {
    "database_discover": """SELECT 'SNOWFLAKE' AS DATABASE_VENDOR 
      ,'{hostname}' AS DATABASE_SERVER_NM
      ,'MPP' AS DATABASE_TYPE
      ,dbs.DATABASE_NAME AS DATABASE_NAME
      , current_version() AS DATABASE_VERSION
      ,SUM(IFNULL(ACTIVE_BYTES,0)+IFNULL(TIME_TRAVEL_BYTES,0)+IFNULL(FAILSAFE_BYTES,0)+IFNULL(RETAINED_FOR_CLONE_BYTES,0)) AS OCCUPIED_SPACE
      ,NULL AS Allocated_Space,
      'Byte' AS SPACE_MEASURE_IN
      ,1 AS BATCH_ID
FROM "SNOWFLAKE"."INFORMATION_SCHEMA"."DATABASES" dbs
LEFT JOIN "SNOWFLAKE"."INFORMATION_SCHEMA"."TABLE_STORAGE_METRICS" stg
ON dbs.DATABASE_NAME = STG.TABLE_CATALOG
WHERE dbs.DATABASE_NAME NOT IN ('SNOWFLAKE','SNOWFLAKE_SAMPLE_DATA','UTIL_DB','DEMO_DB','IDEA_DATABASE')
GROUP BY dbs.DATABASE_NAME,STG.TABLE_CATALOG;
""",

    "table_discover_1": """SELECT DATABASE_VENDOR, DATABASE_SERVER_NM, DATABASE_NM, TABLE_NM, TBL_SCHEMA_NM, NULL AS LAST_ACCESS_TM,
TBL_CREATED_BY,TBL_SPACE_OCCUPIED_IN_KBS, TBL_SPACE_OCCUPIED_IN_MBS, TBL_SPACE_OCCUPIED_IN_GBS,
NULL AS DATA_DISTRIBUTION_TYPE, NULL AS DATA_DISTRIBUTION_KEYS, NULL AS INDEX_NAME,
NULL AS DATA_SKEWNESS_PRCNT,NULL AS PARTITION_DEFINED,NULL AS INDEX_TYPE,NULL AS INDEX_DEFINED,
CONSTRAINT_TYPE,NULL AS CONSTRAINT_DEFINED,CHILD_TBL_INFO,PARENT_TBL_INFO,ROWSIZE_DEFINED,
NUM_OF_RECORDS,NULL AS DATA_PROTECTION_JOURNAL_FLAG,NULL AS DATA_PROTECTION_FALLBACK_FLAG, 1 AS BATCH_ID 
from (WITH parent_child_r as (select tc_child.table_name as child_table,tc_parent.table_name as parent_table 
from {database}.INFORMATION_SCHEMA.referential_constraints rc
left join {database}.INFORMATION_SCHEMA.table_constraints tc_child
on rc.CONSTRAINT_NAME=tc_child.CONSTRAINT_NAME
left join {database}.INFORMATION_SCHEMA.table_constraints tc_parent
on rc.UNIQUE_CONSTRAINT_NAME=tc_parent.CONSTRAINT_NAME),
rowdet as (SELECT SUM(IFNULL(CHARACTER_MAXIMUM_LENGTH, 0)+IFNULL(NUMERIC_PRECISION, 0)+IFNULL(DATETIME_PRECISION, 0)) as row_length,
table_name,  table_schema as table_schema  ,table_catalog as database_nm
from {database}.INFORMATION_SCHEMA.columns group by table_schema,table_name,table_catalog ) SELECT DISTINCT 'SNOWFLAKE' AS DATABASE_VENDOR, 
'{hostname}' AS DATABASE_SERVER_NM,
tbl.table_catalog AS DATABASE_NM, 
tbl.Table_Name AS TABLE_NM,
tbl.Table_Schema AS TBL_SCHEMA_NM,
tbl.table_owner TBL_CREATED_BY,
CAST((tbl.BYTES/1024) AS decimal(16, 3)) AS TBL_Space_Occupied_In_KBs,
CAST((tbl.BYTES/(1024*1024)) AS decimal(16, 3)) AS TBL_Space_Occupied_In_MBs,
CAST((tbl.BYTES/(1024*1024*1024)) AS decimal(16, 3)) AS TBL_Space_Occupied_In_GBs,
cntrs.CONSTRAINT_TYPE AS  CONSTRAINT_TYPE,
pcr.child_table as child_tbl_info,
cpr.parent_table as parent_tbl_info,
IFNULL(rowdet.row_length,0) AS ROWSIZE_DEFINED,
ROW_COUNT AS NUM_OF_RECORDS
FROM  {database}.INFORMATION_SCHEMA.TABLES tbl LEFT JOIN {database}.INFORMATION_SCHEMA.TABLE_CONSTRAINTS cntrs
ON cntrs.table_name = tbl.table_name 
--AND cntrs.constraint_catalog = tbl.table_catalog
--AND cntrs.constraint_schema = tbl.table_schema
LEFT JOIN parent_child_r pcr
ON  tbl.table_name=pcr.parent_table 
LEFT JOIN parent_child_r cpr
ON  tbl.table_name=cpr.parent_table 
LEFT JOIN rowdet
ON rowdet.table_name = tbl.table_name
AND rowdet.table_schema= tbl.table_schema
AND rowdet.database_nm = tbl.table_catalog 
AND rowdet.database_nm NOT IN ('SNOWFLAKE','SNOWFLAKE_SAMPLE_DATA','UTIL_DB','DEMO_DB')
where tbl.table_type = 'BASE TABLE'
AND tbl.table_schema = rowdet.table_schema) as x
""",

    "table_discover_2": """WITH ref_tbl as (SELECT tc_child.table_name AS child_table,tc_parent.table_name
AS parent_table from {database}.INFORMATION_SCHEMA.referential_constraints rc
LEFT JOIN {database}.INFORMATION_SCHEMA.table_constraints tc_child 
on rc.CONSTRAINT_NAME=tc_child.CONSTRAINT_NAME 
LEFT JOIN {database}.INFORMATION_SCHEMA.table_constraints tc_parent
on rc.UNIQUE_CONSTRAINT_NAME=tc_parent.CONSTRAINT_NAME) 
SELECT '{database}' AS DATABASE_NM, 
chldtbl.child_table AS CHILD_TBL_INFO ,
prnttbl.parent_table AS PARENT_TBL_INFO,
tbl.table_name AS TABLE_NM 
FROM {database}.INFORMATION_SCHEMA.TABLES tbl
LEFT JOIN ref_tbl AS chldtbl
ON tbl.table_name=chldtbl.parent_table
LEFT JOIN ref_tbl AS prnttbl on tbl.table_name=prnttbl.child_table
WHERE CHILD_TBL_INFO IS NOT NULL OR PARENT_TBL_INFO IS NOT NULL
""",
    "table_ddl_1": """ USE {database_name}.{schema_name};
    """,
    "table_ddl_2": """ SELECT get_ddl('table', '{table_name}') as definition;
    """,
    "column_discover": """SELECT 'SNOWFLAKE' AS DATABASE_VENDOR,
'{hostname}' AS DATABASE_SERVER_NM,
TABLE_CATALOG AS DATABASE_NM,
TABLE_NAME AS TABLE_NM,
TABLE_SCHEMA AS SCHEMA_NM,
COLUMN_NAME AS COLUMN_NM,
DATA_TYPE AS DATA_TYPE,
ORDINAL_POSITION AS COLUMN_SEQ,
IFNULL(CHARACTER_MAXIMUM_LENGTH,0) AS COLUMN_LENGTH,
NULL AS CHAR_TYPE,
IS_NULLABLE AS NULLABLE_IND,
NULL AS DATA_DISTRIBUTION_IND,
NULL AS PARTITION_IND,
NULL AS COLUMN_CONSTRAINTS_DEFINED,
COMMENT AS COMMENT_STRING,
NULL AS COMPRESS_VAL_LIST,
COLUMN_DEFAULT AS DEFAULT_VAL_LIST,
1 AS BATCH_ID /* THIS WILL BE PART OF ABCR BATCH_ID GENERATION */
FROM {database}.information_schema.COLUMNS
WHERE SCHEMA_NM NOT IN ('INFORMATION_SCHEMA');
""",

    "warehouse_discovery_q1": """SHOW WAREHOUSES;""",

    "warehouse_discovery_q2": """select warehouse_name,sum(credits_used) as credits_used,
sum(credits_used_compute) as credits_used_compute,
sum(credits_used_cloud_services) as credits_used_cloud_services
from snowflake.account_usage.WAREHOUSE_METERING_HISTORY
WHERE  warehouse_name not IN ('CLOUD_SERVICES_ONLY')
group by warehouse_name""",

    "user_discover": """select 'SNOWFLAKE' AS DATABASE_VENDOR,
'{hostname}' AS DATABASE_SERVER_Nm,
u.grantee_name as User_Nm,
u.role as rolename,
r.table_catalog AS Database_Nm,
r.table_schema as Schema_Nm,
r.GRANTED_ON AS Object_type,
r.Name as Object_Nm,
r.privilege AS Access_Right,
u.granted_by AS Grantor_Nm,
1 AS Batch_Id
from SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_USERS u
join SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES r
on u.role=r.grantee_name
where u.deleted_on is null
group by 3, 4, 5, 6, 7, 8, 9, 10;""",

    "view_discover": """SELECT 'SNOWFLAKE' AS DATABASE_VENDOR,
'{hostname}' AS DATABASE_SERVER_Nm,
TABLE_CATALOG AS DATABASE_Nm,
TABLE_SCHEMA as Schema_Nm,
TABLE_NAME AS View_Nm,
VIEW_DEFINITION,
IS_SECURE,
1 AS Batch_Id FROM {database}.INFORMATION_SCHEMA.VIEWS
WHERE SCHEMA_NM NOT IN ('INFORMATION_SCHEMA');""",

    "role_discover": """select 'SNOWFLAKE' AS DATABASE_VENDOR
,'{hostname}' AS DATABASE_SERVER_NM
,R.NAME AS ROLE_NAME 
,G.Grantee_name as Grantee
,G.granted_by as Grantor
,G.TABLE_CATALOG AS DATABASE_Nm
,G.TABLE_SCHEMA AS schema_Nm
,G.GRANTED_ON AS Object_type
,G.Name as Object_Nm
,G.privilege as Access_Right
,1 AS Batch_Id from SNOWFLAKE.ACCOUNT_USAGE.ROLES R
FULL OUTER JOIN SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES G
ON R.NAME = G.Grantee_name 
where R.deleted_on is NULL
AND R.NAME NOT IN ('PUBLIC','USERADMIN','ACCOUNTADMIN','SYSADMIN','SECURITYADMIN', 'SNOWFLAKE');""",

    "procedure_discover": """select PROCEDURE_NAME AS PROCEDURE_NM, PROCEDURE_CATALOG AS DATABASE_NM,
PROCEDURE_SCHEMA AS SCHEMA_NM, 'SNOWFLAKE' AS DATABASE_VENDOR,PROCEDURE_DEFINITION 
from {database}.information_schema.PROCEDURES;
""",
    "schema_discover": """select CATALOG_NAME AS DATABASE_NAME, SCHEMA_NAME
from "{database}"."INFORMATION_SCHEMA"."SCHEMATA"
where schema_name not in ('INFORMATION_SCHEMA');
    """,

    "query_id_1": "SELECT QUERY_ID,TOTAL_ELAPSED_TIME,EXECUTION_STATUS,START_TIME  from table({schema_name}.information_schema.query_history())  WHERE QUERY_TYPE LIKE 'COPY' AND substring(query_text,REGEXP_INSTR(query_text,'[\.]',1,2)+1,((REGEXP_INSTR(query_text,'FROM')))  -(REGEXP_INSTR(query_text,'[\.]',1,2)+2))='{table_name}' order by start_time DESC limit 1",
    "query_id_2": "SELECT ROW_COUNT,ROW_PARSED from information_schema.load_history where TABLE_NAME = '{table_name}' order by last_load_time desc limit 1",
    
    "share_discover_1": "SHOW SHARES;",
    "share_discover_2": "DESCRIBE SHARE {share};",
    "reader_discover": "SHOW MANAGED ACCOUNTS;",
    "materialized_views": "SHOW MATERIALIZED VIEWS"
}

cmd_map = {"RETRIEVE OR SELECT": "GRANT SELECT ON {object_type} {db_name}.{db_name}.{object_nm} TO ROLE {role_name};",
           "INSERT": "GRANT INSERT ON {object_type} {db_name}.{db_name}.{object_nm} TO ROLE {role_name};",
           "DELETE": "GRANT DELETE ON {object_type} {db_name}.{db_name}.{object_nm} TO ROLE {role_name};",
           "UPDATE": "GRANT UPDATE ON {object_type} {db_name}.{db_name}.{object_nm} TO ROLE {role_name};",
           "REFERENCES": "GRANT UPDATE ON {object_type} {db_name}.{db_name}.{object_nm} TO ROLE {role_name};"
           }

cmd_map_all = {"RETRIEVE OR SELECT": "GRANT SELECT ON ALL {object_type}S IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
               "INSERT": "GRANT INSERT ON ALL {object_type}S IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
               "DELETE": "GRANT DELETE ON ALL {object_type}S IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
               "UPDATE": "GRANT UPDATE ON ALL {object_type}S IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
               "REFERENCES": "GRANT REFERENCES ON ALL {object_type}S IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
               "CREATE DATABASE": "GRANT CREATE DATABASE ON ACCOUNT TO ROLE {role_name};",
               "CREATE ROLE": "GRANT CREATE ROLE ON ACCOUNT TO ROLE {role_name};",
               "CREATE USER": "GRANT CREATE USER ON ACCOUNT TO ROLE {role_name};",
               "CREATE FUNCTION": "GRANT CREATE FUNCTION ON SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
               "CREATE TABLE": "GRANT CREATE TABLES ON SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
               "CREATE VIEW": "GRANT CREATE VIEWS ON SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
               "CREATE PROCEDURE": "GRANT CREATE PROCEDURES ON SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
               "EXECUTE": "GRANT USAGE ON DATABASE {db_name} TO ROLE {role_name}; GRANT USAGE ON SCHEMA {db_name}.{db_name} TO ROLE {role_name}"
               }

sf_link_all = {
      "discovery_wh_query" : "CREATE OR REPLACE WAREHOUSE {discovery_warehouse_name} WITH WAREHOUSE_SIZE = {discovery_warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD';",
      "schema_migration_wh_query" : "CREATE OR REPLACE WAREHOUSE {schema_warehouse_name} WITH WAREHOUSE_SIZE = {schema_migration_Warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD';",
      "data_migration_wh_query" : "CREATE OR REPLACE WAREHOUSE {data_warehouse_name} WITH WAREHOUSE_SIZE = {data_migration_warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD';",
      "create_db_query" : "CREATE OR REPLACE DATABASE {database_snowflake};",
      "integration_query" : "CREATE OR REPLACE STORAGE INTEGRATION {integration_name} TYPE = {stage_type} STORAGE_PROVIDER = {storage_provider} ENABLED = {enabled} AZURE_TENANT_ID = '{azure_tenant_id}' STORAGE_ALLOWED_LOCATIONS = ('{storage_allowed_locations}')",
      "file_formate_query" : "CREATE OR REPLACE FILE FORMAT {database_snowflake}.{schema}.{file_format_name} TYPE = 'CSV' COMPRESSION = 'AUTO' FIELD_DELIMITER = '\302\254' RECORD_DELIMITER = '\\n' SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '\\042' TRIM_SPACE = TRUE ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE ESCAPE = NONE ESCAPE_UNENCLOSED_FIELD = '\\134' DATE_FORMAT = 'AUTO' TIMESTAMP_FORMAT = 'AUTO' NULL_IF = ('\\\\N');",
      "stage_query" : "create or replace stage {stage_name} storage_integration = {integration_name} url= '{storage_allowed_locations}' file_format = {file_format};",
      "drop_data_wh_query" :  "DROP WAREHOUSE IF EXISTS {data_warehouse_name};",
      "drop_schema_wh_query" : "DROP WAREHOUSE IF EXISTS {schema_warehouse_name};",
      "drop_discovery_wh_query" : "DROP WAREHOUSE IF EXISTS {discovery_warehouse_name};",
      "drop_database_query" : "DROP DATABASE IF EXISTS {database_snowflake}",
      "drop_sf_integration_query" : "DROP STORAGE INTEGRATION IF EXISTS {integration_name}",
      "alt_discovery_wh_query" : " ALTER WAREHOUSE {discovery_warehouse_name} SET WAREHOUSE_SIZE = {discovery_warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD' COMMENT = 'updated at {update_time}';",
      "alt_schema_migration_wh_query" : " ALTER WAREHOUSE {schema_warehouse_name} SET WAREHOUSE_SIZE = {schema_migration_warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD' COMMENT = 'updated at {update_time}';",
      "alt_data_migration_wh_query" : " ALTER WAREHOUSE {data_warehouse_name} SET WAREHOUSE_SIZE = {data_migration_warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD' COMMENT = 'updated at {update_time}';"
}

schema_migration = {
    "use_db": "USE DATABASE {schema_name};",
    "create_db": "CREATE DATABASE {schema_name};",
    "use_schema": "USE SCHEMA {schema_name};",
    "create_schema": "CREATE SCHEMA {schema_name};",
    "drop_table": "DROP TABLE {table_name};",
    "create_role": "CREATE ROLE {role_name};",
    "drop_role": "DROP ROLE {Role_Name};",
    "create_user": "CREATE USER {user_name} PASSWORD = 'IDEA123'  DEFAULT_ROLE = 'SYSADMIN' DEFAULT_WAREHOUSE = 'COMPUTE_WH' COMMENT = 'Please change "
                   "password on first login' "
                   "MUST_CHANGE_PASSWORD = TRUE;",
    "grant_default_role": "GRANT ROLE SYSADMIN TO USER {user_name};",
    "grant_role": "GRANT ROLE {Role_Nm} TO USER {User_Nm};",
    "drop_user": "DROP USER {User_Name};",
    "drop_view": "DROP VIEW {view_name};",
    "use_warehouse": "GRANT USAGE ON WAREHOUSE COMPUTE_WH TO ROLE {Role_Nm};" ,
    "use_sysadmin": "GRANT ROLE SYSADMIN TO ROLE {Role_Nm};"
}

link_service = {
    "check_permission": "SELECT $1 as cm FROM @{} limit 1"
}


cmd_role_cmd = {
                "CREATE DATABASE": "GRANT CREATE DATABASE ON ACCOUNT TO ROLE {role_name};",
                "CREATE ROLE": "GRANT CREATE ROLE ON ACCOUNT TO ROLE {role_name};",
                "CREATE USER": "GRANT CREATE USER ON ACCOUNT TO ROLE {role_name};",
                "ROLE":"GRANT ROLE {child_role} TO ROLE {parent_role}" ,
                "USAGES_DB": "GRANT USAGE ON DATABASE {db_name} TO ROLE {role_name}",
                "USAGES_SCHEMA": "GRANT USAGE ON SCHEMA {db_name}.{db_name} TO ROLE {role_name}",
                "TABLE" :{
                    "SELECT": "GRANT SELECT ON TABLE {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "RETRIEVE OR SELECT": "GRANT SELECT ON TABLE {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "INSERT": "GRANT INSERT ON TABLE {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "DELETE": "GRANT DELETE ON TABLE {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "UPDATE": "GRANT UPDATE ON TABLE {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "REFERENCES": "GRANT REFERENCES ON TABLE {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "OWNERSHIP": "GRANT OWNERSHIP ON TABLE {db_name}.{db_name}.{object_name} TO ROLE {role_name} COPY CURRENT GRANTS;"
                         },
                "VIEW" :{
                    "SELECT": "GRANT SELECT ON VIEW {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "RETRIEVE OR SELECT": "GRANT SELECT ON VIEW {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "INSERT": "GRANT INSERT ON VIEW  {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "DELETE": "GRANT DELETE ON VIEW {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "UPDATE": "GRANT UPDATE ON VIEW {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "REFERENCES": "GRANT REFERENCES ON VIEW {db_name}.{db_name}.{object_name} TO ROLE {role_name};",
                    "OWNERSHIP": "GRANT OWNERSHIP ON VIEW {db_name}.{db_name}.{object_name} TO ROLE {role_name} COPY CURRENT GRANTS;"
                         },
                "SCHEMA":{
                    "CREATE PROCEDURE": "GRANT CREATE PROCEDURES ON SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "CREATE FUNCTION": "GRANT CREATE FUNCTION ON SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "CREATE TABLE": "GRANT CREATE TABLE ON SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "CREATE VIEW": "GRANT CREATE VIEW ON SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "OWNERSHIP": "GRANT OWNERSHIP ON SCHEMA {db_name}.{db_name} TO ROLE {role_name} COPY CURRENT GRANTS;",
                    "EXECUTE PROCEDURE": "GRANT USAGE ON ALL PROCEDURES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "EXECUTE": "GRANT USAGE ON SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "ALL": "GRANT ALL ON SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "ALL_DB": "GRANT ALL ON DATABASE {db_name} TO ROLE {role_name};",
                    "TABLE":{
                    "ALL" : "GRANT ALL ON ALL TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "SELECT": "GRANT SELECT ON ALL TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "RETRIEVE OR SELECT": "GRANT SELECT ON ALL TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "DELETE": "GRANT DELETE ON ALL TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "UPDATE": "GRANT UPDATE ON ALL TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "INSERT": "GRANT INSERT ON ALL TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "REFERENCES": "GRANT REFERENCES ON ALL TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};"
                            },
                    "VIEW":{
                    "ALL" : "GRANT ALL ON ALL VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};", 
                    "SELECT": "GRANT SELECT ON ALL VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "RETRIEVE OR SELECT": "GRANT SELECT ON ALL VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "DELETE": "GRANT DELETE ON ALL VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "UPDATE": "GRANT UPDATE ON ALL VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "INSERT": "GRANT INSERT ON ALL VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                    "REFERENCES": "GRANT REFERENCES ON ALL VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};"
                            },                            
                            }
                }
cmd_role_all = {
            "TABLE" :{  
                        "ALL" : "GRANT ALL ON FUTURE TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "SELECT": "GRANT SELECT ON FUTURE TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "RETRIEVE OR SELECT": "GRANT SELECT ON FUTURE TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "INSERT": "GRANT INSERT ON FUTURE TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "DELETE": "GRANT DELETE ON FUTURE TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "UPDATE": "GRANT UPDATE ON FUTURE TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "REFERENCES": "GRANT REFERENCES ON FUTURE TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};"
                        },
            "VIEW" :{   
                        "ALL" : "GRANT ALL ON FUTURE VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "SELECT": "GRANT SELECT ON FUTURE VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "RETRIEVE OR SELECT": "GRANT SELECT ON FUTURE VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "INSERT": "GRANT INSERT ON FUTURE VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "DELETE": "GRANT DELETE ON FUTURE VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "UPDATE": "GRANT UPDATE ON FUTURE VIEWS IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};",
                        "REFERENCES": "GRANT REFERENCES ON VIEWS TABLES IN SCHEMA {db_name}.{db_name} TO ROLE {role_name};"
                        }
            
                }


view_cmd = {"SELECT": "GRANT SELECT ON VIEW {db_name}.{db_name}.{object_nm} TO ROLE {role_name};",
            "ALL": "GRANT ALL ON VIEW {db_name}.{db_name}.{object_nm} TO ROLE {role_name};"
           }

revoke_cmd = {
                "TABLE": "REVOKE SELECT,INSERT,DELETE,UPDATE,REFERENCES ON TABLE {db_name}.{db_name}.{object_name} FROM ROLE {role_name};",
                "VIEW": "REVOKE SELECT,INSERT,DELETE,UPDATE,REFERENCES ON VIEW {db_name}.{db_name}.{object_name} FROM ROLE {role_name};", 
}