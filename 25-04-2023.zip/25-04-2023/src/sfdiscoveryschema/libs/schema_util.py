"""
This file has all supportive functions for schema migration
"""
import json
import logging
import re
import traceback
import uuid
from datetime import datetime
import pandas as pd
import pyodbc
from config import config, db, send_message
from libs import snowflake
from libs.util import format_json
from libs.secret_manager import get_secret

log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'
query_execute_successful = "Query execution successful"
something_went_wrong = "Something went wrong. Please try later"
table_ddl_conversion_fail = "Table DDL conversion failed"
table_created = "Table created (Brute Force Algorithm)"
schema_not_exist = "Schema not exists or query Syntax error"
role_migration_fail = "Role migration failed"
table_migration_fail = "Table migration failed"
view_migration_fail = "View migration failed"
role_created_brute_force = "Role created (Brute Force Algorithm)"
user_migration_fail = "User migration failed"
conn_string_log = "conn_string: {}"
query_log = "query: {}"
exec_seq_query = '$exec_seq'
drop_list_user = ["DROP VIEW", "DROP TABLE", "DROP PROCEDURE"]
future_grant_list = ["SELECT","DELETE","UPDATE","INSERT","REFERENCES","RETRIEVE OR SELECT"]
not_in = ["DROP TRIGGER", "CREATE TRIGGER", "DUMP", "CREATE AUTHORIZATION", "DROP MACRO", "STATISTICS", 
                        "CREATE FUNCTION", "ALTER EXTERNAL PROCEDURE", "CONSTRAINT DEFINITION", "CREATE MACRO", 
                        "DROP AUTHORIZATION", "DROP USER", "CREATE OWNER PROCEDURE",
                        "EXECUTE PROCEDURE","EXECUTE","DROP PROCEDURE","SHOW","MONITOR SESSION","SET SESSION RATE",
                        "DROP MACRO","SET RESOURCE RATE","ABORT SESSION","MONITOR RESOURCE","EXECUTE FUNCTION",
                        "INDEXES","RESTORE"]
object_not_in = ["STANDARD FUNCTION","JOURNAL","TABLE FUNCTION","USER-DEFINED TABLE OPERATOR",
                 "AGGREGATE FUNCTION","JAR","TABLE OPERATOR PARSER CONTRACT FUNCTION","JOIN INDEX"]


def job_run_fail_update(job_run_id):
    end_time = int(datetime.utcnow().timestamp())
    end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
    db.job_run.update_one({'job_run_id': job_run_id},
                          {"$set": {"status": "Fail", "end_time": end_time,
                                    "end_time_str": end_time_str}})


def bteq_to_snowsql(bteq):
    snowsql = bteq
    for pair in db.idea_etl_td_snow.find({},{"_id":0}):
        snowsql = re.sub(pair['detect_regex'], pair['snowflake_replacement'], snowsql)
    snowsql = re.sub(r'(?i)VIEW\s+(\w+)\s*\.\s*(\w+)\s*',r'VIEW D_IDEA_MIGRATION_DB.\g<2>',snowsql)
    
    # Detect the patterns for extract and from
    extract = re.findall(r"(?i)EXTRACT\s*\(\w*\s*FROM", snowsql)
    lstextract = ["#extract" + str(extract.index(x)) for x in extract]
    from_df = pd.DataFrame(list(zip(lstextract, extract)), columns=['fromid', "fromval"])
    for i in lstextract:
        snowsql = re.sub(r"(?i)EXTRACT\s*\(\w*\s*FROM", " " + i + " ", snowsql)

    # Detect the patterns between FROM and ON clause
    fromon = re.findall(r"(?is)(?<=FROM)(.*)(?=\bon\b)", snowsql)
    if not fromon:
        # Detect the patterns between FROM and WHERE clause
        fromwhere = re.findall(r"(?is)(?<=FROM)(.*)(?=WHERE)", snowsql)
        lstfromwhere = ["#fromwhere" + str(fromwhere.index(x)) for x in fromwhere]
        df = pd.DataFrame(list(zip(lstfromwhere, fromwhere)), columns=['fromid', "fromval"])
        from_df = from_df.append(df)
        del df
        for i in lstfromwhere:
            snowsql = re.sub(r"(?is)(?<=FROM)(.*)(?=WHERE)", " " + i + " ", snowsql)
    lstfromon = ["#fromon" + str(fromon.index(x)) for x in fromon]
    df = pd.DataFrame(list(zip(lstfromon, fromon)), columns=['fromid', "fromval"])
    from_df = from_df.append(df)
    del df
    for i in lstfromon:
        snowsql = re.sub(r"(?is)(?<=FROM)(.*)(?=\bon\b)", " " + i + " ", snowsql)
    # Detect the pattern after FROM clause
    from2 = re.findall(r"(?is)((?<=FROM)\s*\w+\s*\.\s*\w+\s*)", snowsql)
    lstfrom = ["#from" + str(from2.index(x)) for x in from2]
    df = pd.DataFrame(list(zip(lstfrom, from2)), columns=['fromid', "fromval"])
    from_df = from_df.append(df)
    del df

    # Substituting the detected pattern with a keyword #from
    for i in lstfrom:
        snowsql = re.sub(r"(?is)((?<=FROM)\s*\w+\s*\.\s*\w+\s*)", " " + i + " ", snowsql)

    # In the encoded block filter the elements which contain below symbols
    to_filter = [' = ', ' != ', ' <> ', ' > ', ' < ', ' between ', ' is ', ' like ', ' in ']
    for index, row in from_df.iterrows():
        filter_dict = {}
        # Split the encoded block based on the below words
        lst2 = re.split(
            ' FROM | JOIN |INNER JOIN|LEFT JOIN|LEFT OUTER JOIN|RIGHT JOIN|RIGHT OUTER JOIN|FULL OUTER JOIN| ON | EXISTS | WHERE ',
            row['fromval'], re.I)
        lst1 = lst2.copy()

        # Filter the elements which contain the symbols in to_filter list
        for item in range(len(lst1)):
            if not any(sign in lst1[item].lower() for sign in to_filter):
                filter_dict[item] = lst1[item]

        # To filter the a.b elements and make them a.a.b
        for key, value in filter_dict.items():
            filter_dict[key] = re.sub(r"([a-zA-Z_0-9]+\.)", r"{}.\1".format(config['snowflake']['database_snowflake']), value)
            lst1[key] = filter_dict[key]

        # Now replace the filtered and modified elements in the original string
        for item in range(len(lst2)):
            row['fromval'] = row['fromval'].replace(lst2[item], lst1[item], 1)

    # for index, row in from_df.iterrows():
    #     row['fromval'] = re.sub(r"([a-zA-Z_0-9]+\.)", r"\1\1", row['fromval'])

    for index, row in from_df.iterrows():
        snowsql = snowsql.replace(row['fromid'], row['fromval'])
    return snowsql


def check_col_length(value):
    """
    Limiting the column length to 8000
    in case it has a higher value than 8000.
    :param value:
    :return: value
    """
    value = str(value).strip().strip('(').strip(')')
    try:
        value = int(value)
        if value == 0:
            value = 100
    except Exception:
        if value == '*':
            value = 2000
        return value
    # Checking the column length
    if value > 8000:
        log.info(":: Column length is getting capped to 8000 ::")
        value = 8000
    value = str(value)
    return value


def map_data_type(target_db):
    """
    Fetching the data type mapping dictionary
    from mapping table
    :return: map_data_type_dict
    """
    log.info("START")

    # Connecting to mysql
    try:
        info_df = pd.DataFrame(
            db.idea_src_tgt_data_type_map.find({"tgt_db_vendor": {'$regex': target_db,
                                                                  '$options': 'i'}},
                                               {
                                                   "src_generic_data_type": 1,
                                                   "src_generic_char_type": 1,
                                                   "tgt_generic_data_type": 1,
                                                   "tgt_alternate_data_type": 1,
                                                   "tgt_alternate_column_length": 1, "_id": 0
                                               }))
        if info_df.empty:
            log.info("idea_src_tgt_data_type_map error {}".format("record not found"))
            return False

        result = info_df.to_json()
        result = format_json(json.loads(result))
        log.info(query_execute_successful)

        # Initializing the dictionary
        map_data_type_dict = {}
        log.info("Creating the mapping dictionary")
        for item in result:
            if item['tgt_generic_data_type'].strip() != '':
                try:
                    map_data_type_dict[(item['src_generic_data_type'].strip()
                                        + item['src_generic_char_type'].strip())] = item[
                        'tgt_generic_data_type'].strip()
                except Exception:
                    map_data_type_dict[item['src_generic_data_type'].strip()] = \
                        item['tgt_generic_data_type'].strip()
            else:
                try:
                    map_data_type_dict[item['src_generic_data_type'].strip()] = \
                        item['tgt_alternate_data_type'].strip()
                except Exception:
                    map_data_type_dict[item['src_generic_data_type'].strip()] = ''

    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        log.info("map_data_type error {}".format(status))
        return False

    log.info("END")
    return map_data_type_dict


def map_object_type(target_db):
    """
    Fetching the object type mapping dictionary
    from mapping table
    :return: map_object_type_dict
    """
    log.info("START")
    # Fetching the query

    try:
        info_df = pd.DataFrame(
                        db.idea_src_tgt_obj_comnd_map.find({"tgt_db_vendor":{'$regex': target_db,
                                                                  '$options': 'i'}},
                                   {"src_command_name": 1, "tgt_command_name": 1,
                                    "_id": 0}))

        if info_df.empty:
            log.info("map_object_type error message record not found")
            return False

        result = info_df.to_json()
        result = format_json(json.loads(result))
        log.info(query_execute_successful)

        # Initializing the dictionary
        map_object_type_dict = {}
        log.info("Creating the mapping dictionary")
        for item in result:
            map_object_type_dict[item['src_command_name'].strip()] = \
                item['tgt_command_name'].strip()

    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        log.info(status)
        return False

    log.info("END")
    return map_object_type_dict


def fetch_col_details(table_list, discovery_id, job_run_id, schema_nm):
    """
    Fetching all column level details from column_discovery
    :param table_list:
    :param job_run_id:
    :param discovery_id:
    :return: result
    """
    log.info("START")
    try:
        result = pd.DataFrame(
            db.idea_column_discovery_attr.find({"table_nm": {"$in": table_list},
                                                "batch_id": discovery_id,"database_nm" : schema_nm},
                                               {"database_vendor": 1, "database_server_nm": 1,
                                                "database_nm": 1, "table_nm": 1, "column_nm": 1,
                                                "data_type": 1, "column_seq": 1, "column_length": 1,
                                                "char_type": 1, "nullable_ind": 1,
                                                "data_distribution_ind": 1, "partition_ind": 1,
                                                "column_constraints_defined": 1,
                                                "comment_string": 1, "_id": 0
                                                }))
        log.info(query_execute_successful)
        if result.empty:
            log.info("fetch_col_details error record not found")
            return False

    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        upd_status = update_job_run_detail_status(
            job_run_id, table_list, "Fail", "Column discovery failed")
        if not upd_status:
            return False
        log.info(status)
        return False

    log.info("END")
    return list(result.to_records(index=False))


def fetch_table_details(table_list, discovery_id, job_run_id, schema_nm):
    """
    Fetching all table level details from table_discovery
    "param discovery_id:
    :param table_list:
    :param discovery_id:
    :param job_run_id:
    :param schema_nm:
    :return: result
    """
    log.info("START")
    try:
        result = pd.DataFrame(
            db.idea_table_discovery_attr.find(
                {"table_nm": {"$in": table_list}, "batch_id": discovery_id,"database_nm" : schema_nm},
                {"database_vendor": 1, "database_server_nm": 1, "database_nm": 1,
                 "table_nm": 1, "column_nm": 1, "data_distribution_keys": 1,
                 "partition_defined": 1, "index_type": 1, "indexes_defined": 1,
                 "constraint_type": 1, "constraints_defined": 1, "_id": 0
                 }))
        log.info(query_execute_successful)
        if result.empty:
            log.info("fetch_table_details error record not found")
            return False

    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        upd_status = update_job_run_detail_status(
            job_run_id, table_list, "Fail", "Table discovery failed")
        if not upd_status:
            return False
        log.info((status))
        return False

    log.info("END")
    return list(result.to_records(index=False))


def insert_table_details(value, job_run_id):
    """
    Inserting all the converted value in table_schema_conv table
    :param job_run_id:
    :param value:
    :return: boolean
    """
    log.info("START")
    info_df = pd.DataFrame(value,
                           columns=['src_database_vendor', 'src_database_server_nm',
                                    'src_database_nm',
                                    'src_table_nm', 'tgt_database_vendor', 'tgt_database_server_nm',
                                    'tgt_database_nm', 'tgt_table_nm', 'tgt_data_distribution_keys',
                                    'tgt_table_partition', 'tgt_index_type', 'tgt_indexes_defined',
                                    'tgt_constraint_type', 'tgt_constraints_defined',
                                    'src_batch_id', 'tgt_batch_id'
                                    ])
    try:
        info_df["insert_dttm"] = datetime.utcnow()
        db.idea_table_schema_conv_attr.insert_many(info_df.T.to_dict().values())
        log.info(query_execute_successful)

    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        upd_status = update_job_run_detail_status(
            job_run_id, info_df['tgt_table_nm'], "Fail", "Insert table details failed")
        if not upd_status:
            return False
        log.info(status)
        return False

    log.info("END")
    return True


def insert_col_details(value, job_run_id):
    """
    Inserting all the converted value in column_schema_conv table
    :param job_run_id:
    :param value:
    :return: count
    """
    log.info("START")

    info_df = pd.DataFrame(value,
                           columns=['src_database_vendor', 'src_database_server_nm',
                                    'src_database_nm',
                                    'src_table_nm', 'src_column_nm', 'tgt_database_vendor',
                                    'tgt_database_server_nm', 'tgt_database_nm', 'tgt_table_nm',
                                    'tgt_column_nm', 'tgt_data_type', 'tgt_column_seq',
                                    'tgt_column_length', 'tgt_char_type', 'tgt_nullable_ind',
                                    'tgt_data_distribution_ind', 'tgt_partition_ind',
                                    'tgt_column_constraints_defined', 'tgt_comment_string',
                                    'src_batch_id', 'tgt_batch_id'
                                    ])
    try:
        info_df["insert_dttm"] = datetime.utcnow()
        db.idea_column_schema_conv_attr.insert_many(info_df.T.to_dict().values())
        log.info(query_execute_successful)

    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        upd_status = update_job_run_detail_status(
            job_run_id, info_df['tgt_table_nm'], "Fail", "Insert column details failed")
        if not upd_status:
            return False
        log.info(status)
        return False

    log.info("END")
    return True


def get_schema_convert(table_list, discovery_id, tgt_database_server_nm, job_run_id, target_db,schema_nm):
    """
    Fetching all the details from discovery table
    as well as the user inputs. Convert all the data type
    and object types accordingly and insert all the
    converted data into schema conversion tables
    """
    log.info("START")
    try:
        # Creating the batch_id for schema migration
        batch_id = str(uuid.uuid4())

        map_object_type_dict = map_object_type(target_db)
        if not map_object_type_dict:
            upd_status = update_job_run_detail_status(
                job_run_id, table_list, "Fail", table_ddl_conversion_fail)
            return False
        map_data_type_dict = map_data_type(target_db)
        if not map_data_type_dict:
            upd_status = update_job_run_detail_status(
                job_run_id, table_list, "Fail", table_ddl_conversion_fail)
            return False

        table_res = fetch_table_details(table_list, discovery_id, job_run_id,schema_nm)
        if not table_res:
            upd_status = update_job_run_detail_status(
                job_run_id, table_list, "Fail", table_ddl_conversion_fail)
            return False
        col_res = fetch_col_details(table_list, discovery_id, job_run_id, schema_nm)
        if not col_res:
            upd_status = update_job_run_detail_status(
                job_run_id, table_list, "Fail", table_ddl_conversion_fail)
            return False

        # Looping through each row data from table level discovery
        for idx, val in enumerate(table_res):
            table_res[idx] = list(table_res[idx])
            try:
                log.info("Indextype mapping started")
                # Changing the Index_type column value
                table_res[idx][6] = map_object_type_dict[table_res[idx][6].strip().upper()]
                log.info("Constraint type mapping started")
                # Changing the Constraint_Type column value
                table_res[idx][8] = map_object_type_dict[table_res[idx][8].strip().upper()]
                # Unsupported Constraint types are set as blank
                if table_res[idx][8] == '':
                    table_res[idx][9] = ''
            except Exception:
                # In case the Index_type and Constraint_type are not in mapping table
                log.info("Mapping not found")
            table_res[idx] = tuple(table_res[idx])

        # Inserting the target_db details

        for idx, val in enumerate(table_res):
            table_res[idx] = (table_res[idx][:4]
                              + (target_db, tgt_database_server_nm,
                                 table_res[idx][2], table_res[idx][3])
                              + table_res[idx][4:])
            table_res[idx] = table_res[idx] + (discovery_id, batch_id,)

        # Inserting the converted data into schema_conv table
        log.info("Inserting into table schema conversion table")
        table_schema_conv_res = insert_table_details(table_res, job_run_id)

        # Replacing the data type with default one using mapping
        # Looping through each row data from column level discovery
        for idx, val in enumerate(col_res):
            col_res[idx] = list(col_res[idx])
            log.info("Data type mapping started")
            # Changing the Column_data_type value using mapping table
            try:
                # Converting the CHAR, VARCHAR values
                col_res[idx][5] = map_data_type_dict[(col_res[idx][5].strip().upper()
                                                      + col_res[idx][8].strip().upper())]
            except AttributeError:
                try:
                    # Other than CHAR and VARCHAR data types
                    col_res[idx][5] = map_data_type_dict[col_res[idx][5].strip().upper()]
                except KeyError:
                    # If nothing found in mapping dictionary
                    log.info("Nothing found in mapping dictionary")
            # Checking column length in case it is not null
            if col_res[idx][7] != '':
                if col_res[idx][5] == "TIMESTAMP":
                    col_res[idx][7] = str(col_res[idx][7]).strip().strip('(').strip(')')
                elif col_res[idx][5] == 'VARCHAR' and str(type(col_res[idx][7])).find('int') == -1:
                    col_res[idx][7] = '100'
                elif col_res[idx][5] == 'NUMBER' and str(col_res[idx][7]).strip().strip('(').strip(
                        ')').strip() == '*':
                    col_res[idx][7] = ''
                else:
                    col_res[idx][7] = check_col_length(col_res[idx][7])
            # For Alternate data types the data type value will be VARCHAR
            # but the column length will be blank, so replacing it with 100
            else:
                if col_res[idx][5] == 'VARCHAR':
                    col_res[idx][7] = '100'

            col_res[idx] = tuple(col_res[idx])

        # Inserting the db_vendor details
        for idx, val in enumerate(col_res):
            # Inserting the Target database details columns
            col_res[idx] = (col_res[idx][:5]
                            + (target_db, tgt_database_server_nm, col_res[idx][2], col_res[idx][3],
                               col_res[idx][4])
                            + col_res[idx][5:])
            col_res[idx] = col_res[idx] + (discovery_id, batch_id,)

        # Inserting the converted data into schema_conv table
        log.info("Inserting into column schema conversion table")
        log.info(col_res)
        column_schema_conv_res = insert_col_details(col_res, job_run_id)
        if not table_schema_conv_res or not column_schema_conv_res:
            return False
    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        upd_status = update_job_run_detail_status(
            job_run_id, table_list, "Fail", table_ddl_conversion_fail)
        if not upd_status:
            return False
        log.info(status)
        return False

    log.info("END")
    return batch_id


def set_table_options(distribution_column, partition_column, partition_value):
    """
    Fill in all the parameters of table_options
    according to the fetched data from
    mysql database.
    :param distribution_column:
    :param partition_column:
    :param partition_value:
    :return: string - table_options
    """
    table_options = []
    
    if distribution_column == "":
        if partition_column == "":
            distribution = config['table_options']['distribution_default']
            table_options = config['table_options']['without_partition']
            table_options = table_options.format(distribution=distribution)
        elif partition_column != "":
            distribution = config['table_options']['distribution_default']
            partition = config['table_options']['partition']
            table_options = config['table_options']['value']
            partition = partition.format(partition_column_name=partition_column,
                                         partition_value=partition_value)
            table_options = table_options.format(distribution=distribution,
                                                 partition=partition)
    else:
        if partition_column == "":
            distribution = config['table_options']['distribution']
            table_options = config['table_options']['without_partition']
            distribution = distribution.format(distribution_column_name=distribution_column)
            table_options = table_options.format(distribution=distribution)
        elif partition_column != "":
            distribution = config['table_options']['distribution']
            partition = config['table_options']['partition']
            table_options = config['table_options']['value']
            distribution = distribution.format(distribution_column_name=distribution_column)
            partition = partition.format(partition_column_name=partition_column,
                                         partition_value=partition_value)
            table_options = table_options.format(distribution=distribution, partition=partition)
    return table_options


def set_ddl_into_table(json_data, table_name, ddl_script, batch_id):
    """
    accepts all the parameters and
    get the insert query and execute it to
    insert the output of this service into
    mysql database.
    :param json_data:
    :param table_name:
    :param ddl_script:
    :param batch_id:
    :return:
    """
    log.info("START")
    try:
        ddl_script = ddl_script.replace("\'", "\"")
        table_id = "IDEA_"+table_name

        insert_value = [
            (json_data['src_database_vendor'][0], json_data['src_database_server_nm'][0],
             json_data['src_database_nm'][0], table_name, json_data['tgt_database_vendor'][0],
             json_data['tgt_database_server_nm'][0], json_data['tgt_database_nm'][0],
             table_name, ddl_script, batch_id,table_id,1)]
        info_df = pd.DataFrame(insert_value, columns=['src_database_vendor',
                                                      'src_database_server_nm',
                                                      'src_database_nm', 'src_table_nm',
                                                      'tgt_database_vendor',
                                                      'tgt_database_server_nm',
                                                      'tgt_database_nm', 'tgt_table_nm',
                                                      'object_defination_txt', 'tgt_batch_id','table_id','exe_seq'])
        info_df["insert_dttm"] = datetime.utcnow()
        db.idea_ddl_schema_conv_info.insert_many(info_df.T.to_dict().values())
        log.info(query_execute_successful)

    except Exception:
        log.error(traceback.format_exc())
        return False

    log.info("END")
    return True


def get_ddl_script(batch_id, schema_name, job_run_id, target_db):
    """
    this will return the create ddl statement
    for the given batch id
    :param schema_name:
    :param job_run_id:
    :param target_db:
    :param batch_id:
    :return: json - containing ddl scripts
    """
    log.info("START")
    table_names = set()
    try:
        json_data_tables = pd.DataFrame(
            db.idea_table_schema_conv_attr.find(
                {"tgt_batch_id": batch_id},
                {"tgt_table_nm": 1, "tgt_data_distribution_keys": 1, "tgt_table_partition": 1,
                 "tgt_index_type": 1, "tgt_indexes_defined": 1, "tgt_constraint_type": 1,
                 "tgt_constraints_defined": 1, "tgt_batch_id": 1, "_id": 0
                 }))
        for i in json_data_tables.index:
            table_names.add(json_data_tables['tgt_table_nm'][i])

        if len(table_names) == 0:
            msg = {"message": "No tables found for that batch_id"}
            log.info(msg)
            update_job_run_detail_status(
                job_run_id, table_names, "Fail", table_ddl_conversion_fail)
            return False  # jsonify(msg), flask_api.status.HTTP_500_INTERNAL_SERVER_ERROR

        json_data_columns = pd.DataFrame(
            db.idea_column_schema_conv_attr.find({"tgt_batch_id": batch_id},
                                                 {"src_database_vendor": 1,
                                                  "src_database_server_nm": 1,
                                                  "src_database_nm": 1, "src_table_nm": 1,
                                                  "tgt_database_vendor": 1,
                                                  "tgt_database_server_nm": 1, "tgt_database_nm": 1,
                                                  "tgt_table_nm": 1,
                                                  "tgt_column_nm": 1, "tgt_data_type": 1,
                                                  "tgt_column_seq": 1,
                                                  "tgt_column_length": 1, "tgt_char_type": 1,
                                                  "tgt_nullable_ind": 1,
                                                  "tgt_data_distribution_ind": 1,
                                                  "tgt_partition_ind": 1,
                                                  "tgt_column_constraints_defined": 1,
                                                  "tgt_batch_id": 1, "_id": 0
                                                  }).sort([("tgt_column_seq", 1)]))
        definitions = []
        for table_name in table_names:
            table_name = table_name.strip()
            str_columns = {}
            for i in json_data_columns.index:
                if json_data_columns['tgt_table_nm'][i] == table_name:
                    nullable_index = ""
                    if json_data_columns['tgt_nullable_ind'][i] == 'N':
                        nullable_index = "NOT NULL"
                    if json_data_columns['tgt_column_constraints_defined'][i] == '?' or \
                            json_data_columns['tgt_column_constraints_defined'][i] == 'None' or \
                            json_data_columns['tgt_column_constraints_defined'][i] is None:
                        constraint = ""
                    else:
                        if json_data_columns['tgt_column_constraints_defined'][i].find(
                                'CHECK') == -1:
                            constraint = json_data_columns['tgt_column_constraints_defined'][i]
                        else:
                            constraint = ""
                    if json_data_columns['tgt_column_nm'][i] not in str_columns:
                        column_length = ""
                        if json_data_columns['tgt_column_length'][i] != "":
                            if json_data_columns["tgt_data_type"][i] == "NVARCHAR" and \
                                    int(json_data_columns["tgt_column_length"][i]) > 4000:
                                column_length = " (" + "4000" + ") "
                            else:
                                column_length = " (" + json_data_columns['tgt_column_length'][
                                    i] + ") "
                        str_columns[json_data_columns['tgt_column_nm'][i]] = json_data_columns['tgt_column_nm'][i] + " " \
                                      + json_data_columns['tgt_data_type'][i] \
                                      + column_length + " " + nullable_index + " " + constraint + ", "

            temp_str_columns = ""
            for col in str_columns:
                temp_str_columns += str_columns[col]
            str_columns = temp_str_columns
            
            # Removing last comma from the columns
            last_comma_index = str_columns.rfind(",")
            str_columns = str_columns[:last_comma_index]

            partition_value = ""
            for i in json_data_tables.index:
                if json_data_tables['tgt_table_nm'][i] == table_name and \
                        json_data_tables['tgt_table_partition'][i] is not None:
                    partition_value = json_data_tables['tgt_table_partition'][i]

            distribution_column = ""
            partition_column = ""
            for i in json_data_columns.index:
                if json_data_columns['tgt_table_nm'][i] == table_name and \
                        json_data_columns['tgt_data_distribution_ind'][i] == 'Y':
                    distribution_column = json_data_columns['tgt_column_nm'][i]
                    break
            for i in json_data_columns.index:
                if json_data_columns['tgt_table_nm'][i] == table_name and \
                        json_data_columns['tgt_partition_ind'][i] == 'Y':
                    partition_column = json_data_columns['tgt_column_nm'][i]
                    break

            if target_db == "snowflake":
                create_query = "CREATE TABLE {table_name}( {columns} );"
            else:
                create_query = "CREATE TABLE {schema_name}.{table_name}( {columns} ) WITH ( {" \
                               "table_options} ); "

            table_options = set_table_options(distribution_column, partition_column,
                                              partition_value)
            create_query = create_query.format(schema_name=schema_name, table_name=table_name,
                                               columns=str_columns, table_options=table_options)

            ddl_script = create_query
            definitions.append(ddl_script)
            set_ddl_into_table(json_data_columns, table_name, ddl_script, batch_id)

    except Exception:
        log.error(traceback.format_exc())
        upd_status = update_job_run_detail_status(
            job_run_id, table_names, "Fail", table_ddl_conversion_fail)
        if not upd_status:
            return False
        return False

    log.info("END")
    return True


def execute_script(force_create, schema_name, batch_id, job_run_id, link_id, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
    Show the last access details of a particular table mentioned by user
    :param force_create:
    :param schema_name:
    :param job_run_id:
    :param link_id:
    :param batch_id:
    :return: json response
    """
    log.info("START")
    try:
        info_df = pd.DataFrame(db.idea_ddl_schema_conv_info.find({"tgt_batch_id": batch_id},
                                                                 {"_id": 0, "tgt_database_nm": 1,
                                                                  "tgt_table_nm": 1,
                                                                  "object_defination_txt": 1,
                                                                  "tgt_batch_id": 1,"table_id":1,"exe_seq":1}))

        if info_df.empty:
            return False

        info_df.sort_values(by= ["table_id","exe_seq"], inplace = True)

        table_ids = info_df["table_id"].drop_duplicates()
        fail_count = 0
        result = info_df.to_json()

        result = db.link_service.find_one({"link_service_id": link_id})

        hostname = result["db_hostname"]
        username = get_secret(link_id + "-username")
        # Decrypt the password
        password = get_secret(link_id + "-password")
        database = result['link_service_name']
        db_vendor = result['link_service_type'].split()[0]

        sf_conn_string = config[db_vendor]["conn"].format(hostname=hostname,
                                                          uid=username,
                                                          pwd=password,
                                                          database=database,
                                                          warehouse=config['snowflake'][
                                                              'schema_migration_dwh'])
        conn = pyodbc.connect(sf_conn_string, autocommit=True)
        cursor = conn.cursor()

        for ids in table_ids:
            exe_ddls = info_df[info_df["table_id"]==ids].values.tolist()
            update_job_run_detail_status(job_run_id, [ids.split("IDEA_",1)[1]],
                                                        "InProgress", "")
            for itr in range(0, len(exe_ddls)):
                table_name  = exe_ddls[itr][1]
                table_ddl = exe_ddls[itr][2]
                exe_sq = exe_ddls[itr][5]
######### Snowflake instnace COE changes are taking place here #############
                try:
                    use_db_query = snowflake.schema_migration['use_db'].format(
                        schema_name= config['snowflake']['database_snowflake'] )
                    cursor.execute(use_db_query)
                except Exception as exception:
                    log.error(exception)
                    error_code = exception.args[0]
                    if error_code == "02000":
                        create_db_query = snowflake.schema_migration['create_db'].format(
                            schema_name=schema_name)
                        cursor.execute(create_db_query)
                        use_db_query = snowflake.schema_migration['use_db'].format(
                            schema_name=schema_name)
                        cursor.execute(use_db_query)
                        create_schema_query = snowflake.schema_migration['create_schema'].format(
                            schema_name=schema_name)
                        cursor.execute(create_schema_query)
                try:
                    use_schema_query = snowflake.schema_migration['use_schema'].format(
                        schema_name=schema_name)
                    cursor.execute(use_schema_query)
                except Exception as exception:
                    log.error(exception)
                    error_code = exception.args[0]
                    if error_code == "02000":
                        create_schema_query = snowflake.schema_migration['create_schema'].format(
                                schema_name=schema_name)
                        cursor.execute(create_schema_query)
                        use_schema_query = snowflake.schema_migration['use_schema'].format(
                        schema_name=schema_name)
                        cursor.execute(use_schema_query)
                
                try:
                    log.info("executing query :{}".format(table_ddl))
                    cursor.execute(table_ddl)
                    status = 'success'
                    if  exe_sq == 1:
                        desc = 'Table created successfully'
                except Exception as exception:
                    error_code = exception.args[0]
                    if error_code in ("42S01", "42710") and exe_sq == 1:
                        status = 'fail'
                        desc = "Table already exists"
                        if force_create:
                            try:
                                drop_query = snowflake.schema_migration['drop_table']
                                drop_query = drop_query.format(
                                    table_name=table_name)
                                cursor.execute(drop_query)
                                cursor.execute(table_ddl)
                                status = 'success'
                                desc = table_created
                            except Exception as exception:
                                desc = table_migration_fail
                                break
                        else:
                            break
                    elif error_code in ["02000","42S02"] and exe_sq in [2,3,4]:
                        status = 'success'
                        log.info("Object grant related information does not exist")
                        log.info("DDL query : {}".format(table_ddl))
                    else:
                        log.info("error_code in break block: {}".format(error_code))
                        log.info("query in break: {}".format(table_ddl))
                        log.info(exception)
                        status = "fail"
                        desc = table_migration_fail
                        break

            if status == "success":

                # Updating job run detail collection
                if socket_flag:
                    attributes = len(list(db.idea_column_schema_conv_attr.find({"tgt_batch_id": batch_id, "tgt_table_nm": ids.split("IDEA_",1)[1]})))
                    send_message("sf_schema_run_status", {ids.split("IDEA_",1)[1]:{"object_type":"table","status":"Success","database": schema_name,"attributes":attributes}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                update_job_run_detail_status(job_run_id,[ids.split("IDEA_",1)[1]], "Success", desc)
            else:
                # Updating job run detail collection
                if socket_flag:
                    send_message("sf_schema_run_status", {ids.split("IDEA_",1)[1]:{"object_type":"table","status":"Fail","database": schema_name,"attributes":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                fail_count+=1
                # Updating job run detail collection
                update_job_run_detail_status(job_run_id,[ids.split("IDEA_",1)[1]], "Fail", desc)

        cursor.close()
        conn.close()

    except Exception:
        log.error(traceback.format_exc())
        end_time = int(datetime.utcnow().timestamp())
        end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
        db.job_run_detail.update({"job_run_id": job_run_id, "object_type": "table"},
                                 {"$set": {"status": "Fail", "message": "Table migration failed", "end_time": end_time,
                                           "end_time_str": end_time_str}})
        return False

    log.info("END")
    if fail_count !=0:
        return False
    else:
        return True


def fetch_view_details(view_list, schema_name, discovery_id, job_run_id):
    """
    Fetching all view level details from view_discovery
    :param view_list:
    :param schema_name:
    :param discovery_id:
    :param job_run_id:
    :return: result
    """
    log.info("START")
    try:
        result = pd.DataFrame(
            db.idea_view_discovery_attr.find(
                {"view_nm": {"$in": view_list}, "batch_id": discovery_id,
                 "database_nm": schema_name},
                {"database_vendor": 1, "database_server_nm": 1, "database_nm": 1, "view_nm": 1,
                 "view_definition": 1, "_id": 0}))
        log.info(query_execute_successful)
        if result.empty:
            return False

    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        upd_status = update_job_run_detail_status(
            job_run_id, view_list, "Fail", "View discovery failed")
        if not upd_status:
            return False
        log.info(status)
        return False

    log.info("END")
    return list(result.itertuples(index=False, name=None))


def insert_view_details(value, job_run_id):
    """
    Inserting all the converted value in view_schema_conv table
    :param job_run_id:
    :param value:
    :return: boolean
    """
    log.info("START")
    info_df = pd.DataFrame(value,
                           columns=["src_database_vendor", "src_database_server_nm",
                                    "src_database_nm", "src_view_nm", "tgt_database_vendor",
                                    "tgt_database_server_nm", "tgt_database_nm", "tgt_schema_nm",
                                    "tgt_view_nm", "view_definition", "src_batch_id",
                                    "tgt_batch_id","view_id","exe_seq"])
    try:
        info_df["insert_dttm"] = datetime.utcnow()
        db.idea_ddl_view_conv_info.insert_many(info_df.T.to_dict().values())
        log.info(query_execute_successful)
    except Exception:
        log.error(traceback.format_exc())
        upd_status = update_job_run_detail_status(
            job_run_id, info_df["tgt_view_nm"], "Fail", "Insert view details failed")
        if not upd_status:
            return False
        return False

    log.info("END")
    return True


def duplicate_replacement(index_of_dot, ddl_statement):
    """
    Utility function to duplicate the database.view to database.schema.view in DDL script
    :param index_of_dot:
    :param ddl_statement:
    :return:
    """
    space_ind = ddl_statement[:index_of_dot].rfind(' ')
    section = ddl_statement[space_ind:index_of_dot]
    ddl_statement = ddl_statement[:space_ind] + section + '.' + ddl_statement[space_ind + 1:]
    return ddl_statement


def find_closing_parenthesis(ddl_statement, start_par):
    """
    Utility function to find the closing parenthesis of a function in DDL script
    :param ddl_statement:
    :param start_par:
    :return:
    """
    for _ in ddl_statement:
        close_par = ddl_statement.find(')', start_par + 1)
        next_start_par = ddl_statement.find('(', start_par + 1)
        total_start_par = len(re.findall(r'\(', ddl_statement[start_par + 1:close_par]))
        if total_start_par > 1:
            close_par = find_closing_parenthesis(ddl_statement, next_start_par)
        start_par = close_par

        if next_start_par > close_par or next_start_par == -1:
            return close_par


def get_view_convert(view_list, schema_name, discovery_id, tgt_database_server_nm, job_run_id,
                     target_db):
    """
    Fetching view details from discovery and converting it according to the target database
    :param view_list:
    :param schema_name:
    :param discovery_id:
    :param tgt_database_server_nm:
    :param job_run_id:
    :param target_db:
    :return:
    """
    try:
        batch_id = str(uuid.uuid4())

        view_res = fetch_view_details(view_list, schema_name, discovery_id, job_run_id)

        if not view_res:
            update_job_run_detail_status(
                job_run_id, view_res, 'Fail', "View DDL conversion failed")
            return False

        for idx, val in enumerate(view_res):
            teradata_ddl_conv = bteq_to_snowsql(view_res[idx][4])                        
            view_res[idx] = (view_res[idx][:4]
                             + (target_db, tgt_database_server_nm,
                                view_res[idx][2], view_res[idx][2], view_res[idx][3],
                                teradata_ddl_conv)
                             )
            view_res[idx] = view_res[idx] + (discovery_id, batch_id,"IDEA_"+view_res[idx][3],1)

        view_schema_conv_res = insert_view_details(view_res, job_run_id)
        if not view_schema_conv_res:
            return False

    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        upd_status = update_job_run_detail_status(
            job_run_id, view_list, "Fail", "View DDL Conversion failed")
        if not upd_status:
            return False
        log.info(status)
        return False

    return batch_id


def create_views(force_create,batch_id, job_run_id, link_id, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
    Show the last access details of a particular view mentioned by user
    :param job_run_id:
    :param link_id:
    :param batch_id:
    :return: json response
    """
    log.info("START")
    try:

        info_df = pd.DataFrame(
            db.idea_ddl_view_conv_info.find({"tgt_batch_id": batch_id}, {"tgt_view_nm": 1,
                                                                         "view_definition": 1,
                                                                         "tgt_database_nm":1,
                                                                         "tgt_schema_nm":1,"view_id":1,"exe_seq":1,"_id": 0}))
        if info_df.empty:
            end_time = int(datetime.utcnow().timestamp())
            end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
            db.job_run_detail.update({"job_run_id": job_run_id, "object_type": "view"},
                                     {"$set": {"status": "Fail","message": "View migration failed",  "end_time": end_time,
                                               "end_time_str": end_time_str}})
            return False

        info_df.sort_values(by= ["view_id","exe_seq"], inplace = True)

        view_ids = info_df["view_id"].drop_duplicates()
        fail_count = 0

        result = info_df.to_json()

        result = db.link_service.find_one({"link_service_id": link_id})

        hostname = result["db_hostname"]
        username = get_secret(link_id + "-username")
        # Decrypt the password
        password = get_secret(link_id + "-password")
        database = result['link_service_name']
        db_vendor = result['link_service_type'].split()[0]

        sf_conn_string = config[db_vendor]["conn"].format(hostname=hostname,
                                                          uid=username,
                                                          pwd=password,
                                                          database=database,
                                                          warehouse=config['snowflake'][
                                                              'schema_migration_dwh'])

        conn = pyodbc.connect(sf_conn_string, autocommit=True)
        cursor = conn.cursor()
        view_info = []

        for ids in view_ids:

            exe_ddls = info_df[info_df["view_id"]==ids].values.tolist()
            update_job_run_detail_status(job_run_id, [ids.split("IDEA_",1)[1]],
                                                        "InProgress", "")
            for itr in range(0, len(exe_ddls)):
                view_nme  = exe_ddls[itr][2]
                view_ddl = exe_ddls[itr][3]
                exe_sq = exe_ddls[itr][5]
                # view_id = exe_ddls[itr][5]
                tgt_database_nm = exe_ddls[itr][0]
                tgt_schema_nm = exe_ddls[itr][1]

                if exe_sq == 1:
                    try:
                        db_schema_query = "use {0}.{1}".format(config['snowflake']['database_snowflake'],tgt_schema_nm)
                        cursor.execute(db_schema_query)
                    except Exception as exception:
                        log.info(exception)
                        error_code = exception.args[0]
                        if error_code == "02000":
                            create_db_query = snowflake.schema_migration['create_db'].format(
                                schema_name=tgt_database_nm)
                            log.info(create_db_query)
                            cursor.execute(create_db_query)
                            use_db_query = snowflake.schema_migration['use_db'].format(
                                schema_name=tgt_database_nm)
                            log.info(use_db_query)
                            cursor.execute(use_db_query)
                            create_schema_query = snowflake.schema_migration['create_schema'].format(
                                schema_name=tgt_schema_nm)
                            log.info(create_schema_query)
                            cursor.execute(create_schema_query)
                            use_schema_query = snowflake.schema_migration['use_schema'].format(
                                schema_name=tgt_schema_nm)
                            log.info(use_schema_query)
                            cursor.execute(use_schema_query)
                try:
                    cursor.execute(view_ddl)
                    status = 'success'
                    if exe_sq == 1:
                        desc = 'View created successfully'
                except Exception as exception:
                    error_code = exception.args[0]
                    if error_code in ("42S01", "42710") and exe_sq == 1:
                        status = 'fail'
                        desc = "View already exists"
                        if force_create:
                            try:
                                drop_query = snowflake.schema_migration['drop_view']
                                drop_query = drop_query.format(
                                    view_name=view_nme)
                                cursor.execute(drop_query)
                                cursor.execute(view_ddl)
                                status = 'success'
                                desc = "View created (Brute Force Algorithm)"
                            except Exception as exception:
                                desc = "Query syntax error or object not present"
                                break
                        else:
                            desc = 'View created failed'
                            break
                    elif error_code in ["02000","42S02"] and exe_sq in [2,3,4]:
                        status = 'success'
                        log.info("Object grant related information does not exist")
                        log.info("DDL query : {}".format(view_ddl))

                    else:
                        log.info("error_code in break block: {}".format(error_code))
                        log.info("query in break: {}".format(view_ddl))
                        log.info(exception)
                        status = "fail"
                        desc = 'Query syntax error or object not present'
                        break

            if status == "success":
                # Updating job run detail collection
                if socket_flag:
                    send_message("sf_schema_run_status", {ids.split("IDEA_",1)[1]:{"object_type":"view","status":"Success","database": tgt_schema_nm}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                update_job_run_detail_status(job_run_id,[ids.split("IDEA_",1)[1]], "Success", desc)
            else:
                if socket_flag:
                    send_message("sf_schema_run_status", {ids.split("IDEA_",1)[1]:{"object_type":"view","status":"Fail","database": tgt_schema_nm}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                fail_count+=1
                # Updating job run detail collection
                update_job_run_detail_status(job_run_id,[ids.split("IDEA_",1)[1]], "Fail", desc)

        cursor.close()
        conn.close()

    except Exception:
        log.error(traceback.format_exc())
        end_time = int(datetime.utcnow().timestamp())
        end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
        db.job_run_detail.update({"job_run_id": job_run_id, "object_type": "view"},
                                 {"$set": {"status": "Fail","message": "View migration failed",  "end_time": end_time,
                                           "end_time_str": end_time_str}})
        return False
        
    log.info("END")
    if fail_count !=0:
        return False
    else:
        return True

def insert_role_details(value, role_list, job_run_id):
    """
       Inserting all the converted value in role_schema_conv_info table
       :param role_list:
       :param job_run_id:
       :param value:
       :return: boolean
       """
    log.info("START")
    try:
        info_df = pd.DataFrame(value, columns=["src_database_vendor", "src_database_server_nm",
                                               "tgt_database_vendor",
                                               "tgt_database_server_nm", "role_ddl", "exec_seq",
                                               "src_batch_id",
                                               "tgt_batch_id", "role_id"])
        info_df["insert_dttm"] = datetime.utcnow()
        info_df["migration_status"] = ""
        info_df["migration_comment"] = ""
        db.idea_ddl_role_conv_info.insert_many(info_df.T.to_dict().values())
        log.info(query_execute_successful)
    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        upd_status = update_job_run_detail_status(
            job_run_id, role_list, "Fail", "Insert role details failed")
        if not upd_status:
            return False
        log.info(status)
        return False
    log.info("END")
    return True


def get_role_convert(role_list, discovery_id, tgt_database_server_nm, job_run_id, target_db):
    """
    Fetching and converting the create role DDLs for target database
    :param role_list:
    :param discovery_id:
    :param tgt_database_server_nm:
    :param job_run_id:
    :param target_db:
    :return:
    """
    try:
        batch_id = str(uuid.uuid4())
        
        role_data_df = pd.DataFrame(db.idea_role_discovery_attr.find(
                {"batch_id": discovery_id, "role_nm": {"$in": role_list},"accessright_desc":{"$nin":not_in},"object_type":{"$nin":object_not_in}},
                {"database_vendor": 1, "database_server_nm": 1,
                "database_nm": 1, "object_nm": 1, "role_nm": 1,
                "accessright_desc": 1, "object_type": 1,"child_role_nm":1,"_id": 0}))

        role_query_list = []
        if not len(role_data_df):
            update_job_run_detail_status(
                    job_run_id, role_list, "Fail", "Role DDL conversion failed")
            return False
        
        role_data_df["object_type"].replace({"TABLE WITH NO PRIMARY INDEX AND NO PARTITIONING":"TABLE"},inplace = True)

        role_data_list = list(role_data_df.to_records(index=False))
        
        # Making a list of child role 
        child_list = role_data_df[role_data_df["child_role_nm"].notnull()].filter(["child_role_nm"]).values.tolist()

        # Making a list for parent child role
        parent_child_list = role_data_df[role_data_df["child_role_nm"].notnull()].filter(["role_nm" ,"child_role_nm"]).values.tolist()

        # Creating the role query
        for role_count in range(len(role_list)):
            role_id = "IDEA_"+role_list[role_count]
            role_create_ddl = snowflake.schema_migration["create_role"].format(
                                                role_name=role_list[role_count])

            role_query_list.append(list(role_data_list[role_count])[:1] + ["TERADATA",target_db, 
                                            tgt_database_server_nm, role_create_ddl, 1,
                                            discovery_id, batch_id,
                                            role_id])

        for role in range(len(role_data_list)):
            role_id = "IDEA_"+role_data_list[role][2]
            role_name = role_data_list[role][2]
            obj_type = role_data_list[role][7]
            obj_name = role_data_list[role][5]
            child_name = role_data_list[role][3]
            grant = role_data_list[role][6]
            db_nm = role_data_list[role][4]

            if child_name is not None:
                role_to_role_ddl = snowflake.cmd_role_cmd["ROLE"].format(child_role = child_name, 
                                                                        parent_role = role_name)
                
                role_query_list.append(list(role_data_list[role])[:1] + ["TERADATA",target_db, 
                                            tgt_database_server_nm, role_to_role_ddl, 2,
                                            discovery_id, batch_id,
                                            role_id])

            # Creating the role query for direct object access    
            else:
                if obj_name != "All" and grant.upper() not in drop_list_user:
                    role_grants_ddl = get_grant_stat(role_name,db_nm,obj_type,obj_name,grant.upper())

                    for ddl in role_grants_ddl:
                        role_query_list.append(list(role_data_list[role])[:1] + ["TERADATA",target_db, 
                                                    tgt_database_server_nm, ddl, 3,
                                                    discovery_id, batch_id,
                                                    role_id])
                else:
                    All_ddl = get_grant_stat(role_name,db_nm,"SCHEMA",obj_name,"ALL")
                    for ddl in All_ddl:
                        role_query_list.append(list(role_data_list[role])[:1] + ["TERADATA",target_db, 
                                                            tgt_database_server_nm, ddl, 3,
                                                            discovery_id, batch_id,
                                                            role_id])
            # Checking if the role is a child role anywhere and creating the query
            if len(child_list)>0 and child_name in child_list[0]:
                for itr in parent_child_list:
                    if itr[1] == child_name:
                        role_to_role_ddl = snowflake.cmd_role_cmd["ROLE"].format(child_role = itr[1], 
                                                                        parent_role = itr[0])

                        role_query_list.append(list(role_data_list[role])[:1] + ["TERADATA",target_db, 
                                                        tgt_database_server_nm, role_to_role_ddl, 6,
                                                        discovery_id, batch_id,
                                                        role_id])
                        parent_child_list.remove(itr)

        # Inserting the ddl for the role migrations 
        grants_create_ddl_res = insert_role_details(role_query_list, role_list, job_run_id)
        if not grants_create_ddl_res:
            log.info("Issue while inserting DDLs for role")
            return False
    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        upd_status = update_job_run_detail_status(
            job_run_id, role_list, "Fail", "Role DDL conversion failed")
        if not upd_status:
            return False
        log.info(status)
        return False
    return batch_id


def update_role_details(role_id, migration_status, migration_comment, tgt_batch_id):
    """
    Updating role details in collection idea_ddl_role_conv_info
    :param role_id:
    :param migration_status:
    :param migration_comment:
    :param tgt_batch_id:
    :return:
    """
    try:
        db.idea_ddl_role_conv_info.update_many({'role_id': role_id, 'tgt_batch_id': tgt_batch_id, 'exec_seq':{"$eq":1}},
                                               {'$set': {
                                                   'migration_comment': migration_comment,
                                                   'migration_status': migration_status}})
        db.idea_ddl_role_conv_info.update_many({'role_id': role_id, 'tgt_batch_id': tgt_batch_id, 'exec_seq':{"$ne":1}},
                                               {'$set': {
                                                   'migration_comment': " ",
                                                   'migration_status': migration_status}})                                                        

    except Exception:
        log.error(traceback.format_exc())
        status = {"update_role_details error Something went wrong. Please try later"}
        log.info(status)
        return False
    return True


def create_roles(force_create, batch_id, job_run_id, link_id, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
    Show the last access details of a particular role mentioned by user
    :param force_create:
    :param job_run_id:
    :param link_id:
    :param batch_id:
    :return: json response
    """
    log.info("START")
    try:

        info_df = pd.DataFrame(db.idea_ddl_role_conv_info.find({"tgt_batch_id": batch_id},
                                                               {"role_ddl": 1, "exec_seq": 1,
                                                                "role_id": 1, "_id": 0}).sort([("exec_seq",1)]))

        if info_df.empty:
            log.info("message : record not found for roles")
            end_time = int(datetime.utcnow().timestamp())
            end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
            db.job_run_detail.update({"job_run_id": job_run_id, "object_type": "role"},
                                     {"$set": {"status": "Fail", "message": role_migration_fail, "end_time": end_time,
                                               "end_time_str": end_time_str}})
            return False
        res_df = info_df
        fail_count = 0
        result = db.link_service.find_one({"link_service_id": link_id})
        hostname = result["db_hostname"]
        username = get_secret(link_id + "-username")
        # Decrypt the password
        password = get_secret(link_id + "-password")
        database = result['link_service_name']
        db_vendor = result['link_service_type'].split()[0]

        sf_conn_string = config[db_vendor]["conn"].format(hostname=hostname,
                                                          uid=username,
                                                          pwd=password,
                                                          database=database,
                                                          warehouse=config['snowflake'][
                                                              'schema_migration_dwh'])
        conn = pyodbc.connect(sf_conn_string, autocommit=True)
        cursor = conn.cursor()

        # Creating the df for all the role_id
        role_id_df = res_df["role_id"]
        role_id_df.drop_duplicates(inplace = True)
        
        for role_id in role_id_df:
            
            # Getting all the ddls for role_id
            role_df = res_df[res_df["role_id"] == role_id]
            update_job_run_detail_status(job_run_id, [role_id.split("IDEA_",1)[1]],
                                                        "InProgress", "")
            for itr in range(len(role_df)):
                log.info(itr)
                log.info("executing the query : {}".format(role_df.iloc[itr, 0]))
                try:
                    cursor.execute(role_df.iloc[itr, 0])
                    status = "success"
                    if role_df.iloc[itr,1]==1:
                        desc = 'Role created successfully'
                except Exception as exception:
                    error_code = exception.args[0]
                    ex_seq = role_df.iloc[itr, 1]
                    if error_code == "42710" and ex_seq ==1:
                        status = "fail"
                        desc = "Role already exists"
                        if force_create:
                            try:
                                drop_query = snowflake.schema_migration["drop_role"]
                                drop_query = drop_query.format(
                                    Role_Name=role_df.iloc[itr, 0].split()[2])
                                cursor.execute(drop_query)
                                cursor.execute(role_df.iloc[itr, 0])
                                status = "success"
                                desc = role_created_brute_force
                            except Exception as exception:
                                desc = role_migration_fail
                                break
                        else:
                            break
                               
                    elif error_code == "02000" and ex_seq in [2,6]:
                        log.info("query: {}".format(role_df.iloc[itr, 0]))
                        log.info("Exception = {}".format(exception))
                        log.info("Role not present")

                    elif error_code in ["02000","42S02"] and ex_seq in [3,4,5]:
                        log.info("query: {}".format(role_df.iloc[itr, 0]))
                        log.info("Exception = {}".format(exception))
                        log.info("Object not present")

                    else:
                        log.info("error_code in break block: {}".format(error_code))
                        log.info("query in break: {}".format(role_df.iloc[itr, 0]))
                        log.info(exception)
                        status = "fail"
                        desc = role_migration_fail
                        break

            if status == "success":
                log.info(role_id)
                # Updating job run detail collection
                if socket_flag:
                    send_message("sf_schema_run_status", {role_id.split("IDEA_",1)[1]:{"object_type":"role","status":"Success"}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                update_job_run_detail_status(job_run_id,[role_id.split("IDEA_",1)[1]], "Success", desc)
                
                # Updating idea_role_ddl_conv_info collectio 
                update_role_details(role_id, "success","Role created successfully",batch_id)
            else:
                if socket_flag:
                    send_message("sf_schema_run_status", {role_id.split("IDEA_",1)[1]:{"object_type":"role","status":"Fail"}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                fail_count+=1
                # Updating job run detail collection
                update_job_run_detail_status(job_run_id,[role_id.split("IDEA_",1)[1]], "Fail", desc)
                
                # Updating idea_role_ddl_conv_info collectio 
                update_role_details(role_id, "fail",desc,batch_id)
                
        cursor.close()
        conn.close()

    except Exception:
        log.error(traceback.format_exc())
        end_time = int(datetime.utcnow().timestamp())
        end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
        db.job_run_detail.update({"job_run_id": job_run_id, "object_type": "role"},
                                 {"$set": {"status": "Fail", "message": role_migration_fail, "end_time": end_time,
                                           "end_time_str": end_time_str}})
        return False
    log.info("END")
    if fail_count !=0:
        return False
    else:
        return True


def insert_user_details(value, user_list, job_run_id):
    """
       Inserting all the converted value in user_schema_conv_info table
       :param user_list:
       :param job_run_id:
       :param value:
       :return: boolean
       """
    log.info("START")
    try:
        info_df = pd.DataFrame(value, columns=["src_database_vendor", "src_database_server_nm",
                                               "tgt_database_vendor", "tgt_database_server_nm",
                                               "user_ddl", "exec_seq", "src_batch_id",
                                               "tgt_batch_id",
                                               "user_id"])
        info_df["insert_dttm"] = datetime.utcnow()
        info_df["migration_status"] = ""
        info_df["migration_comment"] = ""
        db.idea_ddl_user_conv_info.insert_many(info_df.T.to_dict().values())
        log.info(query_execute_successful)
    except Exception:
        log.error(traceback.format_exc())
        status = {"insert_user_details error": something_went_wrong}
        log.info(status)
        upd_status = update_job_run_detail_status(
            job_run_id, user_list, "Fail", "Insert user details failed")
        if not upd_status:
            return False
        return False

    log.info("END")
    return True


def get_user_convert(user_list, discovery_id, tgt_database_server_nm, job_run_id, target_db):
    """
    Fetching and converting the create user DDLs for target database
    :param user_list:
    :param discovery_id:
    :param tgt_database_server_nm:
    :param job_run_id:
    :param target_db:
    :return:
    """
    try:
        batch_id = str(uuid.uuid4())

        # Getting user data from user discovery
        log.info("start")
        user_data_dis = pd.DataFrame(db.idea_user_discovery_attr.find(
                        {"batch_id": discovery_id, "user_nm": {"$in": user_list},"accessright_desc":{"$nin":not_in},"object_type":{"$nin":object_not_in}},
                        {"role_nm": 1, "database_vendor": 1, "database_server_nm": 1,
                        "user_nm": 1,"database_nm":1,"object_nm":1,"object_type":1,
                        "accessright_desc":1,"_id": 0}))


        if not len(user_data_dis):
            update_job_run_detail_status(
            job_run_id, user_list, "Fail", "User DDL conversion failed")
            return True
        
        user_data_dis["object_type"].replace({"TABLE WITH NO PRIMARY INDEX AND NO PARTITIONING":"TABLE"},inplace = True)
        user_data_list = list(user_data_dis.to_records(index=False))

        user_query_list = []
        grant_role_list = []

        # Creating user query for all the users
        for user_count in range(len(user_list)):
            user_id = "IDEA_"+user_list[user_count]
            user_create_ddl = snowflake.schema_migration["create_user"].format(
            user_name=user_list[user_count])

            user_query_list.append(list(user_data_list[user_count])[3:4]+list(user_data_list[user_count])[0:1]+ [target_db,
                                        tgt_database_server_nm,
                                        user_create_ddl, 1,discovery_id,
                                        batch_id, user_id])

        # Creating role and grants query for users  
        for role_count in range(len(user_data_list)):
            user_name  = user_data_list[role_count][2]
            user_id = "IDEA_"+user_name

            if user_data_list[role_count][3] is not None:
                
                role_grants_ddl = snowflake.schema_migration["grant_role"].format(
                            Role_Nm=user_data_list[role_count][3],
                            User_Nm=user_name)
                user_query_list.append(list(user_data_list[role_count])[3:4]+list(user_data_list[role_count])[0:1]+ [target_db,
                                            tgt_database_server_nm,
                                            role_grants_ddl, 2,discovery_id,
                                            batch_id, user_id])

                # Creating a grant of usage on warehouse for the role
                role_wh_grant_ddl = snowflake.schema_migration["use_warehouse"].format(
                            Role_Nm=user_data_list[role_count][3])
                user_query_list.append(list(user_data_list[role_count])[3:4]+list(user_data_list[role_count])[0:1]+ [target_db,
                                            tgt_database_server_nm,
                                            role_wh_grant_ddl, 6,discovery_id,
                                            batch_id, user_id])
                

            # To create the ddl for direct access
            else:
                role_nme = "IDEA_"+user_name
                # Cretaing the role dll
                if role_nme not in grant_role_list:
                    create_ddl_role = snowflake.schema_migration["create_role"].format(role_name =role_nme)

                    user_query_list.append(list(user_data_list[role_count])[3:4]+list(user_data_list[role_count])[0:1]+ [target_db,
                                                tgt_database_server_nm,
                                                create_ddl_role, 3,discovery_id,
                                                batch_id, user_id])

                    create_role_to_user_ddl = snowflake.schema_migration["grant_role"].format(Role_Nm =role_nme,User_Nm = user_name)
                    user_query_list.append(list(user_data_list[role_count])[3:4]+list(user_data_list[role_count])[0:1]+ [target_db,
                                            tgt_database_server_nm,
                                            create_role_to_user_ddl, 5,discovery_id,
                                            batch_id, user_id])
                    
                    # Creating a grant of usage on warehouse for the role
                    role_wh_grant_ddl = snowflake.schema_migration["use_warehouse"].format(
                            Role_Nm=role_nme)
                    user_query_list.append(list(user_data_list[role_count])[3:4]+list(user_data_list[role_count])[0:1]+ [target_db,
                                            tgt_database_server_nm,
                                            role_wh_grant_ddl, 6,discovery_id,
                                            batch_id, user_id])

                    # creating grant to sysadmin
                    role_wh_grant_ddl = snowflake.schema_migration["use_sysadmin"].format(
                            Role_Nm=role_nme)
                    user_query_list.append(list(user_data_list[role_count])[3:4]+list(user_data_list[role_count])[0:1]+ [target_db,
                                            tgt_database_server_nm,
                                            role_wh_grant_ddl,7,discovery_id,
                                            batch_id, user_id])

                    grant_role_list.append(role_nme)
                grant = user_data_list[role_count][7].upper()

                # Creating ddl for role if its not a drop grant for view and table
                if user_data_list[role_count][5] !="All" and  grant not in drop_list_user:

                    role_grants_ddl = get_grant_stat(role_nme,user_data_list[role_count][4],
                                                            user_data_list[role_count][6],user_data_list[role_count][5],
                                                            grant)

                    for ddl in role_grants_ddl:
                        user_query_list.append(list(user_data_list[role_count])[3:4]+list(user_data_list[role_count])[0:1]+ [target_db,
                                                tgt_database_server_nm,
                                                ddl, 4,discovery_id,
                                                batch_id, user_id])
                else :
                    All_ddl = get_grant_stat(role_nme,user_data_list[role_count][4],
                                                                    "SCHEMA",user_data_list[role_count][5],
                                                                "ALL")
                    for ddl in All_ddl:
                        user_query_list.append(list(user_data_list[role_count])[3:4]+list(user_data_list[role_count])[0:1]+ [target_db,
                                                        tgt_database_server_nm,
                                                        ddl, 4,discovery_id,
                                                        batch_id, user_id])
                
        # User execution ddl insertion
        user_create_ddl_res = insert_user_details(user_query_list, user_list, job_run_id)
        if not user_create_ddl_res:
            log.info("Issue while inserting DDLs ")
            return False
    except Exception:
        log.error(traceback.format_exc())
        status = {"get_user_convert error": something_went_wrong}
        log.info(status)
        upd_status = update_job_run_detail_status(
            job_run_id, user_list, "Fail", "User DDL conversion failed")
        if not upd_status:
            return False
        return False
    return batch_id


def update_user_details(user_id, migration_status, migration_comment, tgt_batch_id):
    """
    Updating user details in collection idea_ddl_user_conv_info
    :param user_id:
    :param migration_status:
    :param migration_comment:
    :param tgt_batch_id:
    :return:
    """
    try:
        db.idea_ddl_user_conv_info.update_many({'user_id': user_id, 'tgt_batch_id': tgt_batch_id, 'exec_seq':{"$eq":1}},
                                               {'$set': {
                                                   'migration_comment': migration_comment,
                                                   'migration_status': migration_status}})
        db.idea_ddl_user_conv_info.update_many({'user_id': user_id, 'tgt_batch_id': tgt_batch_id, 'exec_seq':{"$ne":1}},
                                               {'$set': {
                                                   'migration_comment': " ",
                                                   'migration_status': migration_status}})                                                   

    except Exception:
        log.error(traceback.format_exc())
        status = {"update_user_details error": something_went_wrong}
        log.info(status)
        return False
    return True


def create_users(force_create, batch_id, job_run_id, link_id, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
    Show the last access details of a particular user mentioned by user
    :param force_create:
    :param job_run_id:
    :param link_id:
    :param batch_id:
    :return: json response
    """
    log.info("START")
    try:
        info_df = pd.DataFrame(db.idea_ddl_user_conv_info.find({"tgt_batch_id": batch_id},
                                                               {"user_ddl": 1, "exec_seq": 1,
                                                                "user_id": 1, "_id": 0}).sort([("exec_seq",1)]))
        fail_count = 0

        if info_df.empty:
            end_time = int(datetime.utcnow().timestamp())
            end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
            db.job_run_detail.update({"job_run_id": job_run_id, "object_type": "user"},
                                     {"$set": {"status": "Fail", "message": user_migration_fail,
                                               "end_time": end_time,
                                               "end_time_str": end_time_str}})
            return False
        res_df = info_df

        result = db.link_service.find_one({"link_service_id": link_id})
        hostname = result["db_hostname"]
        username = get_secret(link_id + "-username")
        # Decrypt the password
        password = get_secret(link_id + "-password")
        database = result['link_service_name']
        db_vendor = result['link_service_type'].split()[0]

        sf_conn_string = config[db_vendor]["conn"].format(hostname=hostname,
                                                          uid=username,
                                                          pwd=password,
                                                          database=database,
                                                          warehouse=config['snowflake'][
                                                              'schema_migration_dwh'])

        conn = pyodbc.connect(sf_conn_string, autocommit=True)
        cursor = conn.cursor()

        # Gatting all the distinct user id
        user_id_df = res_df["user_id"]
        user_id_df.drop_duplicates(inplace = True)


        for userid in user_id_df:
            
            # Getting all the ddl for a given user_id
            user_df = res_df[res_df["user_id"] == userid]

            update_job_run_detail_status(job_run_id, [userid.split("IDEA_",1)[1]],
                                                        "InProgress", "")
            for itr in range(len(user_df)):
                try:
                    log.info(itr)
                    log.info("executing the query : {}".format(user_df.iloc[itr, 0]))
                    cursor.execute(user_df.iloc[itr, 0])
                    status = "success"
                    if user_df.iloc[itr, 1] == 1:
                        desc = 'User created successfully'
                except Exception as exception:
                    error_code = exception.args[0]
                    if error_code == "42710" and user_df.iloc[itr, 1] == 1:
                        status = "fail"
                        desc = "User already exists"
                        if force_create:
                            try:
                                drop_query = snowflake.schema_migration["drop_user"]
                                drop_query = drop_query.format(
                                    User_Name=user_df.iloc[itr, 0].split()[2])
                                cursor.execute(drop_query)
                                cursor.execute(user_df.iloc[itr, 0])
                                status = "success"
                                desc = "User created (Brute Force Algorithm)"
                            except Exception as exception:
                                desc = user_migration_fail
                                break
                        else:
                            break

                    # If role is not there
                    elif error_code == "02000" and user_df.iloc[itr, 1] in [2]:
                        log.info("query: {}".format(user_df.iloc[itr, 0]))
                        log.info("Exception = {}".format(exception))
                        log.info("Corresponding role doesn't exist")

                    # If role already exist
                    elif error_code == "42710" and user_df.iloc[itr, 1] == 3:
                        log.info("query: {}".format(user_df.iloc[itr, 0]))
                        log.info("Exception = {}".format(exception))
                        log.info("Corresponding roles already exist")

                    # If the objet does not exist
                    elif error_code in["02000","42S02"] and user_df.iloc[itr, 1] in [4,5,6,7]:
                        log.info("query: {}".format(user_df.iloc[itr, 0]))
                        log.info("Exception = {}".format(exception))
                        log.info("Corresponding object does not exist")

                    else:
                        log.info("error code in break block: {}".format(error_code))
                        log.info("query in break: {}".format(user_df.iloc[itr, 0]))
                        log.info("Exception = {}".format(exception))
                        desc = user_migration_fail
                        status = "fail"
                        break
            if status == "success":
                if socket_flag:
                    send_message("sf_schema_run_status", {user_df.iloc[itr, 2].split("IDEA_",1)[1]:{"object_type":"user","status":"Success"}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                update_job_run_detail_status(
                    job_run_id, [user_df.iloc[itr, 2].split("IDEA_",1)[1]], "Success", desc)
                update_user_details(user_df.iloc[itr, 2], "success",
                                            "User created successfully!",
                                            batch_id)
            else:
                if socket_flag:
                    send_message("sf_schema_run_status", {user_df.iloc[itr, 2].split("IDEA_",1)[1]:{"object_type":"user","status":"Fail"}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                fail_count+=1
                update_job_run_detail_status(
                            job_run_id, [user_df.iloc[itr, 2].split("IDEA_",1)[1]], "Fail",
                            desc)
                update_user_details(user_df.iloc[itr, 2], "fail",
                                            desc,
                                            batch_id)
                
        cursor.close()
        conn.close()

    except Exception :
        log.error(traceback.format_exc())
        end_time = int(datetime.utcnow().timestamp())
        end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
        db.job_run_detail.update({"job_run_id": job_run_id, "object_type": "user"},
                                 {"$set": {"status": "Fail", "message": user_migration_fail,
                                           "end_time": end_time,
                                           "end_time_str": end_time_str}})
        return False
    log.info("END")

    if fail_count!=0:
        log.info("fail_count : {} ".format(fail_count))
        return False
    else:
        return True


def update_job_run_detail_status(job_run_id, object_name, status, message):
    """
    Updating the status of items inserted in collection job_run_detail with respect to the job
    run ID
    :param job_run_id:
    :param object_name:
    :param status:
    :return:
    """
    try:
        log.info("Updating job run item status")
        for name in object_name:
            end_time = int(datetime.utcnow().timestamp())
            end_time_str = datetime.fromtimestamp(end_time).strftime(idea_date_format)
            db.job_run_detail.update_one({"job_run_id": job_run_id, "object_name": name},
                                         {"$set": {"status": status, "message": message,
                                                   "end_time": end_time,
                                                   "end_time_str": end_time_str}})

            log.info(query_execute_successful)

    except Exception:
        log.error(traceback.format_exc())
        status = {"message": something_went_wrong}
        log.info(status)
        return False
    return True


def create_object_user_role(table_list,discovery_id,batch_id, schema_name):
    """
    Fetching the details from user and role table and creating the ddls 
    """

    try:
        schema_name = [schema_name]
        obj_user_df = pd.DataFrame(db.idea_user_discovery_attr.find(
                            {"batch_id": discovery_id, "object_nm": {"$in": table_list},"database_nm": {"$in": schema_name},"accessright_desc":{"$nin":not_in},"object_type":{"$nin":object_not_in}},
                            {"role_nm": 1, "database_vendor": 1, "database_server_nm": 1,
                            "user_nm": 1,"database_nm":1,"object_nm":1,"object_type":1,
                            "accessright_desc":1,"_id": 0}))
        
        obj_role_df = pd.DataFrame(db.idea_role_discovery_attr.find(
                            {"batch_id": discovery_id,"object_nm": {"$in": table_list},"database_nm": {"$in": schema_name},"accessright_desc":{"$nin":not_in},"object_type":{"$nin":object_not_in}},
                            {"database_vendor": 1, "database_server_nm": 1,
                            "database_nm": 1, "object_nm": 1, "role_nm": 1,
                            "accessright_desc": 1, "object_type": 1,"child_role_nm":1,"_id": 0}))

        # Creating grant for objects in user
        if len(obj_user_df)>0:
            user_ddl = []

            try:
                obj_user_df["object_type"].replace({"TABLE WITH NO PRIMARY INDEX AND NO PARTITIONING":"TABLE"},inplace = True)
                obj_user_data_list = list(obj_user_df.to_records(index=False))

                for itr in obj_user_data_list:
                    if itr[5] in table_list:
                        table_id = "IDEA_"+itr[5]
                        grant = itr[7]
                        role_nme = "IDEA_"+itr[2]
                        obj_name = itr[5]
                        obj_type = itr[6]
                        db_nm = itr[4]
                        sr_db_vendor = itr[0]
                        sr_db_server = itr[1]
                
                        if obj_name !="All" and grant not in drop_list_user:
                            role_grants_ddl = get_grant_stat(role_nme,db_nm,obj_type,obj_name,grant)

                            for ddl in role_grants_ddl:
                                user_ddl.append(list([sr_db_vendor,sr_db_server,db_nm,obj_name,"snowflake",sr_db_server,db_nm,obj_name,ddl,batch_id,table_id,2]))
                        else :
                            All_ddl = get_grant_stat(role_nme,db_nm,"SCHEMA",obj_name,"ALL")
                            for ddl in All_ddl:
                                user_ddl.append(list([sr_db_vendor,sr_db_server,db_nm,obj_name,"snowflake",sr_db_server,db_nm,obj_name,ddl,batch_id,table_id,2]))
                # Inserting value to into the collection
                log.info("Inserting user grant ddls")
                user_df = pd.DataFrame(user_ddl, columns=['src_database_vendor',
                                                            'src_database_server_nm',
                                                            'src_database_nm', 'src_table_nm',
                                                            'tgt_database_vendor',
                                                            'tgt_database_server_nm',
                                                            'tgt_database_nm', 'tgt_table_nm',
                                                            'object_defination_txt', 'tgt_batch_id','table_id','exe_seq'])
                user_df["insert_dttm"] = datetime.utcnow()
                db.idea_ddl_schema_conv_info.insert_many(user_df.T.to_dict().values())

            except Exception:
                log.info("user grant fail")
                log.error(traceback.format_exc())
                return False
        if len(obj_role_df)>0:
            try:
                role_ddl = []
                obj_role_df["object_type"].replace({"TABLE WITH NO PRIMARY INDEX AND NO PARTITIONING":"TABLE"},inplace = True)
        
                obj_role_data_list= list(obj_role_df.to_records(index=False))
                log.info("2532")
                # Creating the for object in role
                for itr in obj_role_data_list:
                    if itr[5] in table_list:
                        table_id = "IDEA_"+itr[5]
                        grant = itr[6]
                        role_nme = itr[2]
                        obj_name = itr[5]
                        obj_type = itr[7]
                        db_nm = itr[4]
                        sr_db_vendor = itr[0]
                        sr_db_server = itr[1]
                        if obj_name != "All" and grant.upper() not in drop_list_user:
                            role_grants_ddl = get_grant_stat(role_nme,db_nm,obj_type,obj_name,grant.upper())

                            for ddl in role_grants_ddl:
                                role_ddl.append(list([sr_db_vendor,sr_db_server,db_nm,obj_name,"snowflake",sr_db_server,db_nm,obj_name,ddl,batch_id,table_id,2]))
                        else:
                            All_ddl = get_grant_stat(role_nme,db_nm,"SCHEMA",obj_name,"ALL")
                            for ddl in All_ddl:
                                role_ddl.append(list([sr_db_vendor,sr_db_server,db_nm,obj_name,"snowflake",sr_db_server,db_nm,obj_name,ddl,batch_id,table_id,2]))

                # Inserting the ddl into the collectoin
                log.info("Inserting role grant ddl for object")
                role_df = pd.DataFrame(role_ddl, columns=['src_database_vendor',
                                                            'src_database_server_nm',
                                                            'src_database_nm', 'src_table_nm',
                                                            'tgt_database_vendor',
                                                            'tgt_database_server_nm',
                                                            'tgt_database_nm', 'tgt_table_nm',
                                                            'object_defination_txt', 'tgt_batch_id','table_id','exe_seq'])
                role_df["insert_dttm"] = datetime.utcnow()
                db.idea_ddl_schema_conv_info.insert_many(role_df.T.to_dict().values())
            except Exception:
                log.info("role grant fail")
                log.error(traceback.format_exc())
                return False

    except Exception:
        log.error(traceback.format_exc())
        return False
    return True


def create_schema_user_role(view_list,discovery_id,batch_id, schema_name):
    """
    Fetching the details from user and role table and creating the ddls 
    """

    try:
        schema_name = [schema_name]
        obj_user_df = pd.DataFrame(db.idea_user_discovery_attr.find(
                            {"batch_id": discovery_id, "object_nm": {"$in": view_list},"database_nm": {"$in": schema_name},"accessright_desc":{"$nin":not_in},"object_type":{"$nin":object_not_in}},
                            {"role_nm": 1, "database_vendor": 1, "database_server_nm": 1,
                            "user_nm": 1,"database_nm":1,"object_nm":1,"object_type":1,
                            "accessright_desc":1,"_id": 0}))
        
        obj_role_df = pd.DataFrame(db.idea_role_discovery_attr.find(
                            {"batch_id": discovery_id,"object_nm": {"$in": view_list},"database_nm": {"$in": schema_name},"accessright_desc":{"$nin":not_in},"object_type":{"$nin":object_not_in}},
                            {"database_vendor": 1, "database_server_nm": 1,
                            "database_nm": 1, "object_nm": 1, "role_nm": 1,
                            "accessright_desc": 1, "object_type": 1,"child_role_nm":1,"_id": 0}))

        # Creating grant for objects in user
        if len(obj_user_df)>0:
            user_ddl = []

            try:
                obj_user_data_list = list(obj_user_df.to_records(index=False))

                for itr in obj_user_data_list:
                    if itr[5] in view_list:
                        table_id = "IDEA_"+itr[5]
                        grant = itr[7]
                        role_nme = "IDEA_"+itr[2]
                        obj_name = itr[5]
                        obj_type = itr[6]
                        db_nm = itr[4]
                        sr_db_vendor = itr[0]
                        sr_db_server = itr[1]
                
                        if obj_name !="All" and grant not in drop_list_user:
                            role_grants_ddl = get_grant_stat(role_nme,db_nm,obj_type,obj_name,grant)

                            for ddl in role_grants_ddl:
                                user_ddl.append(list([sr_db_vendor,sr_db_server,db_nm,obj_name,"snowflake",sr_db_server,db_nm,db_nm,obj_name,ddl,discovery_id,batch_id,table_id,2]))
                        else :
                            All_ddl = get_grant_stat(role_nme,db_nm,"SCHEMA",obj_name,"ALL")
                            for ddl in All_ddl:
                                user_ddl.append(list([sr_db_vendor,sr_db_server,db_nm,obj_name,"snowflake",sr_db_server,db_nm,db_nm,obj_name,ddl,discovery_id,batch_id,table_id,2]))
                # Inserting value to into the collection
                log.info("Inserting user grant ddls")
                user_df = pd.DataFrame(user_ddl, columns=['src_database_vendor',
                                                            'src_database_server_nm',
                                                            'src_database_nm', 'src_view_nm',
                                                            'tgt_database_vendor',
                                                            'tgt_database_server_nm','tgt_database_nm',
                                                            'tgt_schema_nm', 'tgt_view_nm',
                                                            'view_definition','src_batch_id','tgt_batch_id','view_id','exe_seq'])


                user_df["insert_dttm"] = datetime.utcnow()
                db.idea_ddl_view_conv_info.insert_many(user_df.T.to_dict().values())

            except Exception:
                log.info("user grant fail")
                log.error(traceback.format_exc())
                return False

        if len(obj_role_df)>0:
            try:
                role_ddl = []        
                obj_role_data_list= list(obj_role_df.to_records(index=False))
                # Creating the for object in role
                for itr in obj_role_data_list:
                    if itr[5] in view_list:
                        table_id = "IDEA_"+itr[5]
                        grant = itr[6]
                        role_nme = itr[2]
                        obj_name = itr[5]
                        obj_type = itr[7]
                        db_nm = itr[4]
                        sr_db_vendor = itr[0]
                        sr_db_server = itr[1]
                        if obj_name != "All" and grant.upper() not in drop_list_user:
                            role_grants_ddl = get_grant_stat(role_nme,db_nm,obj_type,obj_name,grant.upper())

                            for ddl in role_grants_ddl:
                                role_ddl.append(list([sr_db_vendor,sr_db_server,db_nm,obj_name,"snowflake",sr_db_server,db_nm,db_nm,obj_name,ddl,discovery_id,batch_id,table_id,2]))
                            
                        else:
                            All_ddl = get_grant_stat(role_nme,db_nm,"SCHEMA",obj_name,"ALL")
                            for ddl in All_ddl:
                                role_ddl.append(list([sr_db_vendor,sr_db_server,db_nm,obj_name,"snowflake",sr_db_server,db_nm,db_nm,obj_name,ddl,discovery_id,batch_id,table_id,2]))

                # Inserting the ddl into the collectoin
                log.info("Inserting role grant ddl for object")
                role_df = pd.DataFrame(role_ddl, columns=['src_database_vendor',
                                                            'src_database_server_nm',
                                                            'src_database_nm', 'src_view_nm',
                                                            'tgt_database_vendor',
                                                            'tgt_database_server_nm','tgt_database_nm',
                                                            'tgt_schema_nm', 'tgt_view_nm',
                                                            'view_definition','src_batch_id','tgt_batch_id','view_id','exe_seq'])
                role_df["insert_dttm"] = datetime.utcnow()
                db.idea_ddl_view_conv_info.insert_many(role_df.T.to_dict().values())
            except Exception:
                log.info("role grant fail")
                log.error(traceback.format_exc())
                return False

    except Exception:
        log.error(traceback.format_exc())
        return False
    return True


def get_grant_stat(grantee_name,db_name, object_type, object_name,grant):

    try:
        if object_type.upper() == "TABLE":
            grant_stat = snowflake.cmd_role_cmd["TABLE"][grant].format(object_name=object_name, db_name=db_name,role_name=grantee_name)
            grant_lst = [grant_stat]
            grant_stat = snowflake.cmd_role_cmd["USAGES_DB"].format(db_name=db_name,role_name=grantee_name)
            grant_lst.append(grant_stat)
            grant_stat = snowflake.cmd_role_cmd["USAGES_SCHEMA"].format(db_name=db_name,role_name=grantee_name)
            grant_lst.append(grant_stat)
            return grant_lst

        elif object_type.upper() == "VIEW":
            grant_stat = snowflake.cmd_role_cmd["VIEW"][grant].format(object_name=object_name, db_name=db_name,role_name=grantee_name)
            grant_lst = [grant_stat]
            grant_stat = snowflake.cmd_role_cmd["USAGES_DB"].format(db_name=db_name,role_name=grantee_name)
            grant_lst.append(grant_stat)
            grant_stat = snowflake.cmd_role_cmd["USAGES_SCHEMA"].format(db_name=db_name,role_name=grantee_name)
            grant_lst.append(grant_stat)
            return grant_lst

        elif object_type.upper() == "SCHEMA":
            grant_stat = snowflake.cmd_role_cmd["SCHEMA"]["ALL_DB"].format(db_name=db_name,role_name=grantee_name)
            grant_lst = [grant_stat]
            grant_stat = snowflake.cmd_role_cmd["SCHEMA"][grant].format(db_name=db_name,role_name=grantee_name)
            grant_lst.append(grant_stat)
            grant_stat = snowflake.cmd_role_cmd["SCHEMA"]["TABLE"][grant].format(db_name=db_name,role_name=grantee_name)
            grant_lst.append(grant_stat)
            grant_stat = snowflake.cmd_role_cmd["SCHEMA"]["VIEW"][grant].format(db_name=db_name,role_name=grantee_name)
            grant_lst.append(grant_stat)
            grant_stat = snowflake.cmd_role_all["TABLE"][grant].format(db_name=db_name,role_name=grantee_name)
            grant_lst.append(grant_stat)
            grant_stat = snowflake.cmd_role_all["VIEW"][grant].format(db_name=db_name,role_name=grantee_name)
            grant_lst.append(grant_stat)
            return grant_lst

    except:
        return ["Keyword not in ddl conversion"]

def drop_grants_stat(grantee_name,db_name,object_name,object_type):
    grant_lst = []
    drop_query_dict = snowflake.revoke_cmd
    if object_type == "TABLE":
        grant_stat = drop_query_dict["TABLE"].format(db_name = db_name,role_name = grantee_name,object_name = object_name)
        grant_lst.append(grant_stat)
    else:
        grant_stat = drop_query_dict["VIEW"].format(db_name = db_name,role_name = grantee_name,object_name = object_name)
        grant_lst.append(grant_stat)
    return grant_lst
