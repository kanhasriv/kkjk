"""
This service  run consumer for Discovery and Schema
"""
import logging
import logging.handlers
import json
import traceback
import _thread
from kafka import KafkaConsumer
from config import config
from consumers.discover import discover
from consumers.schema_migration import schema_migration


# Log
log = logging.getLogger(config["logging"]["name"])
log.setLevel(int(config["logging"]["logging_level"]))
handler = logging.handlers.RotatingFileHandler(
            config["logging"]["filename"],
            maxBytes =int(config["logging"]["logging_maxBytes"]),
            backupCount = int(config["logging"]["logging_backup_count"]))

# Set the log format
handler.setFormatter(
        logging.Formatter("%(asctime)s|%(levelname)-5.5s|[%(filename)s:%(lineno)s-%(funcName)20s()]|%(message)s"))
log.addHandler(handler)

# set consumer for Discover and Schema
topic = config["kafka"]["topic_discovery_schema"]
server = config["kafka"]["host"]
consumer = KafkaConsumer(topic, bootstrap_servers=[server])

log.info("Snowflake Discovery Service initialized Successfully")

for message in consumer:
    data = message.value.decode("utf-8")
    data = json.loads(data)
    if data["type"] == "DISCOVER":
        _thread.start_new_thread(discover, (data,))
    if data["type"] == "SCHEMA_MIGRATION":
        _thread.start_new_thread(schema_migration, (data,))



