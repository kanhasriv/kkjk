import pyodbc
import logging
import traceback
from config import config, db
log = logging.getLogger(config["logging"]["name"])


def job_run(data):
    try:
        job_run_id = data['jobRunID']
        update_query = {"jobRunID": job_run_id}
        log.info("db.job_run.update(): update_query: {}".format(data))
        db.job_run.update(update_query, {"$set": data}, upsert=True)
        status = "Success"
    except Exception as e_error :
        log.error(e_error)
        status = "Fail"
    return status
