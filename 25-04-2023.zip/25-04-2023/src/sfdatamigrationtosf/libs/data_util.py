"""
This file has all supportive functions for data migration
"""
import traceback
from datetime import datetime, timedelta, date
import time
import logging
import pyodbc
import re
import pandas as pd
from config import (config, db, glue_client, send_message, update_dashboard)
from libs.util import abcr_job_run
from libs import snowflake
from libs.secret_manager import get_secret

log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'
blob_sf_failed = "Blob to snowflake migration failed"
fail_dict = {"status_sf": "Fail",
             "end_time_sf": int(datetime.utcnow().timestamp()),
             "copy_sf": None,
             "noofrows_read_sf": 0,
             "noofrows_skipped_sf": 0,
             "noofrows_written_sf": 0
             }
log_url_aws = "https://console.aws.amazon.com/gluestudio/home?region={region}#/job/{jobName}/run/{jobRunId}"


def s3_to_snowflake_migrate(schema_name, table_name, job_run_id, file_name,
                            load_type, sink_link_service_id, job_id, data_migration_option, split,
                            split_id, user_id, socket_flag, pipeline_id, pipeline_run_id, s3_duration,source_link_service_type):
    """
    This api will migrate the data from s3 to snowflake
    by triggering copy command or glue shell job
    :param table_name
    :param job_run_id
    :param schema_name
    :param file_name
    :param load_type
    :param sink_link_service_id
    :param job_id
    :param data_migration_option
    :return: Boolean
    """
    try:
        # Fetching Link Service details
        result = db.link_service.find_one({"link_service_id": sink_link_service_id,
                                           "active": True})
        hostname = result["db_hostname"]
        username = get_secret(sink_link_service_id + "-username")
        password = get_secret(sink_link_service_id + "-password")

        # Establishing pyodbc Connection
        warehouse_name = config['snowflake']['warehouse']
        sf_conn_string = config["snowflake"]["conn"].format(hostname=hostname,
                                                            uid=username,
                                                            pwd=password,
                                                            warehouse=warehouse_name)
        conn = pyodbc.connect(sf_conn_string)
        cur = conn.cursor()

        # Deleting the existing values in target for ADHOC Load type
        if load_type.upper() == "ADHOC":
            del_range = db.job_run_detail.find_one(
                {"job_run_id": job_run_id, "object_name": table_name,
                 "object_parent": schema_name},
                {"_id": 0, "column_name": 1, "min_value": 1, "max_value": 1})
            del_cmd = snowflake.query["del_cmd"].format(schema_name=schema_name.upper(),
                                                        database_name=config['snowflake']['idea_database_snowflake'],
                                                        table_name=table_name.upper(),
                                                        column_name=del_range["column_name"],
                                                        min_value=del_range["min_value"],
                                                        max_value=del_range["max_value"])
            cur.execute(del_cmd)
            cur.commit()

        if source_link_service_type.upper() == "TERADATA DWH":
            # Fetching batch_id to get schema conversion details
            batch_id = list(db.idea_column_schema_conv_attr.find({"tgt_table_nm": table_name,
                                                                  "tgt_database_nm": schema_name},
                                                                 {'_id': 0, "tgt_batch_id": 1}).sort(
                [("insert_dttm", -1)]).limit(1))
            if len(batch_id) < 1:
                if socket_flag:
                    dashboard_data = {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":s3_duration,"sf_duration":0,"mode":load_type,"service":data_migration_option,"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
                    if split:
                        dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id,table_name,schema_name)
                        dashboard_data[table_name]['status'] = "InProgress"
                        dashboard_data[table_name]['rows'] += dashboard_rows
                        dashboard_data[table_name]['s3_duration'] = dashboard_s3
                        dashboard_data[table_name]['sf_duration'] = dashboard_sf
                        dashboard_data[table_name]['avg_duration'] = round((dashboard_s3 + dashboard_sf) / 2, 2)
                    send_message("sf_data_run_status", dashboard_data, user_id)
                if split:
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    array_filters = [{"stat.split_id": split_id}]
                    newvalues = {"$set": {"splits.$[stat].split_status_sf": "Fail",
                                          "splits.$[stat].end_time_sf": int(datetime.utcnow().timestamp()),
                                          "splits.$[stat].copy_sf": None,
                                          "splits.$[stat].aws_log_url_sf": "",
                                          "splits.$[stat].noofrows_read_sf": 0,
                                          "splits.$[stat].noofrows_written_sf": 0,
                                          "splits.$[stat].noofrows_skipped_sf": 0,
                                          "splits.$[stat].message": "Schema is not migrated using IDEA tool"}}
                    db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                                 array_filters)
                else:
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    newvalues = {"$set": {"split_status_sf": "Fail",
                                           " end_time_sf": int(datetime.utcnow().timestamp()),
                                           " copy_sf": None,
                                            "aws_log_url_sf": "",
                                            "noofrows_read_sf": 0,
                                            "noofrows_written_sf": 0,
                                            "noofrows_skipped_sf": 0,
                                            "message": "Schema is not migrated using IDEA tool"}}
                    db.job_run_detail.update_one(updatequery, newvalues)
                return False
            else:
                batch_id = batch_id[0]['tgt_batch_id']
            log.info(batch_id)
            schema_columns = pd.DataFrame(
                db.idea_column_schema_conv_attr.find({"tgt_table_nm": table_name,
                                                      "tgt_database_nm": schema_name,
                                                      "tgt_batch_id": batch_id},
                                                     {"_id": 0, "tgt_column_nm": 1, "tgt_data_type": 1,
                                                      "tgt_column_length": 1}).sort(
                    [("tgt_column_seq", 1)]))
            log.info("schema_columns = {}".format(schema_columns))
            cmd1 = "COPY INTO {database_name}.{schema}.{table} FROM (select ".format(
                schema=schema_name.upper(), table=table_name.upper(),database_name=config['snowflake']['idea_database_snowflake'].upper())
            for i in schema_columns.index:
                if schema_columns["tgt_column_length"][i] != "":
                    cmd1 = cmd1 + "$1:" + schema_columns['tgt_column_nm'][i] + "::" + \
                           schema_columns['tgt_data_type'][i]
                    cmd1 = cmd1 + " (" + schema_columns["tgt_column_length"][i] + "), "
                else:
                    cmd1 = cmd1 + "$1:" + schema_columns['tgt_column_nm'][i] + "::" + \
                           schema_columns['tgt_data_type'][i] + ", "
            cmd1 = cmd1[:-2]
            path = " from @{stage}/{schema_name}/{table_name}/load_date={file_date}/load_time=" \
                   "{base_timestamp}) FORCE = TRUE".format(
                stage=config["snowflake"]["stg_name"],
                schema_name=schema_name,
                table_name=table_name,
                file_date=file_name[:8],
                base_timestamp=file_name[8:])
            copy_cmd = cmd1 + path
            log.info(copy_cmd)
        else:
            s3_path = "s3://"+config['aws']['bucket_name']+"/"+config['aws']['base_folder']+\
                      f"/{schema_name}/{table_name}/load_date={file_name[:8]}/load_time={file_name[8:]}/{table_name}.csv"
            copy_cmd = snowflake.query["copy_cmd"].format(schema_name=schema_name.upper(),
                                                        database_name=config['snowflake']['idea_database_snowflake'],
                                                        table_name=table_name.upper(),
                                                        s3_path=s3_path,
                                                        snowflake_integration=config['snowflake']['integration'],
                                                        format_name=config['snowflake']['file_format'])
            log.info(copy_cmd)

        if data_migration_option.upper() == "GLUE":
            glue_job_name = config['aws']['glue_job_name']
            account = hostname.split(".snowflake")[0]

            # Starting the Glue Job
            resp = glue_client.start_job_run(JobName=glue_job_name, Arguments={
                '--warehouse': config['snowflake']['warehouse'],
                '--account': account,
                '--idea_db': config['snowflake']['idea_database_snowflake'],
                "--link_service_id": sink_link_service_id,
                "--region_name": config['aws']['region_name'],
                '--copy_cmd': copy_cmd,
                '--load_type': load_type,
                '--schema': config['snowflake']['schema'],
                '--table': table_name
            })
            log.info(resp['JobRunId'])
            glue_run_id = resp['JobRunId']

            # Monitoring the glue job and updating the status
            if split:
                updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                               "object_parent": schema_name}
                array_filters = [{"stat.split_id": split_id}]
                newvalues = {"$set": {"splits.$[stat].split_status_sf": "InProgress"}}
                db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                             array_filters)
            else:
                updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                               "object_parent": schema_name}
                newvalues = {"$set": {"status_sf": "InProgress"}}
                db.job_run_detail.update_one(updatequery, newvalues)
            flag = True
            while flag:
                # Checking after every 10 seconds
                time.sleep(10)
                resp = glue_client.get_job_run(JobName=glue_job_name,
                                               RunId=glue_run_id)
                job_status = resp['JobRun']['JobRunState']
                if job_status not in ('STARTING', 'RUNNING', 'STOPPING'):
                    flag = False

            # Making Glue job log URL
            log_region = config['aws']['region_name']
            aws_log_url = log_url_aws.format(jobRunId = glue_run_id,jobName = glue_job_name, region = log_region)

            # Updating job metrics in job_run_table
            if job_status == "SUCCEEDED":
                # for getting ROW_COUNT,ROW_PARSED
                get_copy_details_cmd_2 = snowflake.query["query_id_2"].format(
                    schema_name=config['snowflake']['idea_database_snowflake'],
                    table_name=table_name.upper(),
                    timestamp=str(file_name[8:]))
                df_get_copy_details_2 = pd.read_sql_query(get_copy_details_cmd_2, conn)
                if df_get_copy_details_2.empty:
                    rows_read = 0
                    rows_copied = 0
                else:
                    rows_read = df_get_copy_details_2.iloc[0]['ROW_COUNT']
                    rows_copied = df_get_copy_details_2.iloc[0]['ROW_PARSED']
                if socket_flag:
                    dashboard_data = {table_name:{"database":schema_name,"status": "Success","rows":rows_copied,"s3_duration":s3_duration,"sf_duration":resp['JobRun']['ExecutionTime'],"mode":load_type,"service":data_migration_option,"avg_duration":round((s3_duration+resp['JobRun']['ExecutionTime'])/2,2)}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
                    if split:
                        dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id, table_name, schema_name)
                        dashboard_data[table_name]['status'] = "InProgress"
                        dashboard_data[table_name]['rows'] += dashboard_rows
                        dashboard_data[table_name]['s3_duration'] = dashboard_s3
                        dashboard_data[table_name]['sf_duration'] = dashboard_sf
                        dashboard_data[table_name]['avg_duration'] = round((dashboard_s3+dashboard_sf)/2,2)
                    send_message("sf_data_run_status", dashboard_data, user_id)
                rows_skipped = rows_read - rows_copied
                
                if split:
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    array_filters = [{"stat.split_id": split_id}]
                    newvalues = {"$set": {"splits.$[stat].glue_job_run_id_sf": glue_run_id,
                                          "splits.$[stat].split_status_sf": "Success",
                                          "splits.$[stat].end_time_sf": str(resp['JobRun'][
                                              'CompletedOn']),
                                          "splits.$[stat].copy_sf": resp['JobRun']['ExecutionTime'],
                                          "splits.$[stat].noofrows_read_sf": rows_read,
                                          "splits.$[stat].noofrows_written_sf": rows_copied,
                                          "splits.$[stat].noofrows_skipped_sf": rows_skipped,
                                          "splits.$[stat].aws_log_url_sf": aws_log_url,
                                          "splits.$[stat].message": "S3 to Snowflake Migration is Successfull"}}
                    db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                                 array_filters)
                else:
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    newvalues = {"$set": {"glue_job_run_id_sf": glue_run_id,
                                          "status_sf": "Success",
                                          "end_time_sf": str(resp['JobRun']['CompletedOn']),
                                          "end_time": int(datetime.utcnow().timestamp()),
                                          "copy_sf": resp['JobRun']['ExecutionTime'],
                                          "noofrows_read_sf": rows_read,
                                          "noofrows_written_sf": rows_copied,
                                          "noofrows_skipped_sf": rows_skipped,
                                          "aws_log_url_sf": aws_log_url,
                                          "message": "S3 to Snowflake Migration is Successfull"}}
                    db.job_run_detail.update_one(updatequery, newvalues)
                    if load_type.upper() == "INCREMENTAL LOAD" and source_link_service_type.upper()=="TERADATA DWH":
                        max_value = db.job_run_detail.find({"job_run_id": job_run_id,
                                                            "object_parent": schema_name,
                                                            "object_name": table_name})
                        max_value = max_value.next()["max_value"]
                        db.table_migration_dashboard.update_one({"table_nm": table_name,
                                                                      "database_nm": schema_name,
                                                                      "active": True},
                                                                     {"$set": {
                                                                         "bookmark": max_value}})


            elif job_status == "FAILED" or job_status == 'STOPPED':

                if socket_flag:
                    dashboard_data = {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":s3_duration,"sf_duration":0,"mode":load_type,"service":data_migration_option,"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
                    if split:
                        dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id, table_name, schema_name)
                        dashboard_data[table_name]['status'] = "InProgress"
                        dashboard_data[table_name]['rows'] += dashboard_rows
                        dashboard_data[table_name]['s3_duration'] = dashboard_s3
                        dashboard_data[table_name]['sf_duration'] = dashboard_sf
                        dashboard_data[table_name]['avg_duration'] = round((dashboard_s3+dashboard_sf)/2,2)
                    send_message("sf_data_run_status", dashboard_data, user_id)
                if job_status == 'STOPPED':
                    message = "S3 to SF glue job has been stopped"
                else:
                    message = resp['JobRun']['ErrorMessage']
                if split:
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    array_filters = [{"stat.split_id": split_id}]
                    newvalues = {"$set": {"splits.$[stat].glue_job_run_id_sf": glue_run_id,
                                          "splits.$[stat].split_status_sf": "Fail",
                                          "splits.$[stat].end_time_sf": str(resp['JobRun'][
                                              'CompletedOn']),
                                          "splits.$[stat].copy_sf": resp['JobRun']['ExecutionTime'],
                                          "splits.$[stat].aws_log_url_sf": aws_log_url,
                                          "splits.$[stat].noofrows_read_sf": 0,
                                          "splits.$[stat].noofrows_written_sf": 0,
                                          "splits.$[stat].noofrows_skipped_sf": 0,
                                          "splits.$[stat].message": message}}
                    db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                                 array_filters)
                else:
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    newvalues = {"$set": {"glue_job_run_id_sf": glue_run_id,
                                          "status_sf": "Fail",
                                          "end_time_sf": str(resp['JobRun']['CompletedOn']),
                                          "end_time": int(datetime.utcnow().timestamp()),
                                          "copy_sf": resp['JobRun']['ExecutionTime'],
                                          "aws_log_url_sf": aws_log_url,
                                          "noofrows_read_sf": 0,
                                          "noofrows_skipped_sf": 0,
                                          "noofrows_written_sf": 0,
                                          "message": message}}
                    db.job_run_detail.update_one(updatequery, newvalues)
        else:
            # updating the status for copy job
            if split:
                updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                               "object_parent": schema_name}
                array_filters = [{"stat.split_id": split_id}]
                newvalues = {"$set": {"splits.$[stat].split_status_sf": "InProgress"}}
                db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                             array_filters)
            else:
                updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                               "object_parent": schema_name}
                newvalues = {"$set": {"status_sf": "InProgress"}}
                db.job_run_detail.update_one(updatequery, newvalues)

            # use IDEA_SNOWFLAKE Database
            idea_db_name = config['snowflake']['idea_database_snowflake']
            use_cmd = snowflake.query["use_schema"].format(database_name=idea_db_name.upper(),schema_name= config['snowflake']['schema'])
            log.info(use_cmd)
            cur.execute(use_cmd)

            # Execute copy command
            log.info(copy_cmd)
            cur.execute(copy_cmd)
            cur.commit()

            # for Getting QUERY_ID , EXECUTION_STATUS
            use_schema = snowflake.query["use_schema_1"].format(schema_name=schema_name.upper(),database_name =config['snowflake']['idea_database_snowflake'])
            log.info(use_schema)
            cur.execute(use_schema)
            if source_link_service_type.upper() == "TERADATA DWH":
                get_copy_details_cmd_1 = snowflake.query["query_id_1"].format(
                
                    schema_name=config['snowflake']['idea_database_snowflake'],
                    table_name=table_name.upper(),
                    timestamp=str(file_name[8:]))
            else:
                get_copy_details_cmd_1 = snowflake.query["query_id_1_ftp"].format(
                    schema_name=config['snowflake']['idea_database_snowflake'],
                    table_name=table_name.upper())

            # for getting ROW_COUNT,ROW_PARSED
            get_copy_details_cmd_2 = snowflake.query["query_id_2"].format(
                schema_name=config['snowflake']['idea_database_snowflake'],
                table_name=table_name.upper(),
                timestamp=str(file_name[8:]))
            df_get_copy_details_1 = pd.read_sql_query(get_copy_details_cmd_1, conn)
            df_get_copy_details_2 = pd.read_sql_query(get_copy_details_cmd_2, conn)
            job_status = df_get_copy_details_1.iloc[0]['EXECUTION_STATUS']
            conn.close()
            if job_status == "SUCCESS":
                query_id = df_get_copy_details_1.iloc[0]['QUERY_ID']
                copy_duration = df_get_copy_details_1.iloc[0]['TOTAL_ELAPSED_TIME']
                if df_get_copy_details_2.empty:
                    rows_read = 0
                    rows_copied = 0
                else:
                    rows_read = df_get_copy_details_2.iloc[0]['ROW_COUNT']
                    rows_copied = df_get_copy_details_2.iloc[0]['ROW_PARSED']
                if socket_flag:
                    dashboard_data = {table_name:{"database":schema_name,"status": "Success","rows":rows_copied,"s3_duration":s3_duration,"sf_duration":copy_duration,"mode":load_type,"service":data_migration_option,"avg_duration":round((s3_duration+copy_duration)/2,2)}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
                    if split:
                        dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id, table_name, schema_name)
                        dashboard_data[table_name]['status'] = "InProgress"
                        dashboard_data[table_name]['rows'] += dashboard_rows
                        dashboard_data[table_name]['s3_duration'] = dashboard_s3
                        dashboard_data[table_name]['sf_duration'] = dashboard_sf
                        dashboard_data[table_name]['avg_duration'] = round((dashboard_s3+dashboard_sf)/2,2)
                    send_message("sf_data_run_status", dashboard_data, user_id)
                rows_skipped = rows_read - rows_copied
                if split:
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    array_filters = [{"stat.split_id": split_id}]
                    newvalues = {"$set": {"splits.$[stat].query_id_sf": query_id,
                                          "splits.$[stat].split_status_sf": "Success",
                                          "splits.$[stat].end_time_sf": str(
                                              datetime.now().strftime(idea_date_format)),
                                          "splits.$[stat].copy_sf": copy_duration,
                                          "splits.$[stat].noofrows_read_sf": rows_read,
                                          "splits.$[stat].noofrows_written_sf": rows_copied,
                                          "splits.$[stat].noofrows_skipped_sf": rows_skipped,
                                          "splits.$[stat].message": "S3 to Snowflake Migration is Successfull"}}
                    db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                                 array_filters)
                else:
                    newvalues = {"$set": {
                        "query_id_sf": query_id,
                        "copy_sf": copy_duration,
                        "end_time_sf": str(datetime.now().strftime(idea_date_format)),
                        "end_time": int(datetime.utcnow().timestamp()),
                        "status_sf": "Success",
                        "noofrows_read_sf": rows_read,
                        "noofrows_written_sf": rows_copied,
                        "noofrows_skipped_sf": rows_skipped,
                        "message": "S3 to Snowflake Migration is Successful"
                    }}
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    db.job_run_detail.update_one(updatequery, newvalues, upsert=True)
                    if load_type.upper() == "INCREMENTAL LOAD" and source_link_service_type.upper() == "TERADATA DWH":
                        max_value = db.job_run_detail.find({"job_run_id": job_run_id,
                                                            "object_parent": schema_name,
                                                            "object_name": table_name})
                        max_value = max_value.next()["max_value"]
                        db.table_migration_dashboard.update_one({"table_nm": table_name,
                                                                 "database_nm": schema_name,
                                                                 "active": True},
                                                                {"$set": {"bookmark": max_value}})
            else:
                if socket_flag:
                    dashboard_data = {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":s3_duration,"sf_duration":0,"mode":load_type,"service":data_migration_option,"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
                    if split:
                        dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id, table_name, schema_name)
                        dashboard_data[table_name]['status'] = "InProgress"
                        dashboard_data[table_name]['rows'] += dashboard_rows
                        dashboard_data[table_name]['s3_duration'] = dashboard_s3
                        dashboard_data[table_name]['sf_duration'] = dashboard_sf
                        dashboard_data[table_name]['avg_duration'] = round((dashboard_s3+dashboard_sf)/2,2)
                    send_message("sf_data_run_status", dashboard_data, user_id)
                query_id = df_get_copy_details_1.iloc[0]['QUERY_ID']
                if split:
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    array_filters = [{"stat.split_id": split_id}]
                    newvalues = {"$set": {"splits.$[stat].query_id": query_id,
                                          "splits.$[stat].split_status_sf": "Fail",
                                          "splits.$[stat].end_time_sf": str(
                                              datetime.now().strftime(idea_date_format)),
                                          "splits.$[stat].copy_sf": None,
                                          "splits.$[stat].message": "S3 to snowflake migration failed",
                                          "splits.$[stat].noofrows_read_sf": 0,
                                          "splits.$[stat].noofrows_written_sf": 0,
                                          "splits.$[stat].noofrows_skipped_sf": 0 }}
                    db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                                 array_filters)
                else:
                    updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                                   "object_parent": schema_name}
                    new_values = {"status_sf": "Fail", "query_id": query_id,
                                  "end_time_sf": int(datetime.utcnow().timestamp()),
                                  "end_time": int(datetime.utcnow().timestamp()),
                                  "copy_sf": None,
                                  "noofrows_read_sf": 0,
                                  "noofrows_skipped_sf": 0,
                                  "noofrows_written_sf": 0,
                                  "message": "S3 to snowflake migration failed"
                                  }
                    db.job_run_detail.update_one(updatequery, {"$set": new_values})
                return False

    except Exception:
        log.error(traceback.format_exc())
        if socket_flag:
            dashboard_data = {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":s3_duration,"sf_duration":0,"mode":load_type,"service":data_migration_option,"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
            if split:
                dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id, table_name, schema_name)
                dashboard_data[table_name]['status'] = "InProgress"
                dashboard_data[table_name]['rows'] += dashboard_rows
                dashboard_data[table_name]['s3_duration'] = dashboard_s3
                dashboard_data[table_name]['sf_duration'] = dashboard_sf
                dashboard_data[table_name]['avg_duration'] = round((dashboard_s3+dashboard_sf)/2,2)
            send_message("sf_data_run_status", dashboard_data, user_id)
        if split:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            array_filters = [{"stat.split_id": split_id}]
            newvalues = {"$set": {"splits.$[stat].split_status_sf": "Fail",
                                  "splits.$[stat].end_time_sf": int(datetime.utcnow().timestamp()),
                                  "splits.$[stat].copy_sf": None,
                                  "splits.$[stat].noofrows_read_sf": 0,
                                  "splits.$[stat].noofrows_written_sf": 0,
                                  "splits.$[stat].noofrows_skipped_sf": 0,
                                  "splits.$[stat].message": "S3 to snowflake migration failed"}}
            db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                         array_filters)
        else:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            newvalues = {
                "$set": {"status_sf": "Fail",
                         "message": "S3 to snowflake migration failed",
                         "noofrows_read_sf": 0,
                         "noofrows_skipped_sf": 0,
                         "noofrows_written_sf": 0,
                         "end_time_sf": int(datetime.utcnow().timestamp()),
                         "end_time": int(datetime.utcnow().timestamp()),
                         "copy_sf": None
                         }}
        db.job_run_detail.update_one(updatequery, newvalues)
        log.error(traceback.format_exc())
        return False

    log.info("END")
    return True



def s3_to_snowflake(data):
    # Consumer Run s3_to_snowflake
    try:
        table_name = data['table_name']
        job_run_id = data['job_run_id']
        run_by = data['run_by']
        start_time = str(data['start'])
        job_id = data['job_id']
        load_type = data['load_type']
        schema_name = data['schema_name']
        user_id = data['user_id']
        socket_flag = data['socket_flag']
        pipeline_id = data['pipeline_id']
        pipeline_run_id = data['pipeline_run_id']
        if "s3_duration" in data:
            s3_duration = data['s3_duration']
        if data["index"] == "job_end" or data["index"] == "split_end":
            job_run_end(job_run_id, job_id, start_time, run_by, data["index"], load_type,
                        schema_name, table_name, user_id, socket_flag, pipeline_id, pipeline_run_id)
        else:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent" : schema_name}
            newvalues = {"$set": {"status_sf": "InProgress"}}
            db.job_run_detail.update_one(updatequery, newvalues)
            source_link_service_id = data["source_link_service_id"]
            source_link_service_type=db.link_service.find_one({"link_service_id":source_link_service_id})["link_service_type"]
            sink_link_service_id = data['sink_link_service_id']
            query_for_option = {"job_id": job_id, "active": True}
            migration_opt_result = db.job_registry.find(query_for_option,
                                                        {"data_migration_option": 1, "_id": 0})
            migration_opt_result = list(migration_opt_result)
            data_migration_option = migration_opt_result[0]['data_migration_option']
            file_name = data['file_name']
            split = data['split']
            split_id = data['split_id']
            s3_to_snowflake_migrate(schema_name, table_name, job_run_id, file_name,
                                    load_type, sink_link_service_id, job_id, data_migration_option,
                                    split, split_id, user_id, socket_flag, pipeline_id, pipeline_run_id, s3_duration,source_link_service_type)

    except Exception:
        log.error(traceback.format_exc())
        if split:
            updatequery = {"job_run_id": job_run_id, "object_name": table_name,
                           "object_parent": schema_name}
            array_filters = [{"stat.split_id": split_id}]
            newvalues = {"$set": {"splits.$[stat].split_status_sf": "Fail",
                                  "splits.$[stat].end_time_sf": int(datetime.utcnow().timestamp()),
                                  "splits.$[stat].copy_sf": None,
                                  "splits.$[stat].noofrows_read_sf": 0,
                                  "splits.$[stat].noofrows_written_sf": 0,
                                  "splits.$[stat].noofrows_skipped_sf": 0,
                                  "splits.$[stat].message": "S3 to snowflake migration failed",}}
            db.job_run_detail.update_one(updatequery, newvalues, False, False, None,
                                         array_filters)
        else:
            myquery = {"job_run_id": job_run_id, "object_name": table_name,
                       "object_parent": schema_name}
            newvalues = {"$set": {"status_sf": "Fail",
                                  "message": "S3 to snowflake migration failed",
                                  "noofrows_read_sf": 0,
                                  "noofrows_skipped_sf": 0,
                                  "noofrows_written_sf": 0,
                                  "end_time_sf": int(datetime.utcnow().timestamp()),
                                  "end_time": int(datetime.utcnow().timestamp()),
                                  "copy_duration_sf": None}
                         }
            db.job_run_detail.update_one(myquery, newvalues)
        return False

    log.info("END")
    return True


def job_run_end(job_run_id, job_id, start_time, run_by, index, load_type, schema_name, table_name, user_id, socket_flag, pipeline_id, pipeline_run_id):
    """
    This Function updates the job run table after the completion of job
    :param job_run_id
    :param job_id
    :param start_time
    :param run_by
    :return Boolean
    """
    try:
        query = {"job_run_id": job_run_id}
        job_name = db.job_registry.find_one({"job_id": job_id}, {"job_name": 1, "_id": 0})
        flag = True

        # Monitoring the job end
        if index == "job_end":
            while flag:
                run_status = db.job_run_detail.find(query,
                                                    {"status_s3": 1, "status_sf": 1, "_id": 0})
                run_status = list(run_status)
                if any(item['status_s3'] in ['InProgress', 'Not Started'] or item['status_sf'] in [
                    'InProgress', 'Not Started'] for item in run_status):
                    log.info(":: Wait for Success or Fail status in table ... ::")
                    time.sleep(5)
                    flag = True
                else:
                    flag = False
            if any(item['status_s3'] == 'Fail' or item['status_sf'] == 'Fail' for item in
                   run_status):
                if socket_flag:
                    send_message("sf_data_run_job_status", {"job_id": job_id, "status": "Fail", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                newvalues = {"$set": {"status": "Fail", "re_run_flag": True, "end_time": int(datetime.utcnow().timestamp()),
                                      "end_time_str": str(datetime.now().strftime(idea_date_format))}}
                db.job_run.update_one(query, newvalues)
                log.info("db.job_run.update_one({query}, {newvalues})".format(query=query,
                                                                              newvalues=newvalues))
                if config["ABCR"]["flag"] == "Y":
                    abcr_job_run("", int(datetime.utcnow().timestamp()),
                                 "Data migration failed",
                                 job_id, job_run_id, job_name['job_name'],
                                 "migrating data from teradata to snowflake", " ",
                                 run_by, start_time, "Fail", config['ABCR']['data'], "")

            else:
                if socket_flag:
                    send_message("sf_data_run_job_status", {"job_id": job_id, "status": "Success", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
                newvalues = {
                    "$set": {"status": "Success", "re_run_flag": False, "end_time": int(datetime.utcnow().timestamp()),
                             "end_time_str": str(datetime.now().strftime(idea_date_format))}}
                db.job_run.update_one(query, newvalues)
                if config["ABCR"]["flag"] == "Y":
                    log.info("db.job_run_detail.find(): query: {},{}".format(query,newvalues))
                    output = list(db.job_run_detail.find(query, {"_id": 0, "active": 0}))
                    abcr_job_run("", int(datetime.utcnow().timestamp()),
                                 "",
                                 job_id, job_run_id, job_name['job_name'],
                                 "migrating data from teradata to snowflake", output,
                                 run_by, start_time, "Success", config['ABCR']['data'], "")


        # Monitoring the split end
        elif index == "split_end":
            query = {"job_run_id": job_run_id,"object_name":table_name,"object_parent":schema_name}
            while flag:
                run_status = db.job_run_detail.find(query, {"splits.split_status_s3": 1,
                                                            "splits.split_status_sf": 1, "_id": 0})
                run_status = list(run_status)
                if any(item['split_status_s3'] in ['InProgress', 'Not Started'] or item[
                    'split_status_sf'] in ['InProgress', 'Not Started'] for item in
                       run_status[0]['splits']):
                    log.info(":: Wait for Success or Fail status in split ... ::")
                    time.sleep(5)
                    flag = True
                else:
                    flag = False
            log.info(":: all splits have ended ... ::")
            aggregate_rows = list(db.job_run_detail.aggregate([
                {
                    '$match': {
                        'job_run_id': job_run_id,
                        'object_parent': schema_name,
                        'object_name': table_name
                    }
                }, {
                    '$unwind': {
                        'path': '$splits'
                    }
                }, {
                    '$group': {
                        '_id': {
                            'object_parent': '$object_parent',
                            'object_name': '$object_name'
                        },
                        'noofrows_read_sf': {
                            '$sum': '$splits.noofrows_read_sf'
                        },
                        'noofrows_written_sf': {
                            '$sum': '$splits.noofrows_written_sf'
                        },
                        'noofrows_skipped_sf': {
                            '$sum': '$splits.noofrows_skipped_sf'
                        }
                    }
                }, {
                    '$project': {
                        'object_parent': '$_id.object_parent',
                        'object_name': '$_id.object_name',
                        'noofrows_read_sf': 1,
                        'noofrows_written_sf': 1,
                        'noofrows_skipped_sf': 1,
                        '_id': 0
                    }
                }
            ]))
            newvalues = {
                "$set": {"status_sf": "Success", "end_time": int(datetime.utcnow().timestamp()),
                         "noofrows_read_sf": aggregate_rows[0]['noofrows_read_sf'],
                         "noofrows_written_sf": aggregate_rows[0]["noofrows_written_sf"],
                         "noofrows_skipped_sf": aggregate_rows[0]["noofrows_skipped_sf"]}}
            db.job_run_detail.update_one(query, newvalues)
            if any(item['split_status_s3'] == 'Fail' for item in run_status[0]['splits']):
                newvalues = {
                    "$set": {"status_s3": "Fail", "end_time": int(datetime.utcnow().timestamp())}}
                db.job_run_detail.update_one(query, newvalues)
            else:
                newvalues = {
                    "$set": {"status_s3": "Success", "end_time": int(datetime.utcnow().timestamp())}}
                db.job_run_detail.update_one(query, newvalues)
            if any(item['split_status_sf'] == 'Fail' for item in run_status[0]['splits']):
                if socket_flag:
                    data_migration_option = db.job_registry.find_one({"job_id": job_id}, {"data_migration_option": 1, "_id": 0})
                    if bool(data_migration_option):
                        data_migration_option = data_migration_option['data_migration_option']
                    dashboard_data = {table_name:{"database":schema_name,"status": "Fail","rows":0,"s3_duration":0,"sf_duration":0,"mode":load_type,"service":data_migration_option,"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
                    dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id, table_name, schema_name)
                    dashboard_data[table_name]['rows'] += dashboard_rows
                    dashboard_data[table_name]['s3_duration'] = dashboard_s3
                    dashboard_data[table_name]['sf_duration'] = dashboard_sf
                    dashboard_data[table_name]['avg_duration'] = round((dashboard_s3+dashboard_sf)/2,2)
                    send_message("sf_data_run_status", dashboard_data, user_id)
                newvalues = {
                    "$set": {"status_sf": "Fail", "end_time": int(datetime.utcnow().timestamp())}}
                db.job_run_detail.update_one(query, newvalues)
            else:
                if socket_flag:
                    data_migration_option = db.job_registry.find_one({"job_id": job_id}, {"data_migration_option": 1, "_id": 0})
                    if bool(data_migration_option):
                        data_migration_option = data_migration_option['data_migration_option']
                    dashboard_data = {table_name:{"database":schema_name,"status": "Success","rows":0,"s3_duration":0,"sf_duration":0,"mode":load_type,"service":data_migration_option,"avg_duration":0}, "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}
                    dashboard_rows, dashboard_s3, dashboard_sf = update_dashboard(job_run_id, table_name, schema_name)
                    dashboard_data[table_name]['rows'] = dashboard_rows
                    dashboard_data[table_name]['s3_duration'] = dashboard_s3
                    dashboard_data[table_name]['sf_duration'] = dashboard_sf
                    dashboard_data[table_name]['avg_duration'] = round((dashboard_s3+dashboard_sf)/2,2)
                    send_message("sf_data_run_status", dashboard_data, user_id)
                newvalues = {
                    "$set": {"status_sf": "Success", "end_time": int(datetime.utcnow().timestamp())
                             }}
                db.job_run_detail.update_one(query, newvalues)
                if load_type.upper() == "INCREMENTAL LOAD":
                    max_value = db.job_run_detail.find({"job_run_id": job_run_id,
                                                        "object_parent": schema_name,
                                                        "object_name": table_name})
                    max_value = max_value.next()["max_value"]
                    db.table_migration_dashboard.update_one({"table_nm": table_name,
                                                                  "database_nm": schema_name,
                                                                  "active": True},
                                                                 {"$set": {"bookmark": max_value}})



    except Exception:
        log.error(traceback.format_exc())
        if socket_flag:
            send_message("sf_data_run_job_status", {"job_id": job_id, "status": "Fail", "pipeline_id": pipeline_id, "pipeline_run_id": pipeline_run_id}, user_id)
        newvalues = {"$set": {"status": "Fail", "re_run_flag": True, "end_time": int(datetime.utcnow().timestamp()),
                              "end_time_str": str(datetime.now().strftime(idea_date_format))}}
        db.job_run.update_one(query, newvalues)
        log.error(traceback.format_exc())
        return False
    return True
