"""
This service  run consumer for BLOB to SNOWFLAKE
"""
import logging
import logging.handlers
import json
import _thread
from kafka import KafkaConsumer
from config import config
from libs.data_util import s3_to_snowflake

# Log
log = logging.getLogger(config["logging"]["name"])
log.setLevel(int(config["logging"]["logging_level"]))
handler = logging.handlers.RotatingFileHandler(
            config["logging"]["filename"],
            maxBytes = int(config["logging"]["logging_maxBytes"]),
            backupCount = int(config["logging"]["logging_backup_count"]))

# Set the log format
handler.setFormatter(
        logging.Formatter("%(asctime)s|%(levelname)-5.5s|[%(filename)s:%(lineno)s-%(funcName)20s()]|%(message)s"))
log.addHandler(handler)
# set consumer for S3 to SNOWFLAKE
topic = config["kafka"]["topic_s3_sf"]
server = config["kafka"]["host"]
consumer_blob_sf = KafkaConsumer(topic,bootstrap_servers=[server])

log.info("Snowflake Data Migration to Snowflake Service initialized Successfully")

for message in consumer_blob_sf:
    message = message.value.decode("utf-8")
    data = json.loads(message)
    _thread.start_new_thread(s3_to_snowflake, (data,))



