"""
This module consists methods to perform CRUD operation on AWS Secret Manager
"""
import base64
import boto3
from botocore.exceptions import ClientError
from config import client as sm_client


def create_secret(secret_name: str, secret_string: str) -> bool:
    """
    Creates a secret in aws secret manager with supplied 'secret_name' and 'secret_string'
    :param secret_name:
    :param secret_string:
    :return:
    """

    try:
        sm_client.create_secret(Name=secret_name, SecretString=secret_string)
    except ClientError as e:
        # logging
        return False
    return True


def get_secret(secret_name: str) -> str:
    """
    Fetches the secret with the supplied name from aws secret manger.
    :param secret_name:
    :return:
    """

    try:
        get_secret_value_response = sm_client.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        # logging
        return False

        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be
        # populated.
    if 'SecretString' in get_secret_value_response:
        secret = get_secret_value_response['SecretString']
        return secret
    else:
        decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
        return decoded_binary_secret


def del_secret(secret_name: str, without_recovery: bool = True) \
        -> bool:
    """
    Deletes a secret in aws secret manager, with the supplied secret_name
    :param secret_name:
    :param without_recovery:
    :return:
    """

    try:
        sm_client.delete_secret(SecretId=secret_name, ForceDeleteWithoutRecovery=without_recovery)
    except ClientError as e:
        # logging
        return False

    return True


def put_secret(secret_name: str, secret_string: str) -> bool:
    """
    Updates an already existing secret in aws secret manager
    :param secret_name:
    :param secret_string:
    :return:
    """

    try:
        sm_client.put_secret_value(SecretId=secret_name, SecretString=secret_string)
    except ClientError as e:
        # logging
        return False
    return True
