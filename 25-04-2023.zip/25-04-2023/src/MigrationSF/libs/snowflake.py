sf_link_all = {
      "discovery_wh_query" : "CREATE OR REPLACE WAREHOUSE {discovery_warehouse_name} WITH WAREHOUSE_SIZE = {discovery_warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD';",
      "schema_migration_wh_query" : "CREATE OR REPLACE WAREHOUSE {schema_warehouse_name} WITH WAREHOUSE_SIZE = {schema_migration_Warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD';",
      "data_migration_wh_query" : "CREATE OR REPLACE WAREHOUSE {data_warehouse_name} WITH WAREHOUSE_SIZE = {data_migration_warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD';",
      "create_db_query" : "CREATE OR REPLACE DATABASE {database_snowflake};",
      "integration_query" : "CREATE OR REPLACE STORAGE INTEGRATION {integration_name} TYPE = {stage_type} STORAGE_PROVIDER = {storage_provider} ENABLED = {enabled} STORAGE_AWS_ROLE_ARN = '{storage_aws_role_arn}' STORAGE_ALLOWED_LOCATIONS = ('{storage_allowed_locations}')",
      "file_formate_query": "CREATE OR REPLACE FILE FORMAT {file_format_name} TYPE = 'PARQUET' COMPRESSION = 'SNAPPY' BINARY_AS_TEXT = TRUE;",
      "file_formate_query_ftp": "CREATE OR REPLACE FILE FORMAT {file_format_name_ftp} TYPE = 'CSV' COMPRESSION = 'AUTO' FIELD_DELIMITER = '\302\254' RECORD_DELIMITER = '\\n' SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '\\042' TRIM_SPACE = TRUE ERROR_ON_COLUMN_COUNT_MISMATCH = TRUE ESCAPE = NONE ESCAPE_UNENCLOSED_FIELD = '\\134' DATE_FORMAT = 'AUTO' TIMESTAMP_FORMAT = 'AUTO' NULL_IF = ('\\\\N');",
      "stage_query" : "create or replace stage {stage_name} storage_integration = {integration_name} url= '{storage_allowed_locations}' file_format = {file_format};",
      "drop_data_wh_query" :  "DROP WAREHOUSE IF EXISTS {data_warehouse_name};",
      "drop_schema_wh_query" : "DROP WAREHOUSE IF EXISTS {schema_warehouse_name};",
      "drop_discovery_wh_query" : "DROP WAREHOUSE IF EXISTS {discovery_warehouse_name};",
      "drop_database_query" : "DROP DATABASE IF EXISTS {database_snowflake}",
      "drop_sf_integration_query" : "DROP STORAGE INTEGRATION IF EXISTS {integration_name}",
      "alt_discovery_wh_query" : " ALTER WAREHOUSE {discovery_warehouse_name} SET WAREHOUSE_SIZE = {discovery_warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD' COMMENT = 'updated at {update_time}';",
      "alt_schema_migration_wh_query" : " ALTER WAREHOUSE {schema_warehouse_name} SET WAREHOUSE_SIZE = {schema_migration_warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD' COMMENT = 'updated at {update_time}';",
      "alt_data_migration_wh_query" : " ALTER WAREHOUSE {data_warehouse_name} SET WAREHOUSE_SIZE = {data_migration_warehouse_type} WAREHOUSE_TYPE = 'STANDARD' AUTO_SUSPEND = 300 AUTO_RESUME = TRUE MIN_CLUSTER_COUNT = 1 MAX_CLUSTER_COUNT = 2 SCALING_POLICY = 'STANDARD' COMMENT = 'updated at {update_time}';",
      "create_schema_query":"CREATE OR REPLACE SCHEMA {schema_snowflake};"
}


link_service = {
    "check_permission": "SELECT $1 as cm FROM @{} limit 1;",
    "use_database": "USE DATABASE {db_name};",
    "select_query": "select '1';"
}

data_sharing = {
    "share_discover_1": "SHOW SHARES;",
    "share_discover_2": "DESCRIBE SHARE {share};",
    "reader_discover": "SHOW MANAGED ACCOUNTS;",
    "create_share": "CREATE SHARE {share} COMMENT='';",
    "database_grant": "GRANT USAGE ON DATABASE {database} TO SHARE {share};",
    "schema_grant": "GRANT USAGE ON SCHEMA {database}.{schema} TO SHARE {share};",
    "table_grant": "GRANT SELECT ON TABLE {database}.{schema}.{table} TO SHARE {share};",
    "secure_view_grant": "GRANT SELECT ON VIEW {database}.{schema}.{secure_view} TO SHARE {share};",
    "database_revoke": "REVOKE USAGE ON DATABASE {database} FROM SHARE {share};",
    "schema_revoke": "REVOKE USAGE ON SCHEMA {database}.{schema} FROM SHARE {share};",
    "table_revoke": "REVOKE SELECT ON TABLE {database}.{schema}.{table} FROM SHARE {share};",
    "secure_view_revoke": "REVOKE SELECT ON VIEW {database}.{schema}.{secure_view} FROM SHARE {share};",
    "create_reader": "CREATE MANAGED ACCOUNT {reader} admin_name='{user}', admin_password='{password}', type=reader, COMMENT='';",
    "assign_share": "ALTER SHARE {share} ADD ACCOUNTS = {consumer};",
    "revoke_share": "ALTER SHARE {share} REMOVE ACCOUNT = {consumer};",
    "drop_share": "DROP SHARE {share};",
    "drop_reader": "DROP MANAGED ACCOUNT {reader};"
}
