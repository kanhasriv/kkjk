key = '$schema'
url = 'http://json-schema.org/schema#'
pattern = "^(\\s*\\w\\s*){1,}$"
data_sharing_pattern = '^[A-Z0-9_]+$'
schema = {
    'discover': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'socket': {
                'type': 'string'
            }
        }
    },
    'overview': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'macro_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'db_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'db_name': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'macro_definition': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'db_name', 'macro_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'db_name': {
                'type': 'string'
            },
            'macro_name': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'users_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'users_access_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'roles_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'snowflake_warehouse_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'schema_migration': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'socket': {
                'type': 'string'
            }
        }
    },
    'schema_migration_status': {
        key: url,
        'type': 'object',
        'required': ['job_run_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'get_schema_migration_job': {
        key: url,
        'type': 'object',
        'required': ['project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'filter': {
                'type': 'string'
            }
        }
    },
    'get_data_migration_job': {
        key: url,
        'type': 'object',
        'required': ['project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'filter': {
                'type': 'string'
            }
        }
    },
    'data_migration': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'socket': {
                'type': 'string'
            }
        }
    },
    'data_migration_rerun': {
        key: url,
        'type': 'object',
        'required': ['job_run_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_run_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
        }
    },
    'data_migration_status': {
        key: url,
        'type': 'object',
        'required': ['job_run_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_run_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 200
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
        }
    },
    'create_schema_migration_job': {
        key: url,
        'type': 'object',
        'required': ['job_name', 'source_link_service_id', 'sink_link_service_id',
                     'data', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_name': {
                'type': 'string',
                "pattern": pattern,
                'minLength': 1,
                'maxLength': 100
            },
            'source_link_service_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'sink_link_service_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'data': {
                'type': 'object',
                'required': ['force_create'],
                'additionalProperties': False,
                'minProperties': 2,
                'properties': {
                    'force_create': {
                        'type': 'boolean'
                    },
                    'database_table': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'required': ['database', 'tables'],
                            'additionalProperties': False,
                            'properties': {
                                'database': {
                                    'type': 'string',
                                    "pattern": pattern,
                                    'minLength': 1,
                                    'maxLength': 100

                                },
                                'tables': {
                                    'type': 'array',
                                    'items': {
                                        'type': 'string',
                                        "pattern": pattern,
                                        'minLength': 1,
                                        'maxLength': 100
                                    },
                                    "minItems": 1
                                }
                            }
                        },
                        "minItems": 1
                    },
                    'database_view': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'required': ['database', 'views'],
                            'additionalProperties': False,
                            'properties': {
                                'database': {
                                    'type': 'string',
                                    "pattern": pattern,
                                    'minLength': 1,
                                    'maxLength': 100
                                },
                                'views': {
                                    'type': 'array',
                                    'items': {
                                        'type': 'string',
                                        "pattern": pattern,
                                        'minLength': 1,
                                        'maxLength': 100
                                    },
                                    "minItems": 1
                                }
                            }
                        },
                        "minItems": 1
                    },
                    'roles': {
                        'type': 'array',
                        'items': {
                            'type': 'string',
                            "pattern": pattern,
                            'minLength': 1,
                            'maxLength': 100
                        },
                        "minItems": 1
                    },
                    'users': {
                        'type': 'array',
                        'items': {
                            'type': 'string',
                            "pattern": pattern,
                            'minLength': 1,
                            'maxLength': 100
                        },
                        "minItems": 1
                    }
                }
            }
        }
    },
    'create_data_migration_job': {
        key: url,
        'type': 'object',
        'required': ['job_name',
                     'load_type', 'source_link_service_id',
                     'sink_link_service_id', 'data_migration_option', 'data','project_id'],
        'additionalProperties': False,
        'properties': {
            'job_name': {
                'type': 'string',
                "pattern": pattern,
                'minLength': 1,
                'maxLength': 100
            },
            'load_type': {
                'type': 'string',
                "pattern": "^(Incremental Load|Full Load|Adhoc)$"
            },
            'source_link_service_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'sink_link_service_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'data_migration_option': {
                'type': 'string',
                "pattern": "^(Glue|Copy)$"
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'data': {
                'type': 'object',
                'required': ['database_details'],
                'additionalProperties': False,
                'properties': {
                    'database_details': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'required': ['database', 'tables'],
                            'additionalProperties': False,
                            'properties': {
                                'database': {
                                    'type': 'string',
                                    "pattern": pattern,
                                    'minLength': 1,
                                    'maxLength': 100
                                },
                                'tables': {
                                    'type': 'array',
                                    'items': {
                                        'type': 'string',
                                        "pattern": pattern,
                                        'minLength': 1,
                                        'maxLength': 100
                                    },
                                    "minItems": 1
                                }
                            }
                        }
                    }
                }
            }
        }
    },
    'delete_schema_migration_job': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'delete_data_migration_job': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
        }
    },
    'data_migration_option': {
        key: url,
        'type': 'object',
        'required': ['link_service_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100

            }
        }
    },
    'database_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'schema_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'db_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'db_name': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'table_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'db_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'db_name': {
                'type': 'string'
            },
            'schema_name': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'column_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'db_name', 'table_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'db_name': {
                'type': 'string'
            },
            'schema_name': {
                'type': 'string'
            },
            'table_name': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'views_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'db_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'db_name': {
                'type': 'string'
            },
            'schema_name': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'view_definition': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'db_name', 'view_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'db_name': {
                'type': 'string'
            },
            'schema_name': {
                'type': 'string'
            },
            'view_name': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },

    'table_definition': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'db_name', 'table_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'db_name': {
                'type': 'string'
            },
            'schema_name': {
                'type': 'string'
            },
            'table_name': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },

    'details_of_all_procedure': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'db_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'db_name': {
                'type': 'string'
            },
            'schema_name': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'details_of_req_procd': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'db_name', 'procedure_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'db_name': {
                'type': 'string'
            },
            'schema_name': {
                'type': 'string'
            },
            'procedure_name': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'list_discovery_id': {
        key: url,
        'type': 'object',
        'required': ['project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'create_link_service': {
        key: url,
        'type': 'object',
        'required': ['link_service_type', 'link_service_name'],
        'additionalProperties': False,
        'properties': {
            'link_service_type': {
                'type': 'string',
                "pattern": pattern,
                'minLength': 1,
                'maxLength': 100
            },
            'link_service_name': {
                'type': 'string',
                "pattern": pattern,
                'minLength': 1,
                'maxLength': 100
            },

            'db_hostname': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'db_user': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'db_password': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'discovery_warehouse_type': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'schema_migration_warehouse_type': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'data_migration_warehouse_type': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'snowflake_subscription_type': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'db_authentication_type': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'shared_path': {
                'type': 'string',
                'maxLength': 100
            },
            's3_bucket_name': {
                'type': 'string',
                'minLenght': 1,
                'maxLength': 100
            },
            'port': {
                'type': 'integer',
                'minLenght': 1,
                'maxLength': 100
            },
            'sid': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'database': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            }
        }
    },
    'delete_link_service': {
        key: url,
        'type': 'object',
        'required': ['link_service_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            }
        }
    },
    'activate_snowflake_integration_service': {
        key: url,
        'type': 'object',
        'required': ['link_service_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            }
        }
    },
    'test_connection': {
        key: url,
        'type': 'object',
        'required': ['link_service_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'username': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'password': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            's3_bucket_name': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            }
        }
    },
    'edit_link_service': {
        key: url,
        'type': 'object',
        'required': ['link_service_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'link_service_name': {
                'type': 'string',
                "pattern": pattern,
                'minLength': 1,
                'maxLength': 100
            },
            'db_user': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'db_password': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'discovery_warehouse_type': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'schema_migration_warehouse_type': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'data_migration_warehouse_type': {
                'type': 'string', 'minLength': 1,
                'maxLength': 100
            },
            'snowflake_subscription_type': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'db_authentication_type': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'shared_path': {
                'type': 'string',
                'maxLength': 100
            },
            'port': {
                'type': 'integer',
                'minLenght': 1,
                'maxLength': 100
            }

        }

    },
    'create_discover_job_register': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'job_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'job_name': {
                'type': 'string',
                "pattern": pattern,
                'minLength': 1,
                'maxLength': 50
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'get_discover_job': {
        key: url,
        'type': 'object',
        'required': ['project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'filter': {
                'type': 'string'
            }
        }
    },
    'delete_discover_job': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
        }
    },
    'discovery_status': {
        key: url,
        'type': 'object',
        'required': ['job_run_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_run_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
        }
    },
    'get_job_run_id': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_id': {
                'type': 'string',
                'minLength': 1,
                'maxLength': 100
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
        }
    },
    'get_latest_discovery': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            },
        }
    },
    'complexityanalyzer_run': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'job_id': {
                'type': 'string'
            },
            'socket': {
                'type': 'string'
            }
        }
    },
    'create_complexityanalyzer_job': {
        key: url,
        'type': 'object',
        'required': ['job_name', 'link_service_id', 'file_path', 'data', 'rule', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_name': {
                'type': 'string',
                "pattern": pattern,
                'minLength': 1,
                'maxLength': 100
            },
            'link_service_id': {
                'type': 'string'
            },
            'file_path': {
                'type': 'string',
                "pattern": "^(\/|(\/\w+)*)\/$",
            },
            'data': {
                'type': 'object',
                'required': ['files'],
                'additionalProperties': False,
                'properties': {
                    'files': {
                        'type': 'array',
                        'items': {
                            'type': 'string'
                        },
                        "minItems": 1
                    }
                }
            },
            'rule': {
                'type': 'object',
                'required': ['simple', 'medium', 'complex'],
                'additionalProperties': False,
                'properties': {
                    'simple': {
                        'type': 'object',
                        'required': ['number_of_lines', 'number_of_queries',
                                     'number_of_dml_statements',
                                     'number_of_ddl_statements', 'number_of_joins',
                                     'number_of_subqueries',
                                     'number_of_tables', 'number_of_columns',
                                     'analytical_functions',
                                     'aggregate_functions', 'distinct_function',
                                     'number_of_columns_updated', 'subquery_in_update',
                                     'where_in_delete',
                                     'subquery_in_delete', 'groupby_count', 'qualify_count',
                                     'parameters_in_script'],
                        'additionalProperties': False,
                        'properties': {
                            'number_of_lines': {
                                'type': 'integer'
                            },
                            'number_of_queries': {
                                'type': 'integer'
                            },
                            'number_of_dml_statements': {
                                'type': 'integer'
                            },
                            'number_of_ddl_statements': {
                                'type': 'integer'
                            },
                            'number_of_joins': {
                                'type': 'integer'
                            },
                            'number_of_subqueries': {
                                'type': 'integer'
                            },
                            'number_of_tables': {
                                'type': 'integer'
                            },
                            'number_of_columns': {
                                'type': 'integer'
                            },
                            'analytical_functions': {
                                'type': 'integer'
                            },
                            'aggregate_functions': {
                                'type': 'integer'
                            },
                            'distinct_function': {
                                'type': 'integer'
                            },
                            'number_of_columns_updated': {
                                'type': 'integer'
                            },
                            'subquery_in_update': {
                                'type': 'integer'
                            },
                            'where_in_delete': {
                                'type': 'integer'
                            },
                            'subquery_in_delete': {
                                'type': 'integer'
                            },
                            'groupby_count': {
                                'type': 'integer'
                            },
                            'qualify_count': {
                                'type': 'integer'
                            },
                            'parameters_in_script': {
                                'type': 'integer'
                            }
                        }
                    },
                    'medium': {
                        'type': 'object',
                        'required': ['number_of_lines', 'number_of_queries',
                                     'number_of_dml_statements',
                                     'number_of_ddl_statements', 'number_of_joins',
                                     'number_of_subqueries',
                                     'number_of_tables', 'number_of_columns',
                                     'analytical_functions',
                                     'aggregate_functions', 'distinct_function',
                                     'number_of_columns_updated', 'subquery_in_update',
                                     'where_in_delete',
                                     'subquery_in_delete', 'groupby_count', 'qualify_count',
                                     'parameters_in_script'],
                        'additionalProperties': False,
                        'properties': {
                            'number_of_lines': {
                                'type': 'integer'
                            },
                            'number_of_queries': {
                                'type': 'integer'
                            },
                            'number_of_dml_statements': {
                                'type': 'integer'
                            },
                            'number_of_ddl_statements': {
                                'type': 'integer'
                            },
                            'number_of_joins': {
                                'type': 'integer'
                            },
                            'number_of_subqueries': {
                                'type': 'integer'
                            },
                            'number_of_tables': {
                                'type': 'integer'
                            },
                            'number_of_columns': {
                                'type': 'integer'
                            },
                            'analytical_functions': {
                                'type': 'integer'
                            },
                            'aggregate_functions': {
                                'type': 'integer'
                            },
                            'distinct_function': {
                                'type': 'integer'
                            },
                            'number_of_columns_updated': {
                                'type': 'integer'
                            },
                            'subquery_in_update': {
                                'type': 'integer'
                            },
                            'where_in_delete': {
                                'type': 'integer'
                            },
                            'subquery_in_delete': {
                                'type': 'integer'
                            },
                            'groupby_count': {
                                'type': 'integer'
                            },
                            'qualify_count': {
                                'type': 'integer'
                            },
                            'parameters_in_script': {
                                'type': 'integer'
                            }
                        }
                    },
                    'complex': {
                        'type': 'object',
                        'required': ['number_of_lines', 'number_of_queries',
                                     'number_of_dml_statements',
                                     'number_of_ddl_statements', 'number_of_joins',
                                     'number_of_subqueries',
                                     'number_of_tables', 'number_of_columns',
                                     'analytical_functions',
                                     'aggregate_functions', 'distinct_function',
                                     'number_of_columns_updated', 'subquery_in_update',
                                     'where_in_delete',
                                     'subquery_in_delete', 'groupby_count', 'qualify_count',
                                     'parameters_in_script'],
                        'additionalProperties': False,
                        'properties': {
                            'number_of_lines': {
                                'type': 'integer'
                            },
                            'number_of_queries': {
                                'type': 'integer'
                            },
                            'number_of_dml_statements': {
                                'type': 'integer'
                            },
                            'number_of_ddl_statements': {
                                'type': 'integer'
                            },
                            'number_of_joins': {
                                'type': 'integer'
                            },
                            'number_of_subqueries': {
                                'type': 'integer'
                            },
                            'number_of_tables': {
                                'type': 'integer'
                            },
                            'number_of_columns': {
                                'type': 'integer'
                            },
                            'analytical_functions': {
                                'type': 'integer'
                            },
                            'aggregate_functions': {
                                'type': 'integer'
                            },
                            'distinct_function': {
                                'type': 'integer'
                            },
                            'number_of_columns_updated': {
                                'type': 'integer'
                            },
                            'subquery_in_update': {
                                'type': 'integer'
                            },
                            'where_in_delete': {
                                'type': 'integer'
                            },
                            'subquery_in_delete': {
                                'type': 'integer'
                            },
                            'groupby_count': {
                                'type': 'integer'
                            },
                            'qualify_count': {
                                'type': 'integer'
                            },
                            'parameters_in_script': {
                                'type': 'integer'
                            }
                        }
                    }
                }
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'get_complexityanalyzer_job': {
        key: url,
        'type': 'object',
        'required': ['project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'filter': {
                'type': 'string'
            }
        }
    },
    'delete_complexityanalyzer_job': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'view_complexity': {
        key: url,
        'type': 'object',
        'required': ['job_run_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'job_run_id': {
                'type': 'string'
            }
        }
    },
    'complexityanalyzer_status': {
        key: url,
        'type': 'object',
        'required': ['job_run_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'complexityanalyzer_files': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'file_path'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'file_path': {
                'type': 'string',
                "pattern": "^(\/|(\/.+)*)\/$"
            }
        }
    },
    'complexityanalyzer_file_content': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'file_path'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'file_path': {
                'type': 'string',
                'pattern': '^(\/|(\/.+)*)\/.+\.(btq|BTQ)$'
            }
        }
    },
    'etl_td_snowflake': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'socket': {
                'type': 'string'
            }
        }
    },
    'create_etl_td_snowflake_job': {
        key: url,
        'type': 'object',
        'required': ['job_name', 'link_service_id', 'file_path', 'data', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_name': {
                'type': 'string',
                "pattern": pattern,
                'minLength': 1,
                'maxLength': 100
            },
            'link_service_id': {
                'type': 'string'
            },
            'file_path': {
                'type': 'string',
                "pattern": "^(\/|(\/.+)*)\/$"
            },
            'data': {
                'type': 'object',
                'required': ['files'],
                'additionalProperties': False,
                'properties': {
                    'files': {
                        'type': 'array',
                        'items': {
                            'type': 'string'
                        },
                        "minItems": 1
                    }
                }
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'get_etl_td_snowflake_job': {
        key: url,
        'type': 'object',
        'required': ['project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'filter': {
                'type': 'string'
            }
        }
    },
    'delete_etl_td_snowflake_job': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'etl_td_snowflake_status': {
        key: url,
        'type': 'object',
        'required': ['job_run_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'etl_file_content': {
        key: url,
        'type': 'object',
        'required': ['job_run_id', 'file_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            },
            'file_name': {
                'type': 'string',
                'pattern': '^.*\.(btq|sql|py)$'
            }
        }
    },
    'etl_read_variables': {
        key: url,
        'type': 'object',
        'additionalProperties': False,
        'minProperties': 1,
        'properties': {
            'job_id': {
                'type': 'string'
            },
            'file_path': {
                'type': 'string'
            }
        }
    },
    'etl_path_variables': {
        key: url,
        'type': 'object',
        'required': ['project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'etl_job_variables': {
        key: url,
        'type': 'object',
        'required': ['project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'secure_view_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'project_id', 'database', 'schema'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'database': {
                'type': 'string',
                'pattern': data_sharing_pattern
            },
            'schema': {
                'type': 'string',
                'pattern': data_sharing_pattern
            }
        }
    },
    'share_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id','project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            }
        }
    },
    'reader_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id','project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            }
        }
    },
    'unassigned_shares': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'project_id', 'reader_name'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'reader_name': {
                'type': 'string',
                'pattern': data_sharing_pattern
            }
        }
    },
    'unassigned_readers': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'project_id', 'share_name'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            },
            'share_name': {
                'type': 'string',
                'pattern': data_sharing_pattern
            }
        }
    },
    'datasharing_create_share': {
        key: url,
        'type': 'object',
        'required': ['share_name', 'database', 'data', 'link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'share_name': {
                'type': 'string',
                'pattern': data_sharing_pattern,
                'minLength': 1
            },
            'database': {
                'type': 'string',
                'pattern': data_sharing_pattern,
                'minLength': 1
            },
            'link_service_id': {
                'type': 'string',
                'minLength': 1
            },
            'project_id': {
                'type': 'string'
            },
            'data': {
                'type': 'array',
                'items': {
                    'type': 'object',
                    'required': ['schema', 'tables', 'secure_views'],
                    'additionalProperties': False,
                    'properties': {
                        'schema': {
                            'type': 'string',
                            'pattern': data_sharing_pattern,
                            'minLength': 1
                        },
                        'tables': {
                            'type': 'array',
                            'items': {
                                'type': 'string',
                                'pattern': data_sharing_pattern,
                                'minLength': 1
                            }
                        },
                        'secure_views': {
                            'type': 'array',
                            'items': {
                                'type': 'string',
                                'pattern': data_sharing_pattern,
                                'minLength': 1
                            }
                        }
                    }
                },
                "minItems": 1
            }
        }
    },
    'datasharing_edit_share': {
        key: url,
        'type': 'object',
        'required': ['share_name', 'database', 'data', 'link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'share_name': {
                'type': 'string',
                'pattern': data_sharing_pattern,
                'minLength': 1
            },
            'database': {
                'type': 'string',
                'pattern': data_sharing_pattern,
                'minLength': 1
            },
            'link_service_id': {
                'type': 'string',
                'minLength': 1
            },
            'project_id': {
                'type': 'string'
            },
            'data': {
                'type': 'array',
                'items': {
                    'type': 'object',
                    'required': ['schema', 'tables', 'secure_views'],
                    'additionalProperties': False,
                    'properties': {
                        'schema': {
                            'type': 'string',
                            'pattern': data_sharing_pattern,
                            'minLength': 1
                        },
                        'tables': {
                            'type': 'array',
                            'items': {
                                'type': 'string',
                                'pattern': data_sharing_pattern,
                                'minLength': 1
                            }
                        },
                        'secure_views': {
                            'type': 'array',
                            'items': {
                                'type': 'string',
                                'pattern': data_sharing_pattern,
                                'minLength': 1
                            }
                        }
                    }
                },
                "minItems": 1
            }
        }
    },
    'datasharing_create_reader': {
        key: url,
        'type': 'object',
        'required': ['reader_name', 'user', 'password', 'link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'reader_name': {
                'type': 'string',
                'pattern': data_sharing_pattern
            },
            'user': {
                'type': 'string',
                'pattern': '^[a-zA-Z_]+\w*$'
            },
            'password': {
                'type': 'string',
                'pattern': '(?=^.{8,}$)(?=.*\d)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$'
            },
            'project_id': {
                'type': 'string'
            }
        }
    },
    'datasharing_assign_shares': {
        key: url,
        'type': 'object',
        'required': ['readers', 'shares', 'link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            },
            'readers': {
                'type': 'array',
                'items': {
                    'type': 'string',
                    'pattern': data_sharing_pattern,
                    'minLength': 1
                }
            },
            'shares': {
                'type': 'array',
                'items': {
                    'type': 'string',
                    'pattern': data_sharing_pattern,
                    'minLength': 1
                },
                "minItems": 1
            },
            'full_accounts': {
                'type': 'array',
                'items': {
                    'type': 'string',
                    'pattern': data_sharing_pattern,
                    'minLength': 1
                }
            }
        }
    },
    'datasharing_revoke_shares': {
        key: url,
        'type': 'object',
        'required': ['readers', 'shares', 'link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            },
            'readers': {
                'type': 'array',
                'items': {
                    'type': 'string',
                    'pattern': data_sharing_pattern,
                    'minLength': 1
                }
            },
            'shares': {
                'type': 'array',
                'items': {
                    'type': 'string',
                    'pattern': data_sharing_pattern,
                    'minLength': 1
                },
                "minItems": 1
            },
            'full_accounts': {
                'type': 'array',
                'items': {
                    'type': 'string',
                    'pattern': data_sharing_pattern,
                    'minLength': 1
                }
            }
        }
    },
    'datasharing_drop_share': {
        key: url,
        'type': 'object',
        'required': ['share_name', 'link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            },
            'share_name': {
                'type': 'string',
                'pattern': data_sharing_pattern,
                'minLength': 1
            }
        }
    },
    'datasharing_drop_reader': {
        key: url,
        'type': 'object',
        'required': ['reader_name', 'link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'reader_name': {
                'type': 'string',
                'pattern': data_sharing_pattern,
                'minLength': 1
            },
            'project_id': {
                'type': 'string'
            }
        }
    },
    'list_dashboard_table': {
        key: url,
        'type': 'object',
        'required': ['database_nm'],
        'additionalProperties': False,
        'properties': {
            'database_nm': {
                'type': 'string',
                'minLength': 1
            }
        }
    },
    'incremental_table_update':{
        key: url,
        'type': 'object',
        'required': ['data'],
        'additionalProperties': False,
        'properties': {
            'data': {
                'type': 'object',
                'additionalProperties': False,
                'properties': {
                    'database_table': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'required': ['database', 'tables'],
                            'additionalProperties': False,
                            'properties': {
                                'database': {
                                    'type': 'string',
                                    "pattern": pattern,
                                    'minLength': 1,
                                    'maxLength': 100

                                },
                                'tables':{
                                    'type': 'array',
                                    'items':{
                                        'type': 'object',
                                        'required': ['table_nm','load_type','split_type'],
                                        'additionalProperties': False,
                                        "minItems": 1,
                                        'properties': {
                                            'table_nm': {
                                                'type': 'string',
                                                'minLength': 1,
                                                'maxLength': 100
                                                },
                                            'load_type':{
                                                'type':'string',
                                                "pattern": "^(Incremental Load|Full Load|Adhoc)$",
                                                'minLength': 1
                                                         },
                                            'split_type':{
                                                'type':'string',
                                                "pattern": "^(No|Range|Duration)$",
                                                'minLength': 1
                                                    },
                                            'column_nm':{
                                                    'type':'string',
                                                    'minLength': 1
                                                },
                                            'value':{
                                                'type':'array',
                                                'items':{
                                                    'type': 'object',
                                                    'additionalProperties': False,
                                                    "minItems": 1,
                                                    "maxItems":2,
                                                    'properties':{
                                                        'value':{
                                                            'type':'string'
                                                        }
                                                    }
                                                }

                                            }
                                            }
                                        }
                                    }
                            }
                        }
                    }
                }
            }
        }
    },
    'col_list': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'database_nm', 'table_nm', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'database_nm': {
                'type': 'string'
            },
            'table_nm': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string',
                'minLength': 1
            }
        }

    },
    'pipeline_template': {
        key: url,
        'type': 'object',
        'required': ['pipeline_template'],
        'additionalProperties': False,
        'properties': {
            'pipeline_template': {
                'type': 'string',
                'pattern': '(Complexity Analyzer|Data Migration|ETL Migration|Schema Migration)'
            }
        }
    },
    'create_pipeline': {
        key: url,
        'type': 'object',
        'required': ['pipeline_name', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string'
            },
            'pipeline_name': {
                'type': 'string',
                'minLength': 1
            },
            'elements': {
                'type': 'array',
                'items': {
                    'type': 'object',
                    'required': ['id', 'position', 'type', 'source_position', 'target_position'],
                    'additionalProperties': False,
                    'properties': {
                        'id': {
                            'type': 'string'
                        },
                        'type': {
                            'type': 'string'
                        },
                        'position': {
                            'type': 'object',
                            'required': ['x', 'y'],
                            'additionalProperties': False,
                            'properties': {
                                'x': {
                                    'type': 'integer'
                                },
                                'y': {
                                    'type': 'integer'
                                }
                            }
                        },
                        'source_position': {
                            'type': 'string'
                        },
                        'target_position': {
                            'type': 'string'
                        }
                    }
                },
                "minItems": 1
            }
        }
    },
    'get_pipeline': {
        key: url,
        'type': 'object',
        'required': ['project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string'
            }
        }
    },
    'update_pipeline': {
        key: url,
        'type': 'object',
        'required': ['pipeline_id', 'elements', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string'
            },
            'pipeline_id': {
                'type': 'string'
            },
            'elements': {
                'type': 'array',
                'items': {
                    'type': 'object',
                    'required': ['id', 'position', 'type', 'source_position', 'target_position'],
                    'additionalProperties': False,
                    'properties': {
                        'id': {
                            'type': 'string'
                        },
                        'type': {
                            'type': 'string'
                        },
                        'position': {
                            'type': 'object',
                            'required': ['x', 'y'],
                            'additionalProperties': False,
                            'properties': {
                                'x': {
                                    'type': 'integer'
                                },
                                'y': {
                                    'type': 'integer'
                                }
                            }
                        },
                        'source_position': {
                            'type': 'string'
                        },
                        'target_position': {
                            'type': 'string'
                        }
                    }
                },
                "minItems": 1
            }
        }
    },
    'delete_pipeline': {
        key: url,
        'type': 'object',
        'required': ['project_id', 'pipeline_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string'
            },
            'pipeline_id': {
                'type': 'string'
            }
        }
    },
    'run_pipeline': {
        key: url,
        'type': 'object',
        'required': ['pipeline_id', 'data', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'pipeline_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            },
            'data': {
                'type': 'array'
            }
        }
    },
    'pipeline_monitor': {
        key: url,
        'type': 'object',
        'required': ['project_id', 'pipeline_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string'
            },
            'pipeline_id': {
                'type': 'string'
            }
        }
    },
    'get_logs': {
        key: url,
        'type': 'object',
        'required': ['project_id'],
        'additionalProperties': False,
        'properties': {
            'pipeline_id': {
                'type': 'string'
            },
            'pipeline_run_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            }
        }
    },
    'pipeline_stats': {
        key: url,
        'type': 'object',
        'required': ['project_id'],
        'additionalProperties': False,
        'properties': {
            'project_id': {
                'type': 'string'
            }
        }
    },
    'job_stats': {
        key: url,
        'type': 'object',
        'required': ['job_type', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_type': {
                'type': 'string',
                'pattern': '^(complexity_analyzer|data_migration|discovery|etl_snowflake|schema_migration)$'
            },
            'project_id': {
                'type': 'string'
            }
        }
    },
    'job_run_stats': {
        key: url,
        'type': 'object',
        'required': ['job_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'job_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            }
        }
    },
    'object_stats': {
        key: url,
        'type': 'object',
        'required': ['link_service_id', 'project_id'],
        'additionalProperties': False,
        'properties': {
            'link_service_id': {
                'type': 'string'
            },
            'project_id': {
                'type': 'string'
            },
            'job_run_id': {
                'type': 'string'
            }
        }
    }
}
