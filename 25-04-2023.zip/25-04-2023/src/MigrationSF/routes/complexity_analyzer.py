"""
This service contains APIs for the complexity analyzer
"""

import sys
import uuid
import datetime
import logging
from ftplib import FTP
import pandas as pd
from bson.json_util import dumps
from flask import request, jsonify
from kafka import KafkaProducer
from config import config, db, send_message
from libs.access_token import validate_access_token
from libs import error
from libs.util import (validate_json_schema, abcr_job_registry, \
    abcr_job_registry_delete, abcr_job_run, response, \
    get_userdata)
from libs.secret_manager import get_secret

# Import app
from . import routes as app

# Log reference
log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'
source_type = "teradata FTP"

@app.route("/idea/services/migrationsf/complexityanalyzer/run", methods=["POST"])
@validate_json_schema
def complexityanalyzer_run():
    """
    Complexity Analyzer for bteq scripts
    """

    log.info("START")
    try:
        # User authentication
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["complexity_analyzer"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Job_id validation
        job_run_id = str(uuid.uuid4())
        creation_time = int(datetime.datetime.utcnow().timestamp())
        creation_time_str = datetime.datetime.fromtimestamp(
            creation_time).strftime(idea_date_format)
        job_register_df = db.job_registry.find_one({"job_id": data['job_id'], 'project_id':data['project_id'],
                                                    "job_type":"complexity_analyzer",
                                                    'active':True}, {'_id': 0})

        if not bool(job_register_df):
            return response(dumps(error.err_078), 404)

        # Link service validation
        file_path = job_register_df['file_path']
        link_service_id = job_register_df["link_service_id"]
        resp = db.link_service.find_one({"link_service_id": link_service_id,
                                         "active": True}, {'_id': 0})
        if not bool(resp):
            return response(dumps(error.err_081), 404)

        # Job execution status validation
        if bool(db.job_run.find_one({"job_id":data['job_id'], "status":"InProgress"})):
            return response(dumps(error.err_0109), 409)

        # Populating ABCR if enabled
        if config["ABCR"]["flag"] == "Y" and abcr_job_run("","","", job_register_df['job_id'],
                            job_run_id, job_register_df['job_name'],
                            "MigrationSF-Complexity_Analyzer",
                            "",user_data['name'], creation_time,
                            "InProgress",config['ABCR']['complexity'], "") == "Fail":
                return response(dumps(error.err_064), 500)

        # Updating IDEA metadata
        db.job_run.insert_one({"job_id": data['job_id'], "job_run_id": job_run_id,
                               "run_by": user_data['name'],
                               "start_time": creation_time,
                               "start_time_str": creation_time_str,
                               "status": "InProgress",
                               "project_id": data['project_id']})

        # Producing message in kafka topic
        topic_complexity_analyzer = config["kafka"]["topic_complexity_analyzer"]
        server = config["kafka"]["host"]
        producer = KafkaProducer(bootstrap_servers=server,
                                 value_serializer=lambda x: dumps(x).encode('utf-8'))
        username = resp['db_user']
        port = resp["port"]
        password = get_secret(link_service_id + "-password")
        data = {
                "db_hostname": resp["db_hostname"],
                "db_user": username,
                "db_password": password,
                "file_path": file_path,
                "files": job_register_df['data']['files'],
                "job_id": data['job_id'],
                "job_run_id": job_run_id,
                "creation_time": creation_time,
                "job_name": job_register_df["job_name"],
                "run_by": user_data['name'],
                "port": port,
                "user_id": user_data['user_id'],
                "socket_flag": "socket" in data,
                "pipeline_run_id": data['socket'] if "socket" in data else None,
                "pipeline_id": db.canvas_pipeline_run.find_one({"pipeline_run_id": data['socket']})['pipeline_id'] if "socket" in data else None
            }
        producer.send(topic_complexity_analyzer, value=data)
        if data['socket_flag']:
            send_message("sf_complexity_run_job_status", {"job_id": data['job_id'], "status": "InProgress", "pipeline_id": data['pipeline_id'], "pipeline_run_id": data['pipeline_run_id']}, data['user_id'])
    except Exception as e_error:
        if data['socket_flag']:
            for file in data['files']:
                send_message("sf_complexity_run_status", {file.split(".")[0]:{"status":"Fail", "complexity":"Not Determined"}, "pipeline_id": data['pipeline_id'], "pipeline_run_id": data['pipeline_run_id']}, data['user_id'])
            send_message("sf_complexity_run_job_status", {"job_id": data['job_id'], "status": "Fail", "pipeline_id": data['pipeline_id'], "pipeline_run_id": data['pipeline_run_id']}, data['user_id'])
        log.error(e_error)
        end_time = int(datetime.datetime.utcnow().timestamp())
        end_time_str = datetime.datetime.fromtimestamp(end_time).strftime(idea_date_format)
        db.job_run.update_one({"job_id": data["job_id"],
                               "job_run_id": job_run_id},
                              {"$set": {"status": "Fail", "end_time": end_time,
                                        "end_time_str": end_time_str}})
        if config["ABCR"]["flag"] == "Y" and abcr_job_run("",end_time, "", job_register_df['job_id'],
                            job_run_id, job_register_df['job_name'],
                            "MigrationSF-Complexity_Analyzer",
                            "",user_data['name'], creation_time,
                            "Fail",config['ABCR']['complexity'], "") == "Fail":
                return response(dumps(error.err_064), 500)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                  "category": "Snowflake_Migration",
                  "error_code": "",
                  "message": "Complexity analyzer is in progress",
                  "data": {"job_run_id": job_run_id}}),200


@app.route("/idea/services/migrationsf/complexityanalyzer/job-register", methods=["POST"])
@validate_json_schema
def create_complexityanalyzer_job():
    """
    Create Complexity Analyzer Job
    """
    try:
        # User authentication
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["complexity_analyzer"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Job name uniqueness validation
        job_id = str(uuid.uuid4())
        job_name = data['job_name']
        link_service_id = data['link_service_id']
        rule = data['rule']
        files = data['data']['files']
        file_path = data["file_path"]
        if bool(db.job_registry.find_one({"job_name":job_name,
                                          "active":True,
                                          "job_type":"complexity_analyzer",
                                          "project_id": data["project_id"]})):
            return response(dumps(error.err_077), 409)
        created_at = int(datetime.datetime.utcnow().timestamp())
        created_at_str = datetime.datetime.fromtimestamp(created_at).strftime(idea_date_format)

        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":link_service_id, "active":True,
        "link_service_type": source_type}, {"_id":0, "link_service_type":1, "link_service_name": 1})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Complexity rule validation
        for i in data['rule']['simple']:
            if not ((data['rule']['simple'][i] < data['rule']['medium'][i]) and
                    (data['rule']['medium'][i] < data['rule']['complex'][i])):
                return response(dumps(error.err_071), 400)


        job_register_df = {'job_type': "complexity_analyzer",
                           'job_name': job_name,
                           'link_service_id': link_service_id,
                           'link_service_type': source_type,
                           'file_path': file_path,
                           'job_id': job_id,
                           'active': True,
                           'created_at': created_at,
                           'created_at_str': created_at_str,
                           'data': data['data'],
                           'rule': rule,
                           'created_by': user_data['name'],
                           'project_id': data['project_id'],
                           }
        configuration = {
                "endPoint": {"url": "/idea/services/migrationsf/complexityanalyzer/run",
                             "method": "POST"},
                "params": {"jobId": job_id}
            }
        parameters = {
                "jobType": "complexity_analyzer",
                "jobName": job_name,
				"file_path": file_path,
                "rule": rule,
                "source": {
                    "type": source_type,
                    "linkServiceID": link_service_id,
                    "bowID": link_service_id
                },
                "data": data["data"],
            }

        # Populating ABCR if enabled
        if config["ABCR"]["flag"] == "Y" and abcr_job_registry(job_id,
                                           True,
                                           "Other",
                                           configuration,
                                           parameters, created_at,
                                           config['ABCR']['complexity'],
                                           job_name, "MigrationSF-Complexity_Analyzer","", "",
                                           "", "", data['project_id'], user_data['name'], "", "",
                                           user_data['project_name']) == "Fail":
            return response(dumps(error.err_063), 500)
        db.job_registry.insert_one(job_register_df)
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Job registered successfully",
        "data": {"job_id": job_id}}), 200


@app.route("/idea/services/migrationsf/complexityanalyzer/job-register", methods=["GET"])
@validate_json_schema
def get_complexityanalyzer_job():
    """
    List Complexity Analyzer Job
    """
    log.info("START")

    try:
        # User authentication
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["complexity_analyzer"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.args

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Fetching active jobs
        query = {'job_type': 'complexity_analyzer','project_id': data['project_id'],'active': True}
        if "filter" in data:
            filter_param = {"$regex": "(?i)" + data['filter']}
            query['$or'] = [
                {"job_name": filter_param},
                {"file_path": filter_param},
                {"data.files": filter_param},
                {"created_by": filter_param}
            ]
        jobs = list(db.job_registry.find(query, {'_id': 0,'active':0,
                                                'created_at_str':0, 'project_id': 0}).sort([("created_at", -1)]))
        if jobs == []:
            return response(dumps(error.err_088), 404)

        for job in range(len(jobs)):
            link_service_name = db.link_service.find_one({"link_service_id": jobs[job]['link_service_id']},
                                                                    {"_id": 0, "link_service_name": 1})
            jobs[job]['link_service_name'] = link_service_name['link_service_name']
            jobs[job]['project_name'] = user_data['project_name']
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Fetched Complexity Analyzer job register details successfully",
          "data": jobs})


@app.route("/idea/services/migrationsf/complexityanalyzer/job-register", methods=["DELETE"])
@validate_json_schema
def delete_complexityanalyzer_job():
    """
    Delete Complexity Analyzer Job
    """
    log.info("START")

    try:
        # User authentication
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["complexity_analyzer"])
        if not access_details:
            return response(dumps(error.err_051), 401)
        # Get json data
        data = request.args

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Job_id  validation
        job_id = data["job_id"]
        job_register_df = db.job_registry.find_one(
            {"job_id": data['job_id'],
             'job_type': 'complexity_analyzer',
             'active':True, 'project_id':data['project_id']},
            {'_id': 0, 'created_at': 1,
             'job_name': 1, 'execution_schedule': 1})
        if not bool(job_register_df):
            return response(dumps(error.err_088), 404)

        # Updating ABCR
        if config["ABCR"]["flag"] == "Y":
            job_status = abcr_job_registry_delete(job_id,False)
            if job_status == "Fail":
                return response(dumps(error.err_063), 500)
        db.job_registry.update_one({"job_id": job_id}, {'$set': {'active': False}})
        db.job_run.update_many({"job_id": job_id}, {'$set': {'active': False}})
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Record deleted successfully",
          "data": ""}), 200


@app.route("/idea/services/migrationsf/complexityanalyzer/rule", methods=["GET"])
def view_rule():
    """
    View Complexity Analyzer Rule
    """
    log.info("START")

    try:
        # User authentication
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["complexity_analyzer"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Default role
        rule = {
                "simple": {
                    "number_of_lines": 1,
                    "number_of_queries": 1,
                    "number_of_dml_statements": 1,
                    "number_of_ddl_statements": 0,
                    "number_of_joins": 1,
                    "number_of_subqueries": 1,
                    "number_of_tables": 1,
                    "number_of_columns": 1,
                    "analytical_functions": 10,
                    "aggregate_functions": 10,
                    "distinct_function": 1,
                    "number_of_columns_updated": 0,
                    "subquery_in_update": 0,
                    "where_in_delete": 1,
                    "subquery_in_delete": 1,
                    "groupby_count": 0,
                    "qualify_count": 0,
                    "parameters_in_script": 0
                },
                "medium": {
                    "number_of_lines": 500,
                    "number_of_queries": 5,
                    "number_of_dml_statements": 5,
                    "number_of_ddl_statements": 2,
                    "number_of_joins": 5,
                    "number_of_subqueries": 5,
                    "number_of_tables": 10,
                    "number_of_columns": 25,
                    "analytical_functions": 20,
                    "aggregate_functions": 20,
                    "distinct_function": 2,
                    "number_of_columns_updated": 10,
                    "subquery_in_update": 2,
                    "where_in_delete": 2,
                    "subquery_in_delete": 2,
                    "groupby_count": 2,
                    "qualify_count": 2,
                    "parameters_in_script": 1
                },
                "complex": {
                    "number_of_lines": 1500,
                    "number_of_queries": 10,
                    "number_of_dml_statements": 10,
                    "number_of_ddl_statements": 5,
                    "number_of_joins": 10,
                    "number_of_subqueries": 10,
                    "number_of_tables": 25,
                    "number_of_columns": 50,
                    "analytical_functions": 30,
                    "aggregate_functions": 30,
                    "distinct_function": 3,
                    "number_of_columns_updated": 20,
                    "subquery_in_update": 3,
                    "where_in_delete": 3,
                    "subquery_in_delete": 3,
                    "groupby_count": 6,
                    "qualify_count": 5,
                    "parameters_in_script": 2
                }
            }
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Fetched Complexity Analyzer rules successfully",
          "data": rule}), 200


@app.route("/idea/services/migrationsf/complexityanalyzer/view", methods=["POST"])
@validate_json_schema
def view_complexity():
    """
    View Complexity Analyzer Summary
    """
    log.info("START")

    try:
        # User authentication
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["complexity_analyzer"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Fetching job run summary details
        result = list(db.idea_complexity_analyzer_summary.find(
            {'job_run_id':data['job_run_id']}, {'_id': 0,"insert_dttm_str":0}))
        if result == []:
            return response(dumps(error.err_088), 404)

        # Job run project validation
        data_frame = list(db.job_run.find_one(
            {'job_run_id':data['job_run_id'], 'project_id':data['project_id']}))
        if data_frame == []:
            return response(dumps(error.err_089), 400)
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "View complexity executed successfully",
          "data": result})


@app.route("/idea/services/migrationsf/complexityanalyzer/status", methods=["POST"])
@validate_json_schema
def complexityanalyzer_status():
    """
    View Complexity Analyzer Run Status
    """
    log.info("START")

    try:
        # User authentication
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["complexity_analyzer"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Fetching job run status
        data_frame = db.job_run.find_one({'job_run_id': data["job_run_id"]},
                                         {'_id': 0, "start_time_str":0,
                                          "end_time_str":0, 'project_id':0})
        if (not bool(data_frame)) or (not bool(db.job_registry.find_one(
                {"job_id": data_frame['job_id'],'project_id':data['project_id'],
                 "job_type": "complexity_analyzer", "active": True}))):
            return response(dumps(error.err_088), 404)
        run_detail = list(db.job_run_detail.find({'job_run_id': data["job_run_id"]},
                                                 {'_id': 0, "start_time_str":0,
                                                  "end_time_str":0}))
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Complexity analyzer job run status executed successfully",
          "data": {"job_run": data_frame, "job_run_detail": run_detail}}), 200


@app.route("/idea/services/migrationsf/complexityanalyzer/files", methods=["POST"])
@validate_json_schema
def complexityanalyzer_files():
    """
    View FTP files
    """
    log.info("START")

    try:
        # User authentication
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["complexity_analyzer"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # Link service validation
        link_service = db.link_service.find_one({"active":True,
        "link_service_type":source_type,"link_service_id":data["link_service_id"]})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)
        username = link_service['db_user']
        password = get_secret(data["link_service_id"] + "-password")
        hostname = link_service['db_hostname']
        file_path = data["file_path"]

        # Trying  to connect to ftp server
        try:
            port = link_service["port"]
            ftp = FTP()
            ftp.connect(hostname,port)
            ftp.login(username, password)
        except Exception as e_error:
                log.info(e_error)
                return jsonify(error.err_052),403

        # Filepath validation
        try:
            ftp.cwd(file_path)
        except Exception as e_error:
            log.error(e_error)
            return response(dumps(error.err_0106), 404)

        # Fetching file names
        # ftp.set_pasv(False)
        files = ftp.nlst()
        try:
            files.remove(".")
        except Exception:
            pass
        try:
            files.remove("..")
        except Exception:
            pass
        files = [i for i in files if i.endswith(".btq") or i.endswith(".BTQ")]
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Fetched Complexity analyzer FTP files successfully",
          "data":{"files":files}})


@app.route("/idea/services/migrationsf/complexityanalyzer/read-file", methods=["POST"])
@validate_json_schema
def complexityanalyzer_file_content():
    """
    View FTP files
    """
    log.info("START")

    try:
        # User authentication
        access_details  = validate_access_token(request.headers.get('Authorization'),permissions=["complexity_analyzer"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # Link service validation
        link_service = db.link_service.find_one({"active":True,
        "link_service_type":source_type,"link_service_id":data["link_service_id"]})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)
        username = link_service['db_user']
        password = get_secret(data["link_service_id"] + "-password")
        hostname = link_service['db_hostname']

        # Trying  to connect to ftp server
        try:
            port = link_service["port"]
            ftp = FTP()
            ftp.connect(hostname,port)
            ftp.login(username, password)
        except Exception as e_error:
                log.info(e_error)
                return jsonify(error.err_052),403
        # Filepath validation
        file_path = data["file_path"]
        try:
            ftp.retrlines("RETR "+file_path, callback=handle_binary)
        except Exception as e_error:
            log.error(e_error)
            return response(dumps(error.err_0106), 404)
        global file_content
        content = '\n'.join(file_content)
        file_content = []
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Complexity analyzer FTP read file executed successfully",
          "data": content}), 200


def handle_binary(more_data):
    """
    handle binary
    """
    file_content.append(more_data)
    return file_content

file_content = []