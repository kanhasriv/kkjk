"""
This service contains APIs for the etl migration ok
"""
import re
import sys
import uuid
import datetime
import logging
import pandas as pd
from bson.json_util import dumps
from flask import request, jsonify
from kafka import KafkaProducer
from config import config, db, s3_client, send_message
from libs.access_token import validate_access_token
from libs import error
from libs.util import (validate_json_schema, abcr_job_registry,\
    abcr_job_registry_delete, abcr_job_run, response, get_userdata)
from libs.secret_manager import get_secret

# Import app
from . import routes as app

# Log reference
log = logging.getLogger(config["logging"]["name"])
idea_date_format = '%Y-%m-%d %H:%M:%S'
source_type = "teradata FTP"

@app.route("/idea/services/migrationsf/etl_td_snowflake/run", methods=["POST"])
@validate_json_schema
def etl_td_snowflake():
    """
    SnowSQL conversion for bteq scripts
    """
    log.info("START")
    try:
        #User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["etl_snowflake"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Job_id validation
        job_run_id = str(uuid.uuid4())
        creation_time = int(datetime.datetime.utcnow().timestamp())
        creation_time_str = datetime.datetime.fromtimestamp(
            creation_time).strftime(idea_date_format)
        job_register_df = db.job_registry.find_one({"job_id": data['job_id'], 'project_id':data['project_id'],
                                                    "job_type": "etl_snowflake",
                                                    'active': True}, {'_id': 0})

        if not bool(job_register_df):
            return response(dumps(error.err_078), 404)

        # Link service validation
        file_path = job_register_df['file_path']
        link_service_id = job_register_df["link_service_id"]
        resp = db.link_service.find_one({"link_service_id": link_service_id,
                                         "active": True}, {'_id': 0})
        if not bool(resp):
            return response(dumps(error.err_081), 404)

        # Job execution status validation
        if bool(db.job_run.find_one({"job_id": data['job_id'], "status": "InProgress"})):
            return response(dumps(error.err_0109), 404)

        # Populating ABCR if enabled
        if config["ABCR"]["flag"] == "Y" and abcr_job_run("", "", "", job_register_df['job_id'],
                                            job_run_id, job_register_df['job_name'], "MigrationSF-ETL_Snowflake",
                                            "", user_data['name'],
                                            creation_time, "InProgress",
                                            config['ABCR']['etl'], "") == "Fail":
            return response(dumps(error.err_064), 500)

        # Updating IDEA metadata
        db.job_run.insert_one({"job_id": data['job_id'],
                               "job_run_id": job_run_id, "run_by": user_data['name'],
                               "start_time": creation_time, "start_time_str": creation_time_str,
                               "status": "InProgress",
                               "project_id": data['project_id']})

        # Producing message in kafka topic
        topic_etl_migration = config["kafka"]["topic_etl_migration"]
        server = config["kafka"]["host"]
        producer = KafkaProducer(bootstrap_servers=server,
                                 value_serializer=lambda x: dumps(x).encode('utf-8'))
        username = resp['db_user']
        port = resp['port']
        password = get_secret(link_service_id + "-password")
        data = {
            "db_hostname": resp["db_hostname"],
            "db_user": username,
            "db_password": password,
            "file_path": file_path,
            "files": job_register_df['data']['files'],
            "job_id": data['job_id'],
            "job_run_id": job_run_id,
            "creation_time": creation_time,
            "job_name": job_register_df["job_name"],
            "link_service_id": link_service_id,
            "run_by": user_data['name'],
            "port": port,
            "user_id": user_data['user_id'],
            "socket_flag": "socket" in data,
            "pipeline_run_id": data['socket'] if "socket" in data else None,
            "pipeline_id": db.canvas_pipeline_run.find_one({"pipeline_run_id": data['socket']})['pipeline_id'] if "socket" in data else None
        }
        producer.send(topic_etl_migration, value=data)
        if data['socket_flag']:
            send_message("sf_etl_run_job_status", {"job_id": data['job_id'], "status": "InProgress", "pipeline_id": data['pipeline_id'], "pipeline_run_id": data['pipeline_run_id']}, data['user_id'])
    except Exception as e_error:
        if data['socket_flag']:
            for file in data['files']:
                send_message("sf_etl_run_status", {file.split(".")[0]:{"status":"Fail"}, "pipeline_id": data['pipeline_id'], "pipeline_run_id": data['pipeline_run_id']}, data['user_id'])
            send_message("sf_etl_run_job_status", {"job_id": data['job_id'], "status": "Fail", "pipeline_id": data['pipeline_id'], "pipeline_run_id": data['pipeline_run_id']}, data['user_id'])
        log.error(e_error)
        end_time = int(datetime.datetime.utcnow().timestamp())
        end_time_str = datetime.datetime.fromtimestamp(end_time).strftime(idea_date_format)
        db.job_run.update_one({"job_id": data["job_id"],
                               "job_run_id": job_run_id},
                              {"$set": {"status": "Fail",
                                        "end_time": end_time,
                                        "end_time_str": end_time_str}})
        if config["ABCR"]["flag"] == "Y" and  abcr_job_run( "", end_time, "", job_register_df['job_id'],
                                                    job_run_id, job_register_df['job_name'], "MigrationSF-ETL_Snowflake",
                                                    "", user_data['name'],
                                                    creation_time, "Fail",
                                                    config['ABCR']['etl'], "") == "Fail":
            return response(dumps(error.err_064), 500)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "ETL Migration is in progress",
                    "data": {"job_run_id": job_run_id}})


@app.route("/idea/services/migrationsf/etl_td_snowflake/job-register", methods=["POST"])
@validate_json_schema
def create_etl_td_snowflake_job():
    """
    Create ETL Migration Job
    """
    try:
        # User authentication
        access_details = validate_access_token(request.headers.get('Authorization'),
                                     permissions=["etl_snowflake"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Job name uniqueness validation
        job_id = str(uuid.uuid4())
        job_name = data['job_name']
        link_service_id = data['link_service_id']
        files = data['data']['files']
        file_path = data["file_path"]
        if bool(db.job_registry.find_one({"job_name": job_name,
                                          "active": True,
                                          "job_type": "etl_snowflake",
                                          "project_id": data["project_id"]})):
            return response(dumps(error.err_077), 409)
        created_at = int(datetime.datetime.utcnow().timestamp())
        created_at_str = datetime.datetime.fromtimestamp(created_at).strftime(idea_date_format)

        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":link_service_id, "active":True,
                        "link_service_type": source_type}, {"_id":0, "link_service_name": 1})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)
        

        job_register_df = {'job_type': "etl_snowflake",
                           'job_name': job_name,
                           'link_service_id': link_service_id,
                           'link_service_type': source_type,
                           'file_path': file_path,
                           'job_id': job_id,
                           'active': True,
                           'created_at': created_at,
                           'created_at_str': created_at_str,
                           'data': data['data'],
                           'created_by': user_data['name'],
                           'project_id': data['project_id']
                           }
        configuration = {
            "endPoint": {"url": "/idea/services/migrationsf/etl_td_snowflake/run",
                         "method": "POST"},
            "params": {"jobId": job_id}
        }
        parameters = {
            "jobType": "etl_snowflake",
            "jobName": job_name,
            "file_path": file_path,
            "source": {
                "type": source_type,
                "linkServiceID": link_service_id,
                "bowID": link_service_id
            },
            "data": data["data"],
        }

        # Populating ABCR if enabled
        if config["ABCR"]["flag"] == "Y":
            job_status = abcr_job_registry(job_id,
                                           True,
                                           "Other",
                                           configuration,
                                           parameters, created_at,
                                           config['ABCR']['etl'],
                                           job_name, "MigrationSF-ETL_Snowflake", "", "",
                                           "", "", data['project_id'], user_data['name'], "", "", 
										   user_data['project_name'])
            if job_status == "Fail":
                return response(dumps(error.err_063), 500)
        db.job_registry.insert_one(job_register_df)
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)
    
    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Job registered successfully",
        "data": {"job_id": job_id}}), 200


@app.route("/idea/services/migrationsf/etl_td_snowflake/job-register", methods=["GET"])
@validate_json_schema
def get_etl_td_snowflake_job():
    """
    List ETL Migration Job
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["complexity_analyzer"])
        if not access_details:
            return response(dumps(error.err_051), 401)
        # Get json data
        data = request.args

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Fetching active jobs
        query = {'job_type': 'etl_snowflake','project_id': data['project_id'],'active': True}
        if "filter" in data:
            filter_param = {"$regex": "(?i)" + data['filter']}
            query['$or'] = [
                {"job_name": filter_param},
                {"file_path": filter_param},
                {"data.files": filter_param},
                {"created_by": filter_param}
            ]
        jobs = list(db.job_registry.find(query,
                                               {'_id': 0,
                                                'active': 0,
                                                'created_at_str': 0,
                                                'project_id': 0,
                                                'variables': 0}).sort([("created_at", -1)]))
        if jobs == []:
            return response(dumps(error.err_088), 404)

        for job in range(len(jobs)):
            link_service_name = db.link_service.find_one({"link_service_id": jobs[job]['link_service_id']},
                                                                    {"_id": 0, "link_service_name": 1})
            jobs[job]['link_service_name'] = link_service_name['link_service_name']
            jobs[job]['project_name'] = user_data['project_name']
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Fetched ETL TD-SF job register details successfully",
                    "data": jobs}), 200


@app.route("/idea/services/migrationsf/etl_td_snowflake/job-register", methods=["DELETE"])
@validate_json_schema
def delete_etl_td_snowflake_job():
    """
    Delete ETL Migration Job
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["etl_snowflake"])
        if not access_details:
            return response(dumps(error.err_051), 401)
        # Get json data
        data = request.args

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Job_id validation
        job_id = data["job_id"]
        job_register_df = db.job_registry.find_one(
            {"job_id": data['job_id'], "project_id": data['project_id'],
             'job_type': 'etl_snowflake', 'active': True},
            {'_id': 0, 'created_at': 1,
             'job_name': 1, 'execution_schedule': 1})
        if not bool(job_register_df):
            return response(dumps(error.err_088), 404)

        # Updating ABCR
        if config["ABCR"]["flag"] == "Y":
            job_status = abcr_job_registry_delete(job_id,False)
            if job_status == "Fail":
                return response(dumps(error.err_063), 500)
        db.job_registry.update_one({"job_id": job_id}, {'$set': {'active': False}})
        db.job_run.update_many({"job_id": job_id}, {'$set': {'active': False}})
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "Record deleted successfully",
                    "data": ""}), 200


@app.route("/idea/services/migrationsf/etl_td_snowflake/status", methods=["POST"])
@validate_json_schema
def etl_td_snowflake_status():
    """
    View ETL Migration Run Status
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["etl_snowflake"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Fetching job status
        data_frame = db.job_run.find_one({'job_run_id': data["job_run_id"]},
        {'_id': 0,'start_time_str': 0, 'end_time_str': 0, 'project_id':0})
        if (not bool(data_frame)) or (not bool(db.job_registry.find_one(
                {"job_id": data_frame['job_id'],'project_id':data['project_id'],
                 "job_type": "etl_snowflake", "active": True}))):
            return response(dumps(error.err_088), 404)
        run_detail = list(db.job_run_detail.find({'job_run_id': data["job_run_id"]},
        {'_id': 0,'start_time_str': 0,'end_time_str': 0}))
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "ETL TD-SF status executed successfully",
                    "data": {"job_run": data_frame, "job_run_detail": run_detail}}), 200


@app.route("/idea/services/migrationsf/etl_td_snowflake/read-file", methods=["POST"])
@validate_json_schema
def etl_file_content():
    """
    View FTP files
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["etl_snowflake"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Checking file extension
        file_name = data["file_name"]
        if file_name.endswith('.btq'):
            key = "input_file"
        elif file_name.endswith('.sql'):
            key = "snowflake_file"
        else:
            key = "snowflake_python_exec"
        job_run_id = data['job_run_id']
        data_frame = db.job_run.find_one({'job_run_id': job_run_id,
        "project_id":data['project_id'],
        "files_list": {"$elemMatch": {key: file_name}}}, {'_id': 0})
        if bool(data_frame):
            job_df = db.job_registry.find_one(
                {"job_id": data_frame['job_id'],
                 "job_type": "etl_snowflake", "active": True})
            if not bool(job_df):
                return response(dumps(error.err_088), 404)
        else:
            return response(dumps(error.err_088), 404)

        # Fetching file content from aws s3 bucket
        file_content = s3_client.get_object(Bucket=config['aws']['bucket'],
        Key="sfmigration/"+job_df['link_service_id']+"/ETL_Migration"+"/"+job_run_id+"/"+file_name)
        file_content = file_content['Body'].read().decode("utf-8")
        if file_name.endswith('.btq'):
            file_name = file_name.split(".")[0]
        else:
            file_name = file_name.split(".")[0][3:]
        
        # File variables validation
        variables = db.idea_etl_variables.find_one({job_df['file_path']
                                                    + "." + file_name: {"$exists": True}},
                                                   {"_id": 0, 
                                                   job_df['file_path']+ "." + file_name: 1})
        if bool(variables):
            for variable in variables[job_df['file_path']][file_name].keys():
                file_content = re.sub(r"\$\s*" + variable,
                                      variables[job_df['file_path']][file_name][variable],
                                      file_content)
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "ETL TD-SF read file executed successfully",
                    "data": file_content}), 200


@app.route("/idea/services/migrationsf/etl_td_snowflake/file-type", methods=["GET"])
def etl_file_type():
    """
        This API get the list of etl file types
        :return: json response
        """
    log.info("START")
    # User authentication
    if not validate_access_token(request.headers.get('Authorization'),
                                 permissions=["etl_snowflake"]):
        return response(dumps(error.err_051), 401)

    resp = {"status": "Success",
            "category": "Snowflake_Migration",
            "error_code": "",
            "message": "ETL TD-SF file type fetched successfully",
            "data": {"file_types": ["Snowflake SQL", "Snowflake Python Exec"]}}

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/etl_td_snowflake/read-variables", methods=["POST"])
@validate_json_schema
def etl_read_variables():
    """
    View FTP files variables
    """
    log.info("START")

    try:
        # User authentication
        if not validate_access_token(request.headers.get('Authorization'),
                                     permissions=["etl_snowflake"]):
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # Fetching job variables
        key = list(data)[0]
        data_frame = {}
        if key == 'job_id':
            job_df = db.job_registry.find_one({"job_id":data['job_id']},
                        {"_id": 0, "file_path": 1, "data.files": 1})
            file_path = job_df['file_path']
            data_frame[file_path] = {}
            for file in job_df['data']['files']:
                file_name = file.split(".")[0]
                variables = db.idea_etl_variables.find_one({file_path + "." 
                                                    + file_name: {"$exists": True}},
                                                   {"_id": 0, 
                                                   file_path + "." + file_name: 1})
                if bool(variables):
                    data_frame[file_path][file_name] = variables[file_path][file_name]
        else:
            file_path = data['file_path']
            data_frame = db.idea_etl_variables.find_one({},{"_id": 0, file_path: 1})
        for file in data_frame[file_path].keys():
            data_frame[file_path][file].pop('job_id')
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "ETL TD-SF read file variables executed successfully",
                    "data": data_frame}), 200


@app.route("/idea/services/migrationsf/etl_td_snowflake/write-variables", methods=["POST"])
def etl_write_variables():
    """
    Write FTP files variables
    """
    log.info("START")

    try:
        # User authentication
        if not validate_access_token(request.headers.get('Authorization'),
                                     permissions=["etl_snowflake"]):
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # Update IDEA metadata
        file_path = list(data)[0]
        for file in data[file_path].keys():
            for variable in data[file_path][file].keys():
                db.idea_etl_variables.update_one({},
                {"$set":{file_path+"."+file+"."+variable: data[file_path][file][variable]}})
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
                    "category": "Snowflake_Migration",
                    "error_code": "",
                    "message": "ETL TD-SF write file variables executed successfully",
                    "data": ""}), 200


@app.route("/idea/services/migrationsf/etl_td_snowflake/path-variables", methods=["GET"])
@validate_json_schema
def etl_path_variables():
    """
        This API get the file_paths for variables
        :return: json response
        """
    log.info("START")
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                    permissions=["etl_snowflake"])
        if not access_details:
            return response(dumps(error.err_051), 401)
        # Get json data
        data = request.args

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Fetching path variables
        data = list(db.job_registry.find({"active":True, "variables":True,
                        "project_id": data['project_id']},
                        {"_id": 0, "file_path": 1}))
        resp = {"status": "Success",
                "category": "Snowflake_Migration",
                "error_code": "",
                "message": "ETL TD-SF get variable paths executed successfully",
                "data": list(set(path['file_path'] for path in data))}
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify(resp), 200


@app.route("/idea/services/migrationsf/etl_td_snowflake/job-variables", methods=["GET"])
@validate_json_schema
def etl_job_variables():
    """
        This API get the jobs for variables
        :return: json response
        """
    log.info("START")
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                    permissions=["etl_snowflake"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.args

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Fetching job variables
        resp = {"status": "Success",
                "category": "Snowflake_Migration",
                "error_code": "",
                "message": "ETL TD-SF get variable jobs executed successfully",
                "data": list(db.job_registry.find({"active":True, "variables":True,
                        "project_id": data['project_id']},
                        {"_id": 0, "job_id": 1, "job_name": 1}))}
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify(resp), 200