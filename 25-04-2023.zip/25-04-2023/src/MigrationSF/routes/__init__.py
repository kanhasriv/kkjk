# Route the APIs
from flask import Blueprint
routes = Blueprint('routes', __name__)

# Discover
from .discover import *

# Discover_plane
from .discover_plane import *

# schema_migration
from .schema_migration import *

# etl_migration
from .etl_migration import *

# data_migration
from .data_migration import *

# link service
from .link_service import *

# Complexity_analyzer
from .complexity_analyzer import *

# Data_Sharing
# from .data_sharing import *

# Canvas_Pipeline
# from .canvas_pipeline import *