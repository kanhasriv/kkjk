"""
This service contains APIs for the data discover
"""
import json
import logging
import sys
from libs.util import (format_json, response, validate_json_schema, get_userdata, get_batch_id)
from libs.access_token import validate_access_token
import pandas as pd
from bson.json_util import dumps
from flask import request, jsonify
from config import config, db
from libs import error
# Import app
from . import routes as app

log = logging.getLogger(config["logging"]["name"])
match_query = "$match"
group_query = "$group"
snowflake_dwh = "snowflake DWH"
mongodb_exists = "$exists"

@app.route('/idea/services/migrationsf/discovery-list', methods=['GET'])
@validate_json_schema
def list_discovery_id():
    """
    Returns the list of discovery id with last date time
    :return: json data
    """
    log.info("START")

    try:
        access_details=validate_access_token(request.headers.get('Authorization'),permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)


        # Get json data
        data = request.args

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        temp_df = pd.DataFrame(db.idea_database_discovery_attr.aggregate(
            [{match_query: {"project_id": data['project_id']}},
            {group_query: {"_id": {"batch_id": "$batch_id", "database_vendor": "$database_vendor"},
                         "assigned_on": {"$max": "$insert_dttm"}}}]))
        if temp_df.empty:
            return response(dumps(error.err_088), 404)
                
        resp_df = pd.DataFrame(temp_df["_id"].tolist())
        resp_df["assigned_on"] = temp_df["assigned_on"]
        result = resp_df.to_json()
        result = format_json(json.loads(result))
        resp = {"data": []}
        for item in result:
            if item is None:
                continue
            temp = {'database_vendor': item['database_vendor'], 'batch_id': item['batch_id'],
                    'assigned_on': item['assigned_on']}
            resp['data'].append(temp)
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Discovery-id's fetched successfully",
        "data": resp['data']}), 200


@app.route("/idea/services/migrationsf/overview", methods=["POST"])
@validate_json_schema
def overview():
    """
    This service will get the overview of the databases
    :return: json data
    """
    log.info("START")
    
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)
        
        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        db_vendor = db.idea_database_discovery_attr.find_one({"batch_id": batch_id,
                                                            "project_id": data['project_id']},
                                                             {"_id": 0, "database_vendor": 1})
        if not bool(db_vendor):
            return response(dumps(error.err_088), 404)

        db_vendor = db_vendor["database_vendor"]
        
        # Database Count
        db_count = db.idea_database_discovery_attr.count_documents({"batch_id": batch_id,"project_id": data['project_id']})
        if not db_count:
            return response(dumps(error.err_088), 404)

        # Database details
        if db_vendor.lower() == 'teradata':
            resp_df = pd.DataFrame(
                db.idea_database_discovery_attr.find({"batch_id": batch_id,
                                                    "project_id": data['project_id']},
                                                     {"_id": 0, "database_nm": 1,
                                                      "space_measure_in": 1,
                                                      "occupied_space": 1}))
            hashamp_result = db.idea_hashamp_discovery_attr.find_one({"batch_id": batch_id,
                                                                    "project_id": data['project_id']},
                                                                     {"_id": 0,
                                                                      "(hashamp()+1)": 1})
            if hashamp_result is None:
                hashamp_result = {'(hashamp()+1)': 0}
        if db_vendor.lower() == 'snowflake':
            resp_df = pd.DataFrame(
                db.idea_database_discovery_attr.find({"batch_id": batch_id,
                                                    "project_id": data['project_id']},
                                                     {"_id": 0, "database_nm": 1,
                                                      "space_measure_in": 1,
                                                      "occupied_space": 1}))
            warehouse_count = len(
                db.idea_warehouse_discovery_attr.find({'batch_id': batch_id,"project_id": data['project_id']}).distinct(
                    'warehouse_name'))
            warehouse_details = pd.DataFrame(db.idea_warehouse_discovery_attr.find({"batch_id": batch_id,
                                                                    "project_id": data['project_id']},
                                                                     {"_id": 0, "is_default": 1,
                                                                      "warehouse_name": 1,
                                                                      "type": 1, "size": 1,
                                                                      "min_cluster_count": 1,
                                                                      "max_cluster_count": 1,
                                                                      "credits_used": 1,
                                                                      "credits_used_compute": 1,
                                                                      "credits_used_cloud_services"
                                                                      : 1}))
            warehouse_details[['min_cluster_count', 'max_cluster_count']] = \
            warehouse_details[['min_cluster_count', 'max_cluster_count']].fillna(value=0)
            warehouse_details = warehouse_details.astype({"min_cluster_count": int, "max_cluster_count": int})
            warehouse_details = warehouse_details.to_json()
            warehouse_details = format_json(json.loads(warehouse_details))
        resp_df.rename(columns={"database_nm": "database_name"}, inplace=True)
        
        if resp_df.empty:
            log.info({"message": "Record not found or deleted"})
            return response(dumps(error.err_088), 404)

        if resp_df.space_measure_in[0] != "MB":
            resp_df.occupied_space = round(resp_df.occupied_space / 1048576, 2)
            resp_df.space_measure_in = "MB"
        db_details_result = resp_df.to_json()
        db_details_result = format_json(json.loads(db_details_result))
        # Objects details
        objects = db.idea_object_details_discovery_attr.find({"batch_id": batch_id,
                                                            "project_id": data['project_id']},
                                                             {"_id": 0, "object_kind": 1,
                                                              "object_count": 1})
        objects = pd.DataFrame(objects)
        if objects.empty:
            log.info({"message": "Record not found or deleted"})
            return response(dumps(error.err_088), 404)

        objects[['object_count']] = objects[['object_count']].fillna(value=0)
        objects['object_count'] = objects['object_count'].apply(float).apply(int)
        object_result = objects.to_json()
        object_result = format_json(json.loads(object_result))
        # Users details
        role_df = pd.DataFrame(db.idea_user_discovery_attr.aggregate(
            [{match_query: {"batch_id": batch_id, "project_id": data['project_id'],"role_nm": {'$ne': None}}},
             {group_query: {"_id": {"users": "$user_nm", "roles": "$role_nm"}}},
             {group_query: {"_id": "$_id.users", "count": {'$sum': 1}}}]))
        table_df = pd.DataFrame(db.idea_user_discovery_attr.aggregate(
            [{match_query: {"batch_id": batch_id, "project_id": data['project_id'],"role_nm": {'$eq': None}}},
             {group_query: {
                 "_id": {"users": "$user_nm", "dbs": "$database_nm", "schemas": "$schema_nm",
                         "tables": "$object_type"}}},
             {group_query: {"_id": "$_id.users", "count": {'$sum': 1}}}]))
        resp_df = role_df.append(table_df, ignore_index=True)
        if not resp_df.empty:
            resp_df = resp_df.groupby(['_id']).agg(
                user_count=pd.NamedAgg(column='count', aggfunc="sum")).reset_index()
            resp_df.rename(columns={'_id': 'user_name'}, inplace=True)
        else:
            resp_df = pd.DataFrame(
                db.idea_user_discovery_attr.find({'batch_id': batch_id,
                "project_id": data['project_id']}).distinct(
                    'user_nm'))
            resp_df['user_count'] = 0
            resp_df.rename(columns={0: 'user_name'}, inplace=True)
        user_result = resp_df.to_json()
        user_result = format_json(json.loads(user_result))
        # Database server details
        server_details_result = db.idea_database_discovery_attr.find_one(
            {"batch_id": batch_id,"project_id": data['project_id']},
            {"_id": 0, "database_server_nm": 1, "database_version": 1, 'insert_dttm': 1,
             "database_type": 1})
        
        if not bool(server_details_result):
            return response(dumps(error.err_088), 404)

        total_space = 0
        for item in db_details_result:
            total_space = item['occupied_space'] + total_space
        resp = {
                'data': {
                    "database_count": db_count,
                    "database_vendor": db_vendor.lower(),
                    "database_server_name": server_details_result['database_server_nm'],
                    "database_version": server_details_result['database_version'],
                    "database_type": server_details_result['database_type'],
                    "total_occupied_space": round(total_space, 2),
                    "space_measured_in": db_details_result[0]['space_measure_in'],
                    "database_details": db_details_result,
                    "users": user_result,
                    "discover_id": batch_id,
                    "created_at": server_details_result['insert_dttm'],
                    "objects": object_result
                }
            }
        if db_vendor.lower() == 'teradata':
            resp['data']['hashamp'] = hashamp_result["(hashamp()+1)"]
        if db_vendor.lower() == 'snowflake':
            resp['data']['warehouse_count'] = warehouse_count
            resp['data']['warehouse_details'] = warehouse_details
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Overview of the databases fetched successfully",
        "data": resp['data']}), 200


@app.route("/idea/services/migrationsf/database-list", methods=['POST'])
@validate_json_schema
def database_list():
    """
    This service will get the list of the databases
    :return: json data
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        # Fetching database details
        result = pd.DataFrame(
            db.idea_database_discovery_attr.find({"batch_id": batch_id,"project_id": data["project_id"]},
                                                 {"_id": 0, "database_nm": 1, "occupied_space": 1,
                                                  "space_measure_in": 1}))
        if result.empty:
            return response(dumps(error.err_088), 404)

        if result.space_measure_in[0] != "MB":
            result.occupied_space = round(result.occupied_space / 1048576, 2)
            result.space_measure_in = "MB"
        result.rename(columns={"database_nm": "db_name", "space_measure_in": "space_type"},
                      inplace=True)
        result = result.to_json()
        result = format_json(json.loads(result))
        total = len(result)
        result = sorted(result, key=lambda x: x['db_name'].lower())
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Databases list fetched successfully",
        "data": [{'database_count': total, 'databases': result}]}), 200


@app.route("/idea/services/migrationsf/schema-list", methods=['POST'])
@validate_json_schema
def schema_list():
    """
    This service will get the list of the schemas
    :return: json data
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data = get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        database_nm = data['db_name']
        temp_df = pd.DataFrame(db.idea_schema_discovery_attr.find({'batch_id': batch_id,
                                                                "project_id": data["project_id"],
                                                                   'database_name': database_nm}).
                               distinct('schema_name'))
        if temp_df.empty:
            return response(dumps(error.err_088), 404)

        # Fetching schema details
        temp_df.rename(columns={0: "schema_name"}, inplace=True)
        result = temp_df.to_json()
        result = format_json(json.loads(result))
        total = len(result)
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Schemas list fetched successfully",
        "data": [{'schema_count': total, 'schemas': result}]}), 200


@app.route("/idea/services/migrationsf/macro", methods=["POST"])
@validate_json_schema
def macro_list():
    """
    List Down All Macro Service
    :return: json data
    """
    log.info("START")
    
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        database_name = data['db_name']
        resp_df = pd.DataFrame(
            db.idea_macro_discovery_attr.find({"database_nm": database_name, "batch_id": batch_id,
                                                "project_id": data["project_id"]},
                                              {"_id": 0, "macro_nm": 1}))
        if resp_df.empty:
            return response(dumps(error.err_088), 404)

        # Fetching macro details
        resp_df.rename(columns={"macro_nm": "macro_name"}, inplace=True)
        result = resp_df.to_json()
        result = json.loads(result)
        count = len(result['macro_name'].keys())
        result = format_json(result)
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Macros list fetched successfully",
        "data": [{'macro_count': count, 'macros': result}]}), 200


@app.route("/idea/services/migrationsf/macro/definition", methods=["POST"])
@validate_json_schema
def macro_definition():
    """
    Show definition of a particular macro given by user
    :return: json data
    """
    log.info("START")
    
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        # Fetching macro details
        database_name = data['db_name']
        macro_name = data['macro_name']
        resp_df = db.idea_macro_discovery_attr.find_one({"database_nm": database_name,
                                                         "macro_nm": macro_name,
                                                         "batch_id": batch_id,
                                                        "project_id": data["project_id"]},
                                                        {"_id": 0, "macro_definition": 1})
        if not bool(resp_df):
            return response(dumps(error.err_088), 404)

        df_result = resp_df["macro_definition"].replace('\\\\r','\r')
        df_result = df_result.replace('\\r','\r')
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Macro definition fetched successfully",
        "data": [{"macro_definition": df_result}]}), 200


@app.route('/idea/services/migrationsf/table-list', methods=['POST'])
@validate_json_schema
def table_list():
    """
    Return list of tables from a particular database
    :return: json data
    """
    log.info("START")
    
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        database_name = data['db_name']
        db_vendor = db.idea_table_discovery_attr.find_one({"batch_id": batch_id,
                                                        "project_id": data["project_id"]},
                                                          {"_id": 0, "database_vendor": 1})
        if not bool(db_vendor):
            return response(dumps(error.err_088), 404)

        db_vendor = db_vendor["database_vendor"]
        if db_vendor.lower() == 'snowflake' and 'schema_name' not in data:
            return response(dumps(error.err_084), 404)

        # Fetching table details
        if db_vendor.lower() == 'teradata':
            query = db.idea_table_discovery_attr.find(
                {'batch_id': batch_id, 'database_nm': database_name,"project_id": data["project_id"]},
                {'_id': 0, 'data_skewness_prcnt': 1, 'database_nm': 1, 'database_vendor': 1,
                 'tbl_created_by': 1, 'num_of_records': 1, 'rowsize_defined': 1, 'tbl_schema_nm': 1,
                 'last_access_tm': 1, 'tbl_space_occupied_in_mbs': 1, 'table_nm': 1, 'data_distribution_keys':1})
            total = len(db.idea_table_discovery_attr.find(
                {'batch_id': batch_id, "project_id": data["project_id"],
                'database_nm': database_name}).distinct('table_nm'))
        if db_vendor.lower() == 'snowflake':
            schema_name = data['schema_name']
            query = db.idea_table_discovery_attr.find(
                {'batch_id': batch_id, 'database_nm': database_name,
                 'tbl_schema_nm': schema_name,"project_id": data["project_id"]},
                {'_id': 0, 'data_skewness_prcnt': 1, 'database_nm': 1, 'database_vendor': 1,
                 'tbl_created_by': 1, 'num_of_records': 1, 'rowsize_defined': 1, 'tbl_schema_nm': 1,
                 'last_access_tm': 1, 'tbl_space_occupied_in_mbs': 1, 'table_nm': 1, 'data_distribution_keys':1})
            total = len(db.idea_table_discovery_attr.find(
                {'batch_id': batch_id, "project_id": data["project_id"],
                'database_nm': database_name,'tbl_schema_nm': schema_name}
                ).distinct('table_nm'))
        resp_df = pd.DataFrame(query).drop_duplicates(ignore_index=True)
        if resp_df.empty:
            return response(dumps(error.err_088), 404)
        resp_df[['rowsize_defined', 'num_of_records']] = \
            resp_df[['rowsize_defined', 'num_of_records']].fillna(value=0)
        resp_df = resp_df.astype({"num_of_records": float, "rowsize_defined": float})
        resp_df = resp_df.astype({"rowsize_defined": 'int64', "num_of_records": 'int64'})
        resp_df.columns = map(lambda x: x.replace('tbl_', '') if x.startswith('tbl_') else x,
                              resp_df.columns)
        resp_df.columns = [
            x.replace('tbl', 'table').replace('_nm', '_name').replace('_tm', '_time') for x in
            resp_df.columns]
        resp_df.replace({'': None}, inplace=True)
        result = resp_df.to_json()
        result = format_json(json.loads(result))
        result = sorted(result, key=lambda x: x['table_name'].lower())
    except Exception as e_error :
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Tables list fetched successfully",
        "data": [{'table_count': total, 'tables': result}]}), 200


@app.route('/idea/services/migrationsf/table/definition', methods=['POST'])
@validate_json_schema
def table_definition():
    """
    This will return the definition of
    the given table
    :return: json data
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        database_name = data['db_name']
        table_name = data['table_name']
        db_vendor = db.idea_table_discovery_attr.find_one({"batch_id": batch_id,
                                                        "project_id": data["project_id"]},
                                                          {"_id": 0, "database_vendor": 1})
        if not bool(db_vendor):
            return response(dumps(error.err_088), 404)

        db_vendor = db_vendor["database_vendor"]
        if db_vendor.lower() == 'snowflake' and 'schema_name' not in data:
            return response(dumps(error.err_084), 404)

        # Fetching table details
        if db_vendor.lower() == 'teradata':
            query = db.idea_table_discovery_attr.find_one(
                {"database_nm": database_name, "table_nm": table_name,
                "project_id": data["project_id"], "batch_id": batch_id},
                {"_id": 0, "definition": 1})
        if db_vendor.lower() == 'snowflake':
            schema_name = data["schema_name"]
            query = db.idea_table_discovery_attr.find_one(
                {"database_nm": database_name, "tbl_schema_nm": schema_name,
                 "table_nm": table_name, "project_id": data["project_id"],
                 "batch_id": batch_id},
                {"_id": 0, "definition": 1})
        if not bool(query):
            return response(dumps(error.err_088), 404)
        def12 = query['definition'].replace('\\\\r','\r')
        def12 = def12.replace('\\r','\r')
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Table definition fetched successfully",
        "data": [{'table_definition': def12}]}), 200


@app.route("/idea/services/migrationsf/column-list", methods=['POST'])
@validate_json_schema
def column_list():
    """
    This method will return the list of all columns
    available in the given table
    :return: json data
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        database_name = data['db_name']
        table_name = data['table_name']
        db_vendor = db.idea_column_discovery_attr.find_one({"batch_id": batch_id,
                                                        "project_id": data["project_id"]},
                                                           {"_id": 0, "database_vendor": 1})
        if not bool(db_vendor):
            return response(dumps(error.err_088), 404)

        db_vendor = db_vendor["database_vendor"]
        if db_vendor.lower() == 'snowflake' and 'schema_name' not in data:
            return response(dumps(error.err_084), 404)
        
        # Fetching column details
        if db_vendor.lower() == 'teradata':
            query = db.idea_column_discovery_attr.find(
                {'batch_id': batch_id, 'database_nm': database_name,
                "project_id": data["project_id"],
                 "table_nm": table_name}, {'_id': 0,
                                           'insert_dttm_str': 0,
                                           'insert_dttm': 0,
                                           'batch_id': 0,
                                           'column_seq': 0,
                                           'char_type': 0,
                                           'database_server_nm': 0,
                                           'project_id': 0})
        if db_vendor.lower() == 'snowflake':
            schema_name = data['schema_name']
            query = db.idea_column_discovery_attr.find(
                {'batch_id': batch_id, 'database_nm': database_name,
                "project_id": data["project_id"],
                 'schema_nm': schema_name, "table_nm": table_name},
                {'_id': 0, 'insert_dttm': 0, 'insert_dttm_str': 0, 'batch_id': 0,
                 'column_seq': 0, 'char_type': 0,
                 'database_server_nm': 0,
                 'project_id': 0})
        resp_df = pd.DataFrame(query)
        resp_df.columns = [
            x.replace('_ind', '_index').replace('_nm', '_name').replace('_tm', '_time') for x in
            resp_df.columns]
        resp_df.replace({'': None}, inplace=True)
        resp_df['column_length'].replace({None: ''}, inplace=True)
        resp_df.rename(columns={"nullable_ind": "null_index"}, inplace=True)
        if resp_df.empty:
            return response(dumps(error.err_088), 404)
        result = resp_df.to_json()
        result = format_json(json.loads(result))
        total = len(result)
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Columns list fetched successfully",
        "data": [{'column_count': total, 'columns': result}]}), 200


@app.route('/idea/services/migrationsf/views', methods=['POST'])
@validate_json_schema
def views_list():
    """
    This method will return the list of
    all views available in the database
    :return: json data
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        database_name = data['db_name']
        db_vendor = db.idea_view_discovery_attr.find_one({"batch_id": batch_id,
                                                        "project_id": data["project_id"]},
                                                         {"_id": 0, "database_vendor": 1})
        if not bool(db_vendor):
            return response(dumps(error.err_088), 404)

        db_vendor = db_vendor["database_vendor"]
        if db_vendor.lower() == 'snowflake' and 'schema_name' not in data:
            return response(dumps(error.err_084), 404)

        # Fetching views details        
        if db_vendor.lower() == 'teradata':
            query = db.idea_view_discovery_attr.find(
                {"database_nm": database_name, "batch_id": batch_id,
                "project_id": data["project_id"]},
                {"_id": 0, "view_nm": 1})
        if db_vendor.lower() == 'snowflake':
            schema_name = data['schema_name']
            query = db.idea_view_discovery_attr.find(
                {"database_nm": database_name, "schema_nm": schema_name,
                 "batch_id": batch_id,"project_id": data["project_id"],
                 "is_secure": "NO"},{"_id": 0, "view_nm": 1})
        resp_df = pd.DataFrame(query)
        if resp_df.empty:
            return response(dumps(error.err_088), 404)
        result = resp_df.to_json()
        result = json.loads(result)
        count = len(result['view_nm'].keys())
        result = format_json(result)
        result = sorted(result, key=lambda x: x['view_nm'].lower())
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Views list fetched successfully",
        "data": [{'view_count': count, 'views': result}]}), 200


@app.route('/idea/services/migrationsf/views/definition', methods=['POST'])
@validate_json_schema
def view_definition():
    """
    This will return the definition of
    the given view
    :return: json data
    """
    log.info("START")
    
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        database_name = data['db_name']
        view_name = data['view_name']
        db_vendor = db.idea_view_discovery_attr.find_one({"batch_id": batch_id,
                                                        "project_id": data["project_id"]},
                                                         {"_id": 0, "database_vendor": 1})
        if not bool(db_vendor):
            return response(dumps(error.err_088), 404)

        db_vendor = db_vendor["database_vendor"]
        if db_vendor.lower() == 'snowflake' and 'schema_name' not in data:
            return response(dumps(error.err_084), 404)

        # Fetching view details
        if db_vendor.lower() == 'teradata':
            query = db.idea_view_discovery_attr.find_one(
                {"database_nm": database_name, "view_nm": view_name,
                "project_id": data["project_id"], "batch_id": batch_id},
                {"_id": 0, "view_definition": 1})

        if db_vendor.lower() == 'snowflake':
            schema_name = data["schema_name"]
            query = db.idea_view_discovery_attr.find_one(
                {"database_nm": database_name, "schema_nm": schema_name,
                "project_id": data["project_id"], "view_nm": view_name,
                 "batch_id": batch_id, "is_secure": "NO"},
                {"_id": 0, "view_definition": 1})

        if not bool(query):
            return response(dumps(error.err_088), 404)

        query['view_definition'] = query['view_definition'].replace('\\\\r','\r')
        query['view_definition'] = query['view_definition'].replace('\\r','\r')
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "View definition fetched successfully",
        "data": [query]}), 200


@app.route("/idea/services/migrationsf/stored-procedure", methods=["POST"])
@validate_json_schema
def details_of_all_procedure():
    """
    This method will return the list of
    all procedures available in the database
    :return: json data
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        database_name = data['db_name']
        db_vendor = db.idea_procedure_discovery_attr.find_one({"batch_id": batch_id,
                                                            "project_id": data["project_id"]},
                                                              {"_id": 0, "database_vendor": 1})
        if not bool(db_vendor):
            return response(dumps(error.err_088), 404)

        db_vendor = db_vendor["database_vendor"]
        if db_vendor.lower() == 'snowflake' and 'schema_name' not in data:
            return response(dumps(error.err_084), 404)

        # Fetching procedure details
        if db_vendor.lower() == 'teradata':
            query = pd.DataFrame(
                db.idea_procedure_discovery_attr.find(
                    {"database_nm": database_name, "batch_id": batch_id,
                    "project_id": data["project_id"]},
                    {"_id": 0, "procedure_nm": 1}))

        if db_vendor.lower() == 'snowflake':
            schema_name = data['schema_name']
            query = pd.DataFrame(db.idea_procedure_discovery_attr.find(
                {"database_nm": database_name, "schema_nm": schema_name,
                "project_id": data["project_id"], "batch_id": batch_id},
                {"_id": 0, "procedure_nm": 1}))

        resp_df = pd.DataFrame(query)
        if resp_df.empty:
            return response(dumps(error.err_088), 404)

        result = resp_df.to_json()
        result = json.loads(result)
        count = len(result['procedure_nm'].keys())
        result = format_json(result)
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Procedures list fetched successfully",
        "data": [{'procedure_count': count, 'procedures': result}]}), 200


@app.route("/idea/services/migrationsf/stored-procedure/definition", methods=["POST"])
@validate_json_schema
def details_of_req_procd():
    """
    This method will return definition
    of a particular procedure as given by user
    :return: json data
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        database_name = data['db_name']
        procedure_name = data['procedure_name']
        db_vendor = db.idea_procedure_discovery_attr.find_one({"batch_id": batch_id,
                                                            "project_id": data["project_id"]},
                                                              {"_id": 0, "database_vendor": 1})
        if not bool(db_vendor):
            return response(dumps(error.err_088), 404)

        db_vendor = db_vendor["database_vendor"]

        if db_vendor.lower() == 'snowflake' and 'schema_name' not in data:
            return response(dumps(error.err_084), 404)

        # Fetching procedure details
        if db_vendor.lower() == 'teradata':
            query = db.idea_procedure_discovery_attr.find_one(
                {"database_nm": database_name, "procedure_nm": procedure_name,
                 "batch_id": batch_id, "project_id": data["project_id"]},
                {"_id": 0, "procedure_definition": 1})

        if db_vendor.lower() == 'snowflake':
            schema_name = data["schema_name"]
            query = db.idea_procedure_discovery_attr.find_one(
                {"database_nm": database_name, "schema_nm": schema_name,
                 "procedure_nm": procedure_name, "project_id": data["project_id"],
                 "batch_id": batch_id}, {"_id": 0, "procedure_definition": 1})

        if not bool(query):
            return response(dumps(error.err_088), 404)
                
        query['procedure_definition'] = query['procedure_definition'].replace('\\\\r','\r')
        query['procedure_definition'] = query['procedure_definition'].replace('\\r','\r')
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Procedure definition fetched successfully",
        "data": [{'procedure_definition': query['procedure_definition']}]}), 200


@app.route("/idea/services/migrationsf/snowflake-wh-list", methods=['POST'])
@validate_json_schema
def snowflake_warehouse_list():
    """
    This service will get the list of the snowflake warehouses
    :return: json data
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True,
                                                "link_service_type":snowflake_dwh}, {"_id": 0})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)
        
        # Fetching warehouse details
        resp_df = pd.DataFrame(db.idea_warehouse_discovery_attr.find({"batch_id": batch_id,
                                                                "project_id": data["project_id"]},
                                                                     {"_id": 0, "is_default": 1,
                                                                      "warehouse_name": 1,
                                                                      "type": 1, "size": 1,
                                                                      "min_cluster_count": 1,
                                                                      "max_cluster_count": 1,
                                                                      "credits_used": 1,
                                                                      "credits_used_compute": 1,
                                                                      "credits_used_cloud_services"
                                                                      : 1}))
        if resp_df.empty:
            return response(dumps(error.err_088), 404)

        resp_df[['min_cluster_count', 'max_cluster_count']] = \
            resp_df[['min_cluster_count', 'max_cluster_count']].fillna(value=0)
        resp_df = resp_df.astype({"min_cluster_count": int, "max_cluster_count": int})
        result = resp_df.to_json()
        result = format_json(json.loads(result))
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Warehouse list fetched successfully",
        "data": result}), 200


@app.route('/idea/services/migrationsf/users', methods=['POST'])
@validate_json_schema
def users_list():
    """
    This method will return the list of
    all users available in the instance
    :return: json data
    """
    log.info("START")
    
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {"_id": 0})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        # Fetching user details
        query = db.idea_user_discovery_attr.find({"batch_id": batch_id,
                                                "project_id": data["project_id"]},
                                                 {"_id": 0, "user_nm": 1})
        resp_df = pd.DataFrame(query).drop_duplicates(ignore_index=True)
        if resp_df.empty:
            return response(dumps(error.err_088), 404)

        result = resp_df.to_json()
        result = format_json(json.loads(result))
        user_count = len(
            db.idea_user_discovery_attr.find({'batch_id': batch_id,
                "project_id": data["project_id"]}).distinct('user_nm'))
        result = sorted(result, key=lambda x: x['user_nm'].lower())
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Users list fetched successfully",
        "data": [{'user_count': user_count, 'users': result}]}), 200


@app.route('/idea/services/migrationsf/roles', methods=['POST'])
@validate_json_schema
def roles_list():
    """
    Return list of roles from a particular database
    :return: json data
    """
    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {"_id": 0})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        # Fetching role details
        query = db.idea_role_discovery_attr.find({"batch_id": batch_id,
                                                "project_id": data["project_id"]},
                                                 {"_id": 0, "role_nm": 1, "database_nm": 1,
                                                  "schema_nm": 1, 'object_type': 1,
                                                  "object_nm": 1, "access_right": 1})
        resp_df = pd.DataFrame(query)
        if resp_df.empty:
            return response(dumps(error.err_088), 404)

        resp_df.drop_duplicates(inplace=True, ignore_index=True)
        resp_df.replace({'': None}, inplace=True)
        result = resp_df.to_json()
        result = format_json(json.loads(result))
        role_count = len(
            db.idea_role_discovery_attr.find({'batch_id': batch_id,
            "project_id": data["project_id"]}).distinct('role_nm'))
        result = sorted(result, key=lambda x: x['role_nm'].lower())
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "Roles list fetched successfully",
        "data": [{'role_count': role_count, 'roles': result}]}), 200


@app.route('/idea/services/migrationsf/user-role-list', methods=['POST'])
@validate_json_schema
def users_access_list():
    """
    This method will return the list of
    all users available in the instance
    :return: json data
    """

    log.info("START")

    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()
        
        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)
        
        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True}, {"_id": 0})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)
        
        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)

        # Fetching user access list
        query = db.idea_user_discovery_attr.find({"batch_id": batch_id,
                                                "project_id": data["project_id"]},
                                                 {"_id": 0, "user_nm": 1, "database_nm": 1,
                                                  'schema_nm': 1, 'role_nm': 1})
        resp_df = pd.DataFrame(query)
        if resp_df.empty:
            return response(dumps(error.err_088), 404)
        resp_df.drop_duplicates(inplace=True, ignore_index=True)
        resp_df.replace({'': None}, inplace=True)
        result = resp_df.to_json()
        result = format_json(json.loads(result))
        user_count = len(db.idea_user_discovery_attr.find({'batch_id': batch_id,
                            "project_id": data["project_id"]})
                         .distinct('user_nm'))
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
        "category": "Snowflake_Migration",
        "error_code": "",
        "message": "User-Role list fetched successfully",
        "data": [{'user_count': user_count, 'users': result}]}), 200


@app.route("/idea/services/migrationsf/share-list", methods=["POST"])
@validate_json_schema
def share_list():
    """
    share list
    """

    log.info("START")
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()
        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Link service validation
        link_service_id = data['link_service_id']
        link_service = db.link_service.find_one({"link_service_id":link_service_id, "active":True,
                                                "link_service_type":snowflake_dwh}, {"_id": 0})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)
        
        # Validate 'job_run_id'
        if "job_run_id" in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
            if not bool(batch_id):
                return response(dumps(error.err_060), 404)
            shares = list(db.idea_share_discovery_attr.find({"batch_id": batch_id},{"_id": 0, "active": 0,
                                                        "link_service_id": 0, "created_at_str": 0,
                                                        "insert_dttm": 0, "project_id": 0,
                                                        "insert_dttm_str": 0, "batch_id": 0}))
            if shares == []:
                return response(dumps(error.err_088), 404)

            # Fetching share details
            for share in range(len(shares)):
                reader_locators = list(db.idea_linkage_discovery_attr.find({"batch_id": batch_id,
                                                        "share_name":shares[share]['share_name'],
                                                            "reader_locator": {mongodb_exists: True}},
                                                                {"_id": 0, "reader_locator": 1}))
                reader_accounts = []
                if reader_locators != []:
                    for locator in reader_locators:
                        reader_accounts.append(db.idea_reader_discovery_attr.find_one({"batch_id": batch_id,
                                                                "locator":locator['reader_locator']},
                                                                {"_id": 0, "reader_name": 1})['reader_name'])
                full_accounts = list(db.idea_linkage_discovery_attr.find({"batch_id": batch_id,
                                                        "share_name":shares[share]['share_name'],
                                                            "full_account": {mongodb_exists: True}},
                                                                {"_id": 0, "full_account": 1}))
                if full_accounts != []:
                    full_accounts = [full_account['full_account'] for full_account in full_accounts]

                shares[share]['reader_accounts'] = reader_accounts
                shares[share]['full_accounts'] = full_accounts
                shares[share]['link_service_name'] = link_service['link_service_name']
        else:
            shares = list(db.idea_data_sharing_shares.find({"link_service_id": data['link_service_id'],
                                                            "active": True},{"_id": 0, "active": 0,
                                                            "link_service_id": 0, "created_at_str": 0}))
            if shares == []:
                return response(dumps(error.err_088), 404)
            
            for share in range(len(shares)):
                reader_locators = list(db.idea_data_sharing_linkage.find({"link_service_id": link_service_id,
                                                                "share_name":shares[share]['share_name'],
                                                                "reader_locator": {mongodb_exists: True},
                                                                "active": True}, {"_id": 0, "reader_locator": 1}))
                reader_accounts = []
                if reader_locators != []:
                    for locator in reader_locators:
                        reader_accounts.append(db.idea_data_sharing_readers.find_one({"link_service_id": link_service_id,
                                                                "locator":locator['reader_locator'],
                                                                "active": True}, {"_id": 0, "reader_name": 1})['reader_name'])
                full_accounts = list(db.idea_data_sharing_linkage.find({"link_service_id": link_service_id,
                                                                "share_name":shares[share]['share_name'],
                                                                "full_account": {mongodb_exists: True},
                                                                "active": True}, {"_id": 0, "full_account": 1}))
                if full_accounts != []:
                    full_accounts = [full_account['full_account'] for full_account in full_accounts]
                    
                shares[share]['reader_accounts'] = reader_accounts
                shares[share]['full_accounts'] = full_accounts
                shares[share]['link_service_name'] = link_service['link_service_name']
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Share list fetched successfully",
          "data": shares}), 200


@app.route("/idea/services/migrationsf/reader-list", methods=["POST"])
@validate_json_schema
def reader_list():
    """
    reader list
    """

    log.info("START")
    try:
        # User authentication
        access_details = validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Link service validation
        link_service_id = data['link_service_id']
        link_service = db.link_service.find_one({"link_service_id":link_service_id, "active":True,
                                                "link_service_type":snowflake_dwh}, {"_id": 0})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Validate 'job_run_id'
        if "job_run_id" in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
            if not bool(batch_id):
                return response(dumps(error.err_060), 404)

            # Fetching reader details
            readers = list(db.idea_reader_discovery_attr.find({"batch_id": batch_id},{"_id": 0, "active": 0,
                                                        "link_service_id": 0, "created_at_str": 0,
                                                        "insert_dttm": 0, "project_id": 0,
                                                        "insert_dttm_str": 0, "batch_id": 0}))
            if readers == []:
                return response(dumps(error.err_088), 404)
            for reader in range(len(readers)):
                assigned_shares = list(db.idea_linkage_discovery_attr.find({"batch_id": batch_id, 
                                                    "reader_locator":readers[reader]['locator']},
                                                    {"_id": 0, "share_name": 1}))
                shares = []
                if assigned_shares != []:
                    shares = [share['share_name'] for share in assigned_shares]
                readers[reader]['shares'] = shares
                readers[reader]['link_service_name'] = link_service['link_service_name']
        else:
            readers = list(db.idea_data_sharing_readers.find({"link_service_id": data['link_service_id'],
                                                            "active": True},{"_id": 0, "active": 0,
                                                            "link_service_id": 0, "created_at_str": 0}))
            if readers == []:
                return response(dumps(error.err_088), 404)
            
            for reader in range(len(readers)):
                assigned_shares = list(db.idea_data_sharing_linkage.find({"link_service_id": link_service_id, 
                                                                        "reader_locator":readers[reader]['locator'],
                                                                        "active": True}, {"_id": 0, "share_name": 1}))
                shares = []
                if assigned_shares != []:
                    shares = [share['share_name'] for share in assigned_shares]
                readers[reader]['shares'] = shares
                readers[reader]['link_service_name'] = link_service['link_service_name']
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Reader list fetched successfully",
          "data": readers}), 200


@app.route("/idea/services/migrationsf/secure-object-list", methods=["POST"])
@validate_json_schema
def secure_view_list():
    """
    secure view list
    """

    log.info("START")
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()
        
        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Link service validation
        link_service_id = data['link_service_id']
        link_service = db.link_service.find_one({"link_service_id":link_service_id, "active":True,
                                                "link_service_type":snowflake_dwh}, {"_id": 0})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)
        database = data['database']
        schema = data['schema']

        # Fetching batch_id
        if 'job_run_id' in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
        else:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"])
        if not bool(batch_id):
            return response(dumps(error.err_060), 404)
        
        # Fetching secure views details
        secure_views = list(db.idea_view_discovery_attr.find({"batch_id": batch_id,
                    "database_nm": database, "schema_nm": schema, "is_secure": "YES"},
                    {"_id": 0, "view_nm": 1})) + list(db.idea_materialized_view_discovery_attr.find(
                    {"batch_id": batch_id,"database_nm": database, "schema_nm": schema},
                    {"_id": 0, "view_nm": 1}))
        if secure_views == []:
            return response(dumps(error.err_088), 404)
        secure_views = [secure_view['view_nm'] for secure_view in secure_views]
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Secure view list fetched successfully",
          "data": secure_views}), 200


@app.route("/idea/services/migrationsf/unassigned-shares", methods=["POST"])
@validate_json_schema
def unassigned_shares():
    """
    unassigned shares
    """

    log.info("START")
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()

        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Reader validation
        reader = db.idea_data_sharing_readers.find_one({"link_service_id": data['link_service_id'],
                    "active": True, "reader_name": data['reader_name']}, {"_id": 0, "locator": 1})
        if not bool(reader):
            return response(dumps(error.err_088), 404)

        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True,
                                                                "link_service_type":snowflake_dwh}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Validate 'job_run_id'
        if "job_run_id" in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
            if not bool(batch_id):
                return response(dumps(error.err_060), 404)

            # Fetching unassigned shares
            assigned_shares = list(db.idea_linkage_discovery_attr.find({"reader_locator": reader['locator'],
                                                    "batch_id": batch_id}, {"_id": 0, "share_name": 1}))
            if assigned_shares != []:
                assigned_shares = [assigned_share['share_name'] for assigned_share in assigned_shares]
            shares = list(db.idea_share_discovery_attr.find({"batch_id": batch_id}, {"_id": 0, "share_name": 1}))
            if shares != []:
                shares = [share['share_name'] for share in shares]
            unassigned_shares = list(set(shares).difference(set(assigned_shares)))
        else:
            assigned_shares = list(db.idea_data_sharing_linkage.find({"reader_locator": reader['locator'],
                "active": True, "link_service_id": data['link_service_id']}, {"_id": 0, "share_name": 1}))
            if assigned_shares != []:
                assigned_shares = [assigned_share['share_name'] for assigned_share in assigned_shares]
            shares = list(db.idea_data_sharing_shares.find({"link_service_id": data['link_service_id'],
                                                            "active": True}, {"_id": 0, "share_name": 1}))
            if shares != []:
                shares = [share['share_name'] for share in shares]
            unassigned_shares = list(set(shares).difference(set(assigned_shares)))
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)

    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Unssigned shares fetched successfully",
          "data": unassigned_shares}), 200


@app.route("/idea/services/migrationsf/unassigned-readers", methods=["POST"])
@validate_json_schema
def unassigned_readers():
    """
    unassigned readers
    """

    log.info("START")
    try:
        # User authentication
        access_details=validate_access_token(request.headers.get('Authorization'),
                                     permissions=["discovery"])
        if not access_details:
            return response(dumps(error.err_051), 401)

        # Get json data
        data = request.get_json()
        
        # User project access validation
        user_data =  get_userdata(access_details, data['project_id'])
        if user_data == False:
            return response(dumps(error.err_089), 400)

        # Share validation
        share = db.idea_data_sharing_shares.find_one({"link_service_id": data['link_service_id'],
                                        "active": True, "share_name": data['share_name']}, {})
        if not bool(share):
            return response(dumps(error.err_088), 404)

        # Link service validation
        link_service = db.link_service.find_one({"link_service_id":data['link_service_id'], "active":True,
                                                                "link_service_type":snowflake_dwh}, {})
        if not bool(link_service):
            return response(dumps(error.err_076), 400)

        # Validate 'job_run_id'
        unassigned_readers = []
        if "job_run_id" in data:
            batch_id = get_batch_id(data["link_service_id"],
                                    data["project_id"],
                                    data["job_run_id"])
            if not bool(batch_id):
                return response(dumps(error.err_060), 404)

            # Fetching unassigned readers
            readers = list(db.idea_reader_discovery_attr.find({"batch_id":batch_id}, {"_id": 0,
                                                            "locator": 1, "reader_name": 1}))
            for reader in readers:
                assigned_reader = db.idea_linkage_discovery_attr.find_one({"reader_locator": reader['locator'],
                                                "batch_id": batch_id, "share_name": data['share_name']})
                if not bool(assigned_reader):
                    unassigned_readers.append(reader['reader_name'])
        else:
            readers = list(db.idea_data_sharing_readers.find({"link_service_id":data['link_service_id'], "active":True},
                                                                        {"_id": 0, "locator": 1, "reader_name": 1}))
            for reader in readers:
                assigned_reader = db.idea_data_sharing_linkage.find_one({"reader_locator": reader['locator'],
                                                    "share_name": data['share_name'], "active": True})
                if not bool(assigned_reader):
                    unassigned_readers.append(reader['reader_name'])
    except Exception as e_error:
        log.error(e_error)
        return response(dumps(error.err_095), 500)
          
    log.info("END")
    return jsonify({"status": "Success",
          "category": "Snowflake_Migration",
          "error_code": "",
          "message": "Unassigned readers fetched successfully",
          "data": unassigned_readers}), 200