import re


text = """ 
select 1 from dbc.tables where TableKind='T'
and DatabaseName='${WORK_DB}' and tablename = 'mfp1_org';

.IF ACTIVITYCOUNT = 1 THEN drop table ${WORK_DB}.mfp1_org;

.IF ERRORLEVEL > 0 THEN .GOTO ABEND;

--capgemini

.IF ERRORLEVEL > 0 THEN .GOTO ABEND;

drop something;

CREATE MULTISET TABLE ${WORK_DB}.mfp1_org AS (
    SELECT  DISTINCT
       chain.mer_org_id                    chn_mer_org_id,
       chain.mer_org_nm                    chn_mer_org_nm,
       area.mer_org_id                     area_mer_org_id,
       area.mer_org_nm                     area_mer_org_nm,
       region.mer_org_id                   rgn_mer_org_id,
       region.mer_org_nm                   rgn_mer_org_nm,
       district.mer_org_id                 dist_mer_org_id,
       district.mer_org_nm                 dist_mer_org_nm
    FROM ${MERCH_VMDB}.mer_org                          district

    LEFT JOIN ${MERCH_VMDB}.mer_org                          region
      ON region.mer_org_id            = district.prnt_mer_org_id
      AND region.mer_org_typ_nm       = 'region'
      AND region.mer_org_vrsn_end_dts = '9999-12-31 00:00:00.0'
      AND region.instnc_st_nm         = 'standard'

    LEFT JOIN ${MERCH_VMDB}.mer_org                          area
      ON area.mer_org_id            = region.prnt_mer_org_id
      AND area.mer_org_typ_nm       = 'area'
      AND area.mer_org_vrsn_end_dts = '9999-12-31 00:00:00.0'
      AND area.instnc_st_nm         = 'standard'

    LEFT JOIN ${MERCH_VMDB}.mer_org                          chain
      ON chain.mer_org_id            = area.prnt_mer_org_id
      AND chain.mer_org_typ_nm       = 'chain'
      AND chain.mer_org_vrsn_end_dts = '9999-12-31 00:00:00.0'
      AND chain.instnc_st_nm         = 'standard'

    WHERE district.mer_org_typ_nm       = 'district'
      AND district.mer_org_vrsn_end_dts = '9999-12-31 00:00:00.0'
      AND district.instnc_st_nm         = 'standard'

) WITH  DATA PRIMARY INDEX(chn_mer_org_id, area_mer_org_id, rgn_mer_org_id, dist_mer_org_id);

.IF ERRORLEVEL > 0 THEN .GOTO ABEND;

COLLECT STATISTICS on ${WORK_DB}.mfp1_org COLUMN chn_mer_org_id;

.IF ERRORLEVEL > 0 THEN .GOTO ABEND;

COLLECT STATISTICS on ${WORK_DB}.mfp1_org COLUMN area_mer_org_id;

.IF ERRORLEVEL > 0 THEN .GOTO ABEND;

COLLECT STATISTICS on ${WORK_DB}.mfp1_org COLUMN rgn_mer_org_id;

.IF ERRORLEVEL > 0 THEN .GOTO ABEND;

COLLECT STATISTICS on ${WORK_DB}.mfp1_org COLUMN dist_mer_org_id;

.IF ERRORLEVEL > 0 THEN .GOTO ABEND;


--capgeminii




--capgeminii

select 1 from dbc.tables where TableKind='T'
and DatabaseName='${WORK_DB}' and tablename = 'mfp1_clndr_org';

.IF ACTIVITYCOUNT = 1 THEN drop table ${WORK_DB}.mfp1_clndr_org;

.IF ERRORLEVEL > 0 THEN .GOTO ABEND;


--capgeminii


.IF ERRORLEVEL > 0 THEN .GOTO ABEND;


CREATE  MULTISET TABLE ${WORK_DB}.mfp1_clndr_org AS (
   SELECT fscl_wk_end_dt,
          o.*
   FROM  ${DATE_VMDB}.dt       dt,
         ${WORK_DB}.mfp1_org        o
   WHERE fscl_yr_nb in (select fscl_yr_nb from ${WORK_DB}.wrk_mfp_year_dates_D)
   AND fscl_wk_end_in = 'Y'
   AND clndr_wk_dy_nb = 7
) WITH  DATA PRIMARY INDEX(fscl_wk_end_dt);

drop something;

drop something;

.if something create something;

drop something;

drop something;

. set logo
. label quit;
. bla bla;

"""

# drop statement fix

# assumption : all comments are replaced by placeholder

# contains block indices which should not be commented

sqlList = ["CREATE", "SELECT", "INSERT", "UPDATE", "ALTER", "DELETE", "DROP"]
sqlListRe = re.compile(r"(?i)^[\s]*\b(?:%s)\b" %("|".join(sqlList)))

def get_type(block):
    # copy of block without comments and stripped of newlines and whitespaces
    cp_block = re.sub(r"(!!!|--).*","", block).strip("\n ")
    
    # do a regex search of sqlList
    match = sqlListRe.search(cp_block)
    if match is None:
        return "OTHER"
    return match.group(0).upper()
    

def get_drop_list(block_list):
    drop_list = []
    stop_scan = False
    # iterate backwards
    for index in range(len(block_list)-1, 0, -1):
        curr_block = block_list[index]
        block_type = get_type(curr_block)
        #print(block_type)
        if block_type in sqlList:
            if block_type != "DROP":
                # stop scanning if sql block other than drop
                stop_scan = False
            else :
                # if drop type, add this index to drop_list
                drop_list.append(index)
        
        if stop_scan :
            # do something and then break
            break
    return drop_list


def driver(string):
    block_list = string.split(";")
    get_drop_list(block_list)
    #print(drop_list)

#driver(text)