import re

reDate = r"(?i)date[\s]+['\"]{1}(.*)['\"]{1}"
reTimestamp = r"(?i)timestamp[\s]+['\"]{1}(.*)['\"]{1}"

replaceDate = "cast('{}' as date)"
replaceTimestamp = "cast('{}' as timestamp)" 

def date_hardcode_fix(string):
    res = ""
    start_index = 0
    for match in re.finditer(reDate, string):
        res += string[start_index:match.start()] + replaceDate.format(match.group(1))
        start_index = match.end()
    res += string[start_index:]
    return res
    
def timestamp_hardcode_fix(string):
    res = ""
    start_index = 0
    for match in re.finditer(reTimestamp, string):
        res += string[start_index:match.start()] + replaceTimestamp.format(match.group(1))
        start_index = match.end()
    res += string[start_index:]
    return res
    
def ts_hardcode_fix(string):
    return timestamp_hardcode_fix(date_hardcode_fix(string))
    
def init(filepath, outpath):
    output = ""
    fp = open(filepath)
    for line in fp.readlines():
        output += process(line)
    
    op = open(outpath, 'w+')
    op.write(output)
    op.close()
    
#init(input("Enter src file:\n"), input("Enter tgt file:\n"))
