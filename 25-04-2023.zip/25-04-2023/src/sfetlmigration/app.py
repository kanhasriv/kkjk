"""
This service  run consumer for etl_migration
"""
import logging
import logging.handlers
import json
import _thread
from kafka import KafkaConsumer
from config import config
from libs.etl_migration import etl_migration

# Log
log = logging.getLogger(config["logging"]["name"])
log.setLevel(int(config["logging"]["logging_level"]))
handler = logging.handlers.RotatingFileHandler(
            config["logging"]["filename"],
            maxBytes = int(config["logging"]["logging_maxBytes"]),
            backupCount = int(config["logging"]["logging_backup_count"]))

# Set the log format
handler.setFormatter(
        logging.Formatter("%(asctime)s|%(levelname)-5.5s|[%(filename)s:%(lineno)s-%(funcName)20s()]|%(message)s"))
log.addHandler(handler)

# set consumer for etl migration
topic = config["kafka"]["topic_etl_migration"]
server = config["kafka"]["host"]
consumer_blob_sf = KafkaConsumer(topic,bootstrap_servers=[server])

log.info("Snowflake ETL Migration Service initialized Successfully")

for message in consumer_blob_sf:
    message = message.value.decode("utf-8")
    data = json.loads(message)
    _thread.start_new_thread(etl_migration, (data,))




