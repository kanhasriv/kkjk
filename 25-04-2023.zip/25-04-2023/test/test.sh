#!/bin/bash

directoryArr=()
pythonArr=()

walk_dir () {
    for pathname in "$1"/*; do
        if [ -d "$pathname" ]; then
            walk_dir "$pathname"
        elif [ -e "$pathname" ]; then
            case "$pathname" in
                *.py)
                    
		    
		    directory=`dirname "$pathname"`
		    directoryArr+=( "$directory" )
		    pyScript=${pathname##*/}
		    pythonArr+=( "$pyScript" )

		    #echo "executing $directory ****** $pyScript"		    
		    
		    #cd "$directory"
		    #python "$pyScript"
            esac
        fi
    done
    
}

DOWNLOADING_DIR=$WORKSPACE/test

walk_dir "$DOWNLOADING_DIR"


#echo "${#pythonArr[@]} ${#directoryArr[@]}"
for i in "${!pythonArr[@]}"
do
    if [ "${pythonArr[i]}" = "__init__.py" ];then
    	echo "init file"
    else
	cd "${directoryArr[i]}"
	mkdir log
	echo "${directoryArr[i]} .... ${pythonArr[i]}"
	
	coverage run -m unittest 
	#discover
    	#python "${pythonArr[i]}"
	ret=$?
	#echo "ret: ${ret}"
	if [ $ret -ne 0 ]; then
     		echo "failed test cases for ${pythonArr[i]}"
	        exit $ret
	fi
	#echo "return value"
	
    fi
done  
exit $ret
#echo "$directoryArr ******* $pythonArr"
